# Environmental Recycling Learning Platform

This is an environmental recycling learning platform developed based on the CodeIgniter 4 framework, aimed at providing educational resources on environmental protection and waste recycling.

## Features

- User registration and login system
- Admin panel for managing platform content
- Course management (CRUD)
- Quiz system (CRUD)
- Blog system (CRUD)
- Responsive design, supporting various devices

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Composer
- Apache/Nginx server

## Installation Steps

### 1. Clone the project

```bash
git clone https://github.com/yourusername/elearning-platform.git
cd elearning-platform
```

### 2. Install dependencies

```bash
composer install
```

### 3. Configure database

Copy the `env` file to `.env`, and update the database configuration:

```
database.default.hostname = localhost
database.default.database = elearning
database.default.username = your_username
database.default.password = your_password
database.default.DBDriver = MySQLi
```

### 4. Run database migrations and seeds

```bash
php spark migrate
php spark db:seed MainSeeder
```

### 5. Create upload directories

```bash
mkdir -p public/uploads/courses public/uploads/blogs
chmod -R 755 public/uploads
```

### 6. Start development server

```bash
php spark serve
```

Now, you can access the website through your browser at `http://localhost:8080`.

## Default Admin Account

- Email: admin@example.com
- Password: admin123

## Project Structure

- `/app/Controllers` - Controller files
- `/app/Models` - Data models
- `/app/Views` - View files
- `/app/Database/Migrations` - Database migration files
- `/app/Database/Seeds` - Database seed files
- `/public/uploads` - Upload file storage directory

## License

MIT License 