<?php

// Initialize CodeIgniter
require 'app/Config/Paths.php';
$paths = new Config\Paths();
require rtrim($paths->systemDirectory, '\\/ ') . DIRECTORY_SEPARATOR . 'bootstrap.php';

// Create a database connection
$db = \Config\Database::connect();

try {
    // Check if the contacts table exists
    $tables = $db->listTables();
    echo "Tables in database: " . implode(', ', $tables) . "\n\n";
    
    if (in_array('contacts', $tables)) {
        echo "Contacts table exists.\n";
        
        // Get table structure
        $fields = $db->getFieldData('contacts');
        echo "Fields in contacts table:\n";
        foreach ($fields as $field) {
            echo "- {$field->name} ({$field->type}, {$field->max_length})\n";
        }
        
        // Test insertion
        echo "\nTesting insertion into contacts table...\n";
        $data = [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'phone' => '1234567890',
            'subject' => 'Test Subject',
            'message' => 'This is a test message from the debug script.',
            'status' => 'unread',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $result = $db->table('contacts')->insert($data);
        $affectedRows = $db->affectedRows();
        
        if ($result && $affectedRows > 0) {
            echo "Insertion successful! Affected rows: {$affectedRows}\n";
            echo "Last insert ID: " . $db->insertID() . "\n";
        } else {
            echo "Insertion failed! Affected rows: {$affectedRows}\n";
            echo "Error: " . $db->error()['message'] . "\n";
        }
        
        // Count records
        $count = $db->table('contacts')->countAllResults();
        echo "Total records in contacts table: {$count}\n";
    } else {
        echo "Contacts table does not exist!\n";
        echo "Running migration to create contacts table...\n";
        
        // Run migration
        $migrate = \Config\Services::migrations();
        $migrate->setNamespace('App');
        if ($migrate->latest()) {
            echo "Migration successful!\n";
        } else {
            echo "Migration failed!\n";
        }
    }
} catch (\Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . " (Line: " . $e->getLine() . ")\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
} 