<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// Set homepage to Home controller
$routes->get('/', 'Home::index');
$routes->get('about', 'Home::about');
$routes->get('contact', 'Contact::index');
$routes->post('contact/submit', 'Contact::submit');

// Courses routes
$routes->get('courses', 'Courses::index');
$routes->get('courses/search', 'Courses::search');
$routes->get('courses/view/(:num)', 'Courses::view/$1');
$routes->get('courses/learn/(:num)', 'Courses::learn/$1');
$routes->get('courses/startLearning/(:num)', 'Courses::startLearning/$1');
$routes->get('courses/startQuiz/(:num)', 'Courses::startQuiz/$1');
$routes->post('courses/submitQuiz', 'Courses::submitQuiz');
$routes->post('courses/updateCourseCompletion', 'Courses::updateCourseCompletion');
$routes->get('courses/certificate/(:num)', 'Courses::certificate/$1');
$routes->get('certificates/verify', 'Courses::verifyCertificate');
$routes->get('courses/bookmarks', 'Courses::bookmarks');
$routes->post('courses/bookmark/(:num)', 'Courses::bookmark/$1');

// Blogs routes
$routes->get('blogs', 'Blogs::index');
$routes->get('blogs/view/(:num)', 'Blogs::view/$1');

// Add blog bookmarks routes
$routes->get('blogs/bookmarks', 'Blogs::bookmarks');
$routes->post('blogs/bookmark/(:num)', 'Blogs::bookmark/$1');
$routes->post('blogs/unbookmark/(:num)', 'Blogs::unbookmark/$1');

// Add dashboard route
$routes->get('dashboard', 'Auth::dashboard');

// Add test routes
$routes->get('test', 'Test::index');
$routes->get('test/db', 'Test::testDb');

// Authentication related routes
$routes->group('auth', function($routes) {
    $routes->get('/', 'Auth::index');
    $routes->get('login', 'Auth::login');
    $routes->post('authenticate', 'Auth::authenticate');
    $routes->get('register', 'Auth::register');
    $routes->post('create-account', 'Auth::createAccount');
    $routes->get('logout', 'Auth::logout');
    
    // 個人資料管理
    $routes->get('edit-profile', 'Auth::editProfile');
    $routes->post('update-profile', 'Auth::updateProfile');
    $routes->get('change-password', 'Auth::changePassword');
    $routes->post('update-password', 'Auth::updatePassword');
});

// Admin panel related routes
$routes->group('admin', function($routes) {
    // Dashboard
    $routes->get('/', 'Admin::index');
    $routes->get('dashboard', 'Admin::dashboard');
    
    // User Management
    $routes->get('users', 'Admin::users');
    $routes->get('add-admin', 'Admin::addAdmin');
    $routes->post('create-admin', 'Admin::createAdmin');
    $routes->get('edit-user/(:num)', 'Admin::editUser/$1');
    $routes->post('update-user/(:num)', 'Admin::updateUser/$1');
    $routes->get('delete-user/(:num)', 'Admin::deleteUser/$1');
    
    // Course Management
    $routes->get('courses', 'Admin::courses');
    $routes->get('add-course', 'Admin::addCourse');
    $routes->post('create-course', 'Admin::createCourse');
    $routes->get('edit-course/(:num)', 'Admin::editCourse/$1');
    $routes->post('update-course/(:num)', 'Admin::updateCourse/$1');
    $routes->get('delete-course/(:num)', 'Admin::deleteCourse/$1');
    
    // Quiz Management
    $routes->get('quizzes', 'Admin::quizzes');
    $routes->get('quizzes/(:num)', 'Admin::quizzes/$1');
    $routes->get('add-quiz', 'Admin::addQuiz');
    $routes->get('add-quiz/(:num)', 'Admin::addQuiz/$1');
    $routes->post('create-quiz', 'Admin::createQuiz');
    $routes->get('edit-quiz/(:num)', 'Admin::editQuiz/$1');
    $routes->post('update-quiz/(:num)', 'Admin::updateQuiz/$1');
    $routes->get('delete-quiz/(:num)', 'Admin::deleteQuiz/$1');
    
    // Question Management
    $routes->get('questions/(:num)', 'Admin::questions/$1');
    $routes->get('add-question/(:num)', 'Admin::addQuestion/$1');
    $routes->post('create-question', 'Admin::createQuestion');
    $routes->get('edit-question/(:num)', 'Admin::editQuestion/$1');
    $routes->post('update-question/(:num)', 'Admin::updateQuestion/$1');
    $routes->get('delete-question/(:num)', 'Admin::deleteQuestion/$1');
    
    // Blog Management
    $routes->get('blogs', 'Admin::blogs');
    $routes->get('add-blog', 'Admin::addBlog');
    $routes->post('create-blog', 'Admin::createBlog');
    $routes->get('edit-blog/(:num)', 'Admin::editBlog/$1');
    $routes->post('update-blog/(:num)', 'Admin::updateBlog/$1');
    $routes->get('delete-blog/(:num)', 'Admin::deleteBlog/$1');
    
    // Profile Management
    $routes->get('profile', 'Admin::profile');
    $routes->post('update-profile', 'Admin::updateProfile');
    
    // Contact Management
    $routes->get('contacts', 'Admin::contacts');
    $routes->get('view-contact/(:num)', 'Admin::viewContact/$1');
    $routes->get('delete-contact/(:num)', 'Admin::deleteContact/$1');
    $routes->post('delete-contact', 'Admin::deleteContactPost');
    $routes->get('mark-all-read-contacts', 'Admin::markAllReadContacts');
    $routes->post('send-reply', 'Admin::sendReply');
    
    // Contact Reply Management
    $routes->get('contact-replies', 'Admin::contactReplies');
    $routes->get('view-reply/(:num)', 'Admin::viewReply/$1');
    $routes->post('delete-reply', 'Admin::deleteReply');
});
