<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdateQuestionsTable extends Migration
{
    public function up()
    {
        // Modify questions table structure
        
        // Add new fields
        $fields = [
            'options' => [
                'type' => 'TEXT',
                'null' => true,
                'comment' => 'JSON format options data',
                'after' => 'question'
            ],
            'correct_answer' => [
                'type' => 'VARCHAR',
                'constraint' => 1,
                'null' => true,
                'comment' => 'Correct answer (A, B, C, D)',
                'after' => 'options'
            ],
        ];
        
        // Try to add fields (if table exists)
        try {
            $this->forge->addColumn('questions', $fields);
        } catch (\Exception $e) {
            // If table does not exist or other errors, create new table
            $this->forge->addField([
                'id' => [
                    'type'           => 'INT',
                    'constraint'     => 11,
                    'unsigned'       => true,
                    'auto_increment' => true,
                ],
                'quiz_id' => [
                    'type'       => 'INT',
                    'constraint' => 11,
                    'unsigned'   => true,
                ],
                'question' => [
                    'type' => 'TEXT',
                    'null' => false,
                ],
                'options' => [
                    'type' => 'TEXT',
                    'null' => true,
                    'comment' => 'JSON format options data',
                ],
                'correct_answer' => [
                    'type' => 'VARCHAR',
                    'constraint' => 1,
                    'null' => true,
                    'comment' => 'Correct answer (A, B, C, D)',
                ],
                'created_at' => [
                    'type' => 'DATETIME',
                    'null' => true,
                ],
                'updated_at' => [
                    'type' => 'DATETIME',
                    'null' => true,
                ],
            ]);
            $this->forge->addKey('id', true);
            $this->forge->addForeignKey('quiz_id', 'quizzes', 'id', 'CASCADE', 'CASCADE');
            $this->forge->createTable('questions', true); // true means replace if table exists
        }
        
        // Try to delete old fields (if they exist)
        try {
            $this->forge->dropColumn('questions', 'answer');
        } catch (\Exception $e) {
            // If field does not exist, ignore error
        }
    }

    public function down()
    {
        // Rollback operation: delete new fields, add old fields
        try {
            // Add answer field
            $fields = [
                'answer' => [
                    'type' => 'TEXT',
                    'null' => true,
                    'after' => 'question'
                ],
            ];
            $this->forge->addColumn('questions', $fields);
            
            // Delete new fields
            $this->forge->dropColumn('questions', 'options');
            $this->forge->dropColumn('questions', 'correct_answer');
        } catch (\Exception $e) {
            // Ignore error
        }
    }
}
