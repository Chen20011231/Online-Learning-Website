<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdateQuizzesTable extends Migration
{
    public function up()
    {
        // Add missing fields to quizzes table
        $fields = [
            'course_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'after' => 'description',
            ],
            'created_by' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'after' => 'course_id',
            ],
            'status' => [
                'type' => 'VARCHAR',
                'constraint' => 20,
                'default' => 'active',
                'after' => 'created_by',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
                'after' => 'status',
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
                'after' => 'created_at',
            ],
        ];
        
        try {
            $this->forge->addColumn('quizzes', $fields);
        } catch (\Exception $e) {
            // If table does not exist, create table
            $this->forge->addField([
                'id' => [
                    'type'           => 'INT',
                    'constraint'     => 11,
                    'unsigned'       => true,
                    'auto_increment' => true,
                ],
                'title' => [
                    'type'       => 'VARCHAR',
                    'constraint' => 255,
                ],
                'description' => [
                    'type' => 'TEXT',
                    'null' => true,
                ],
                'course_id' => [
                    'type'       => 'INT',
                    'constraint' => 11,
                    'unsigned'   => true,
                ],
                'created_by' => [
                    'type'       => 'INT',
                    'constraint' => 11,
                    'unsigned'   => true,
                ],
                'status' => [
                    'type'       => 'VARCHAR',
                    'constraint' => 20,
                    'default'    => 'active',
                ],
                'created_at' => [
                    'type' => 'DATETIME',
                    'null' => true,
                ],
                'updated_at' => [
                    'type' => 'DATETIME',
                    'null' => true,
                ],
            ]);
            $this->forge->addKey('id', true);
            $this->forge->createTable('quizzes', true);
        }
    }

    public function down()
    {
        // Delete added fields
        $this->forge->dropColumn('quizzes', ['course_id', 'created_by', 'status', 'created_at', 'updated_at']);
    }
}
