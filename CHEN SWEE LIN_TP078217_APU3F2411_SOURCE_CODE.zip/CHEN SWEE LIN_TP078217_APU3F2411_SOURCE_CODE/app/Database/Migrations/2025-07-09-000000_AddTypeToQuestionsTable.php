<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddTypeToQuestionsTable extends Migration
{
    public function up()
    {
        // Add 'type' column to questions table
        $fields = [
            'type' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
                'default' => 'multiple_choice',
                'after' => 'question'
            ]
        ];
        
        $this->forge->addColumn('questions', $fields);
    }

    public function down()
    {
        // Remove 'type' column from questions table
        $this->forge->dropColumn('questions', 'type');
    }
} 