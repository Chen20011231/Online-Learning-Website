<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $data = [
            'name' => 'User',
            'email' => 'user@gmail.com',
            'password' => password_hash('user123', PASSWORD_DEFAULT),
            'age' => 30,
            'gender' => 'male',
            'role' => 'user',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        // Insert default administrator account
        $this->db->table('users')->insert($data);
    }
} 