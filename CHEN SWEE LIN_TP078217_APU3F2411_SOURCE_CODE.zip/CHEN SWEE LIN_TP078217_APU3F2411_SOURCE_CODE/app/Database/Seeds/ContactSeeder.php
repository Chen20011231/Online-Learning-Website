<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ContactSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'name' => 'Test User',
                'email' => 'test@example.com',
                'phone' => '1234567890',
                'subject' => 'General Inquiry',
                'message' => 'This is a test message to check if the contact form is working properly.',
                'status' => 'unread',
                'created_at' => date('Y-m-d H:i:s')
            ],
            [
                'name' => 'Another User',
                'email' => 'another@example.com',
                'phone' => '0987654321',
                'subject' => 'Technical Support',
                'message' => 'I need help with the course materials. Can you assist me?',
                'status' => 'unread',
                'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))
            ]
        ];

        // Insert data into contacts table
        $this->db->table('contacts')->insertBatch($data);
    }
} 