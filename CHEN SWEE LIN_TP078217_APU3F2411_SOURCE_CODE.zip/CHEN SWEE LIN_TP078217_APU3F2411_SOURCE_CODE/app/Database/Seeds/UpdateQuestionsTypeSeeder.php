<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UpdateQuestionsTypeSeeder extends Seeder
{
    public function run()
    {
        // Update all questions with 'multiple_choice' as default type
        $this->db->query("UPDATE questions SET type = 'multiple_choice'");
        
        echo "All existing questions have been updated with type 'multiple_choice'\n";
    }
} 