<?= $this->extend('layouts/auth') ?>

<?= $this->section('content') ?>
<div class="auth-container">
    <div class="auth-box">
        <div class="row g-0">
            <!-- Left side - Logo and Name -->
            <div class="col-md-5 auth-brand">
                <div class="brand-content">
                    <img src="<?= base_url('assets/images/eco-logo.png') ?>" alt="Smart Waste Sorting Assistant" class="img-fluid brand-logo">
                    <h2 class="brand-name">Smart Waste Sorting Assistant</h2>
                    <p class="brand-tagline">Learn. Sort. Protect our planet.</p>
                </div>
            </div>
            
            <!-- Right side - Login Form -->
            <div class="col-md-7 auth-form">
                <div class="form-wrapper">
                    <div class="text-end mb-3">
                        <a href="<?= base_url() ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-home"></i> Back to Home Page
                        </a>
                    </div>
                    
<h2 class="form-title">Welcome Back!</h2>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <ul class="mb-0">
            <?php foreach (session()->getFlashdata('errors') as $error): ?>
                <li><?= $error ?></li>
            <?php endforeach; ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<form action="<?= base_url('auth/authenticate') ?>" method="post">
    <?= csrf_field() ?>
    
    <div class="mb-4">
        <label for="email" class="form-label">Email Address</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" class="form-control" id="email" name="email" value="<?= old('email') ?>" placeholder="Enter your email" required>
        </div>
    </div>
    
    <div class="mb-4">
        <label for="password" class="form-label">Password</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
            <button class="btn btn-outline-secondary toggle-password" type="button">
                <i class="fas fa-eye"></i>
            </button>
        </div>
    </div>
    
    <div class="mb-4 form-check">
        <input type="checkbox" class="form-check-input" id="remember" name="remember">
        <label class="form-check-label" for="remember">Remember me</label>
    </div>
    
    <div class="d-grid gap-2 mb-4">
        <button type="submit" class="btn btn-primary">Sign In</button>
    </div>
    
    <div class="text-center">
        <p>Don't have an account? <a href="<?= base_url('auth/register') ?>" class="auth-link">Sign Up</a></p>
    </div>
</form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body {
        background-color: #45586a;
        background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('<?= base_url('assets/images/pagebackground.avif') ?>');
        background-size: cover;
        background-position: center;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0;
        padding: 0;
    }
    
    .auth-container {
        width: 100%;
        max-width: 900px;
        padding: 0;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }
    
    .auth-box {
        background-color: #f8f9fa;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.2);
    }
    
    .auth-brand {
        background-color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 30px;
        border-right: 1px solid #e9ecef;
    }
    
    .brand-content {
        text-align: center;
    }
    
    .brand-logo {
        max-width: 150px;
        margin-bottom: 20px;
    }
    
    .brand-name {
        color: #198754;
        font-weight: 700;
        margin-bottom: 10px;
        font-size: 1.5rem;
    }
    
    .brand-tagline {
        color: #6c757d;
        font-size: 0.9rem;
    }
    
    .auth-form {
        padding: 0;
        background-color: #fff;
    }
    
    .form-wrapper {
        padding: 30px;
    }
    
    .form-title {
        color: #333;
        font-weight: 600;
        margin-bottom: 25px;
        font-size: 1.8rem;
        text-align: left;
    }
    
    .auth-link {
        color: #198754;
        text-decoration: none;
        font-weight: 500;
    }
    
    .auth-link:hover {
        text-decoration: underline;
    }
    
    .btn-primary {
        background-color: #198754;
        border-color: #198754;
    }
    
    .btn-primary:hover {
        background-color: #157347;
        border-color: #146c43;
    }
    
    .btn-outline-secondary {
        border-color: #6c757d;
        color: #6c757d;
    }
    
    .btn-outline-secondary:hover {
        background-color: #6c757d;
        color: #fff;
    }
    
    @media (max-width: 767.98px) {
        .auth-brand {
            border-right: none;
            border-bottom: 1px solid #e9ecef;
            padding: 20px;
        }
        
        .brand-logo {
            max-width: 80px;
            margin-bottom: 10px;
        }
        
        .brand-name {
            font-size: 1.2rem;
        }
        
        .form-wrapper {
            padding: 20px;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    // Toggle password visibility
    document.querySelector('.toggle-password').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const icon = this.querySelector('i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    });
</script>
<?= $this->endSection() ?> 