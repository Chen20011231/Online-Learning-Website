<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container py-4">
    <div class="row g-4">
        <!-- User Profile Sidebar -->
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-user-circle me-2"></i> Personal Information</h5>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <div class="avatar-circle mx-auto mb-3">
                            <span class="avatar-initials"><?= substr($user['name'], 0, 1) ?></span>
                        </div>
                        <h4><?= $user['name'] ?></h4>
                        <p class="text-muted mb-0"><?= $user['email'] ?></p>
                        <?php if ($user['role'] == 'admin'): ?>
                            <span class="badge bg-primary mt-2">Administrator</span>
                        <?php else: ?>
                            <span class="badge bg-success mt-2">Student</span>
                        <?php endif; ?>
                    </div>
                    
                    <ul class="list-group list-group-flush">
                        <?php if (isset($user['age'])): ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Age</span>
                                <span class="text-muted"><?= $user['age'] ?></span>
                            </li>
                        <?php endif; ?>
                        <?php if (isset($user['gender'])): ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Gender</span>
                                <span class="text-muted">
                                    <?php 
                                    if ($user['gender'] == 'male') {
                                        echo 'Male';
                                    } elseif ($user['gender'] == 'female') {
                                        echo 'Female';
                                    } else {
                                        echo 'Other';
                                    }
                                    ?>
                                </span>
                            </li>
                        <?php endif; ?>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Learning Progress</span>
                            <span class="text-muted"><?= $completedCount ?>/<?= $totalCourses ?> Courses</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Certificates Earned</span>
                            <span class="text-muted"><?= count($certificates) ?></span>
                        </li>
                    </ul>
                    
                    <div class="mt-4">
                        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mb-2">
                            <span><i class="fas fa-bookmark me-2"></i>My Bookmarks</span>
                        </h6>
                        
                        <div class="d-grid gap-2">
                            <a href="<?= base_url('courses/bookmarks') ?>" class="btn btn-outline-primary d-flex align-items-center">
                                <i class="fas fa-graduation-cap me-2"></i>
                                <span>Course Bookmarks</span>
                                <span class="ms-auto badge bg-primary rounded-pill">
                                    <?= isset($courseBookmarksCount) ? $courseBookmarksCount : '0' ?>
                                </span>
                            </a>
                            <a href="<?= base_url('blogs/bookmarks') ?>" class="btn btn-outline-success d-flex align-items-center">
                                <i class="fas fa-blog me-2"></i>
                                <span>Blog Bookmarks</span>
                                <span class="ms-auto badge bg-success rounded-pill">
                                    <?= isset($blogBookmarksCount) ? $blogBookmarksCount : '0' ?>
                                </span>
                            </a>
                        </div>
                        
                        <?php if ($user['role'] == 'admin'): ?>
                        <hr class="my-3">
                        <div class="d-grid">
                        <a href="<?= base_url('admin/dashboard') ?>" class="btn btn-primary">
                                <i class="fas fa-tachometer-alt me-1"></i> Admin Dashboard
                        </a>
                        </div>
                        <?php endif; ?>
                        
                        <hr class="my-3">
                        <div class="d-grid gap-2">
                            <a href="<?= base_url('auth/edit-profile') ?>" class="btn btn-outline-primary">
                                <i class="fas fa-user-edit me-1"></i> Edit Profile
                            </a>
                            <a href="<?= base_url('auth/change-password') ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-key me-1"></i> Change Password
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Content Area -->
        <div class="col-lg-8">
            <!-- Overall Progress Card -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0"><i class="fas fa-chart-line me-2"></i> Learning Progress Overview</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span>Overall Progress</span>
                            <span><?= round($progressPercentage, 0) ?>%</span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-success" role="progressbar" 
                                style="width: <?= $progressPercentage ?>%;" 
                                aria-valuenow="<?= $progressPercentage ?>" 
                                aria-valuemin="0" 
                                aria-valuemax="100">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row g-3 text-center">
                        <div class="col-md-4">
                            <div class="p-3 border rounded bg-light">
                                <h3 class="text-primary"><?= $completedCount ?></h3>
                                <p class="text-muted mb-0">Completed Courses</p>
                            </div>
                                </div>
                        <div class="col-md-4">
                            <div class="p-3 border rounded bg-light">
                                <h3 class="text-success"><?= $totalCourses - $completedCount ?></h3>
                                <p class="text-muted mb-0">Courses to Learn</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 border rounded bg-light">
                                <h3 class="text-info"><?= $totalCourses ?></h3>
                                <p class="text-muted mb-0">Total Courses</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2 mt-3">
                        <a href="<?= base_url('courses') ?>" class="btn btn-primary">
                            <i class="fas fa-book-reader me-1"></i> Explore More Courses
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Course Progress Card -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0"><i class="fas fa-graduation-cap me-2"></i> My Courses</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($courseProgress)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-book fa-4x text-muted mb-3"></i>
                            <h4>No courses completed yet</h4>
                            <p class="text-muted mb-4">Start learning and complete course quizzes, your progress will be displayed here</p>
                            <a href="<?= base_url('courses') ?>" class="btn btn-primary">Browse Courses</a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Course Name</th>
                                        <th>Completion Date</th>
                                        <th>Score</th>
                                        <th>Actions</th>
                            </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($courseProgress as $progress): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <?php if (!empty($progress['course']['image'])): ?>
                                                    <img src="<?= base_url('uploads/courses/' . $progress['course']['image']) ?>" alt="" 
                                                        class="img-thumbnail me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-light d-flex justify-content-center align-items-center me-2" 
                                                        style="width: 40px; height: 40px;">
                                                        <i class="fas fa-book text-muted"></i>
                                                    </div>
                            <?php endif; ?>
                                                <?= $progress['course']['title'] ?>
                                            </div>
                                        </td>
                                        <td><?= date('Y-m-d', strtotime($progress['completed_date'])) ?></td>
                                <td>
                                    <?php 
                                            $scoreClass = '';
                                            if ($progress['score'] >= 80) {
                                                $scoreClass = 'text-success';
                                            } elseif ($progress['score'] >= 60) {
                                                $scoreClass = 'text-primary';
                                    } else {
                                                $scoreClass = 'text-danger';
                                    }
                                    ?>
                                            <span class="<?= $scoreClass ?> fw-bold"><?= round($progress['score'], 0) ?>%</span>
                                        </td>
                                        <td>
                                            <a href="<?= base_url('courses/view/' . $progress['course']['id']) ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                </td>
                            </tr>
                                    <?php endforeach; ?>
                                </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Certificates Card -->
            <div class="card shadow-sm">
                <div class="card-header bg-light">
                    <h5 class="mb-0"><i class="fas fa-certificate me-2"></i> My Certificates</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($certificates)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-award fa-4x text-muted mb-3"></i>
                            <h4>No certificates earned yet</h4>
                            <p class="text-muted mb-4">Complete course quizzes with qualifying scores to earn course certificates</p>
                            <a href="<?= base_url('courses') ?>" class="btn btn-primary">Browse Courses</a>
                        </div>
                    <?php else: ?>
                        <div class="row g-3">
                            <?php foreach ($certificates as $certificate): ?>
                            <div class="col-md-6">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h5 class="card-title mb-0"><?= $certificate['course_title'] ?></h5>
                                            <span class="badge bg-success">Passed</span>
                                        </div>
                                        <div class="d-flex align-items-center mb-3">
                                            <?php if (!empty($certificate['course_image'])): ?>
                                                <img src="<?= base_url('uploads/courses/' . $certificate['course_image']) ?>" alt="" 
                                                    class="img-thumbnail me-2" style="width: 60px; height: 60px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light d-flex justify-content-center align-items-center me-2" 
                                                    style="width: 60px; height: 60px;">
                                                    <i class="fas fa-book text-muted fa-2x"></i>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <p class="text-muted mb-0">Certificate No: <?= substr($certificate['certificate_number'], 0, 10) ?>...</p>
                                                <p class="text-muted mb-0">Issue Date: <?= date('Y-m-d', strtotime($certificate['issue_date'])) ?></p>
                                                <p class="text-muted mb-0">Score: <span class="fw-bold"><?= round($certificate['score'], 0) ?>%</span></p>
                                            </div>
                                        </div>
                                        <div class="d-grid">
                                            <button type="button" class="btn btn-outline-primary view-certificate" 
                                                data-id="<?= $certificate['id'] ?>"
                                                data-course="<?= $certificate['course_title'] ?>"
                                                data-user="<?= session()->get('name') ?>"
                                                data-date="<?= date('Y-m-d', strtotime($certificate['issue_date'])) ?>"
                                                data-number="<?= $certificate['certificate_number'] ?>"
                                                data-score="<?= round($certificate['score'], 0) ?>">
                                                <i class="fas fa-eye me-1"></i> View Certificate
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .avatar-circle {
        width: 100px;
        height: 100px;
        background-color: #007bff;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
    }
    
    .avatar-initials {
        font-size: 48px;
        font-weight: bold;
    }
</style>

<!-- Certificate Modal -->
<div class="modal fade" id="certificateModal" tabindex="-1" aria-labelledby="certificateModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="certificateModalLabel">Course Completion Certificate</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="certificate-container p-4">
                    <!-- Certificate Content -->
                    <div class="certificate p-5 bg-white border rounded-3 shadow position-relative overflow-hidden">
                        <!-- Decorative Elements -->
                        <div class="certificate-decoration position-absolute top-0 start-0 w-100 h-100">
                            <div class="certificate-border position-absolute top-0 start-0 w-100 h-100 border border-4 border-primary m-3" style="pointer-events: none;"></div>
                            <div class="certificate-corner-tl position-absolute top-0 start-0 border-top border-start border-5 border-primary" style="width: 50px; height: 50px;"></div>
                            <div class="certificate-corner-tr position-absolute top-0 end-0 border-top border-end border-5 border-primary" style="width: 50px; height: 50px;"></div>
                            <div class="certificate-corner-bl position-absolute bottom-0 start-0 border-bottom border-start border-5 border-primary" style="width: 50px; height: 50px;"></div>
                            <div class="certificate-corner-br position-absolute bottom-0 end-0 border-bottom border-end border-5 border-primary" style="width: 50px; height: 50px;"></div>
                        </div>
                        
                        <!-- Certificate Content -->
                        <div class="certificate-content text-center py-4 position-relative">
                            <!-- Certificate Title -->
                            <div class="certificate-header mb-4">
                                <div class="certificate-logo mb-3">
                                    <img src="<?= base_url('assets/images/eco-logo.png') ?>" alt="Smart Waste Sorting Assistant Logo" class="img-fluid" style="height: 80px;">
                                </div>
                                <p class="certificate-subtitle fs-5 text-muted">Smart Waste Sorting Assistant</p>
                                <h2 class="certificate-title fw-bold text-primary">Course Completion Certificate</h2>                               
                            </div>
                            
                            <!-- Certificate Body -->
                            <div class="certificate-body mb-4">
                                <p class="fs-5 mb-3">This certifies that</p>
                                <h3 class="certificate-name display-6 fw-bold mb-3" id="modal-user-name"></h3>
                                <p class="fs-5 mb-3">has successfully completed the course</p>
                                <h4 class="certificate-course fw-bold mb-3" id="modal-course-title"></h4>
                                <p class="certificate-description mb-3">
                                    This student has achieved a score of <span class="fw-bold" id="modal-score"></span>% in the course quiz,
                                    demonstrating understanding and mastery of environmental recycling knowledge.
                                </p>
                            </div>
                            
                            <!-- Certificate Footer -->
                            <div class="certificate-footer">
                                <div class="row align-items-end">
                                    <div class="col-md-6">
                                        <div class="text-center">
                                            <div class="certificate-date mb-2" id="modal-issue-date"></div>
                                            <div class="certificate-line border-top border-dark w-75 mx-auto"></div>
                                            <div class="certificate-label small">Issue Date</div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="text-center">
                                            <div class="certificate-number mb-2 small text-muted" id="modal-certificate-number"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="printCertificate">
                    <i class="fas fa-print me-1"></i> Print Certificate
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // View certificate button click event
    const viewButtons = document.querySelectorAll('.view-certificate');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get certificate data
            const courseTitle = this.getAttribute('data-course');
            const userName = this.getAttribute('data-user');
            const issueDate = this.getAttribute('data-date');
            const certificateNumber = this.getAttribute('data-number');
            const score = this.getAttribute('data-score');
            
            // Fill modal data
            document.getElementById('modal-course-title').textContent = courseTitle;
            document.getElementById('modal-user-name').textContent = userName;
            document.getElementById('modal-issue-date').textContent = issueDate;
            document.getElementById('modal-certificate-number').textContent = 'Certificate No: ' + certificateNumber;
            document.getElementById('modal-score').textContent = score;
            
            // Show modal
            const certificateModal = new bootstrap.Modal(document.getElementById('certificateModal'));
            certificateModal.show();
        });
    });
    
    // Print certificate
    document.getElementById('printCertificate').addEventListener('click', function() {
        const certificateContent = document.querySelector('.certificate-container').innerHTML;
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
            <head>
                <title>Print Certificate</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
                <style>
                    @media print {
                        body { margin: 0; padding: 20px; }
                        .certificate { border: 2px solid #007bff; page-break-inside: avoid; }
                    }
                </style>
                <base href="${window.location.origin}/">
            </head>
            <body>
                ${certificateContent}
            </body>
            </html>
        `);
        printWindow.document.close();
        setTimeout(() => {
            printWindow.print();
        }, 500);
    });
});
</script>
<?= $this->endSection() ?> 