<?= $this->extend('layouts/auth') ?>

<?= $this->section('content') ?>
<div class="auth-container">
    <div class="auth-box">
        <div class="row g-0">
            <!-- Left side - Logo and Name -->
            <div class="col-md-5 auth-brand">
                <div class="brand-content">
                    <img src="<?= base_url('assets/images/eco-logo.png') ?>" alt="Smart Waste Sorting Assistant" class="img-fluid brand-logo">
                    <h2 class="brand-name">Smart Waste Sorting Assistant</h2>
                    <p class="brand-tagline">Learn. Sort. Protect our planet.</p>
                </div>
            </div>
            
            <!-- Right side - Register Form -->
            <div class="col-md-7 auth-form">
                <div class="form-wrapper">
                    <div class="text-end mb-3">
                        <a href="<?= base_url() ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-home"></i> Back to Home Page
                        </a>
                    </div>
                    
<h2 class="form-title">Create an Account</h2>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <ul class="mb-0">
            <?php foreach (session()->getFlashdata('errors') as $error): ?>
                <li><?= $error ?></li>
            <?php endforeach; ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<form action="<?= base_url('auth/create-account') ?>" method="post" id="registerForm">
    <?= csrf_field() ?>
    
                        <div class="mb-3">
        <label for="name" class="form-label">Full Name</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            <input type="text" class="form-control" id="name" name="name" value="<?= old('name') ?>" placeholder="Enter your full name" required>
        </div>
    </div>
    
                        <div class="mb-3">
        <label for="email" class="form-label">Email Address</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" class="form-control" id="email" name="email" value="<?= old('email') ?>" placeholder="Enter your email" required>
        </div>
    </div>
    
                        <div class="row mb-3">
        <div class="col-md-6">
            <label for="age" class="form-label">Age</label>
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-birthday-cake"></i></span>
                <input type="number" class="form-control" id="age" name="age" value="<?= old('age') ?>" min="1" max="120" placeholder="Your age" required>
            </div>
        </div>
        
        <div class="col-md-6">
            <label for="gender" class="form-label">Gender</label>
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-venus-mars"></i></span>
                <select class="form-select" id="gender" name="gender" required>
                    <option value="" selected disabled>Select Gender</option>
                    <option value="male" <?= old('gender') == 'male' ? 'selected' : '' ?>>Male</option>
                    <option value="female" <?= old('gender') == 'female' ? 'selected' : '' ?>>Female</option>
                    <option value="other" <?= old('gender') == 'other' ? 'selected' : '' ?>>Other</option>
                </select>
            </div>
        </div>
    </div>
    
                        <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" class="form-control" id="password" name="password" placeholder="Create a password" required>
            <button class="btn btn-outline-secondary toggle-password" type="button" data-target="password">
                <i class="fas fa-eye"></i>
            </button>
        </div>
        <div class="form-text">Password must be at least 6 characters</div>
    </div>
    
                        <div class="mb-3">
        <label for="confirm_password" class="form-label">Confirm Password</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
            <button class="btn btn-outline-secondary toggle-password" type="button" data-target="confirm_password">
                <i class="fas fa-eye"></i>
            </button>
        </div>
    </div>
    
                        <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="terms" required>
        <label class="form-check-label" for="terms">I agree to the Terms of Service and Privacy Policy</label>
    </div>
    
                        <div class="d-grid gap-2 mb-3">
        <button type="submit" class="btn btn-primary">Sign Up</button>
    </div>
    
    <div class="text-center">
        <p>Already have an account? <a href="<?= base_url('auth/login') ?>" class="auth-link">Sign In</a></p>
    </div>
</form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body {
        background-color: #45586a;
        background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('<?= base_url('assets/images/pagebackground.avif') ?>');
        background-size: cover;
        background-position: center;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0;
        padding: 0;
    }
    
    .auth-container {
        width: 100%;
        max-width: 900px;
        padding: 0;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }
    
    .auth-box {
        background-color: #f8f9fa;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.2);
    }
    
    .auth-brand {
        background-color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 30px;
        border-right: 1px solid #e9ecef;
    }
    
    .brand-content {
        text-align: center;
    }
    
    .brand-logo {
        max-width: 150px;
        margin-bottom: 20px;
    }
    
    .brand-name {
        color: #198754;
        font-weight: 700;
        margin-bottom: 10px;
        font-size: 1.5rem;
    }
    
    .brand-tagline {
        color: #6c757d;
        font-size: 0.9rem;
    }
    
    .auth-form {
        padding: 0;
        background-color: #fff;
    }
    
    .form-wrapper {
        padding: 30px;
        max-height: 100vh;
        overflow-y: auto;
    }
    
    .form-title {
        color: #333;
        font-weight: 600;
        margin-bottom: 25px;
        font-size: 1.8rem;
        text-align: left;
    }
    
    .auth-link {
        color: #198754;
        text-decoration: none;
        font-weight: 500;
    }
    
    .auth-link:hover {
        text-decoration: underline;
    }
    
    .btn-primary {
        background-color: #198754;
        border-color: #198754;
    }
    
    .btn-primary:hover {
        background-color: #157347;
        border-color: #146c43;
    }
    
    .btn-outline-secondary {
        border-color: #6c757d;
        color: #6c757d;
    }
    
    .btn-outline-secondary:hover {
        background-color: #6c757d;
        color: #fff;
    }
    
    @media (max-width: 767.98px) {
        .auth-brand {
            border-right: none;
            border-bottom: 1px solid #e9ecef;
            padding: 20px;
        }
        
        .brand-logo {
            max-width: 80px;
            margin-bottom: 10px;
        }
        
        .brand-name {
            font-size: 1.2rem;
        }
        
        .form-wrapper {
            padding: 20px;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const passwordInput = document.getElementById(targetId);
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });

    // Password match validation
    document.getElementById('registerForm').addEventListener('submit', function(e) {
        let password = document.getElementById('password').value;
        let confirm_password = document.getElementById('confirm_password').value;
        
        if (password !== confirm_password) {
            e.preventDefault();
            alert('Passwords do not match');
        }
    });
</script>
<?= $this->endSection() ?> 