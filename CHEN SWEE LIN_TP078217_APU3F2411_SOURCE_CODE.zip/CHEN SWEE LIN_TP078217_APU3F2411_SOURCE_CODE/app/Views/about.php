<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Hero Section -->
<section class="about-hero-section">
    <div class="about-hero-overlay">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="hero-title mb-4">About Us</h1>
                    <p class="hero-subtitle mb-0">Dedicated to environmental recycling education, building a sustainable future together</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section class="py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <img src="<?= base_url('assets/images/Lifestyle-for-Environment.jpg') ?>" >
            </div>
            <div class="col-lg-6">
                <h2 class="section-title">Our Mission</h2>
                <p class="text-muted">The Smart Waste Sorting Assistant was established in 2023, aiming to raise public environmental awareness and promote sustainable development concepts by providing high-quality environmental education resources. We believe that every small action from each person can gather to become a force that changes the world.</p>
                <p class="text-muted">We focus on environmental education in the following three areas:</p>
                <ul class="text-muted">
                    <li>Waste sorting and recycling knowledge promotion</li>
                    <li>Practical guidance for sustainable lifestyles</li>
                    <li>Interpretation and sharing of environmental policies and international trends</li>
                </ul>
                <p class="text-muted">Through online courses, community activities, and practical projects, we are committed to transforming environmental concepts into daily actions for everyone.</p>
            </div>
        </div>
    </div>
</section>

<!-- Achievements Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="section-title text-center">Our Achievements</h2>
                <p class="text-muted">Some important achievements since our establishment</p>
            </div>
        </div>
        <div class="row text-center justify-content-center">
            <div class="col-md-4 mb-4">
                <div class="achievement-item">
                    <div class="display-4 text-success fw-bold">10,000+</div>
                    <p class="text-muted">Registered Users</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="achievement-item">
                    <div class="display-4 text-success fw-bold">50+</div>
                    <p class="text-muted">Premium Environmental Courses</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="achievement-item">
                    <div class="display-4 text-success fw-bold">30+</div>
                    <p class="text-muted">Partner Environmental Organizations</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Environmental Data Statistics -->
<section class="py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="section-title text-center">Environmental Data Statistics</h2>
                <p class="text-muted">Environmental achievements through our platform's efforts</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="eco-stat text-center p-4">
                    <div class="eco-icon mb-3">
                        <i class="fas fa-trash-restore fa-3x text-success"></i>
                    </div>
                    <h3 class="counter text-success">15,230</h3>
                    <p class="text-muted">Kilograms of Waste Recycled</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="eco-stat text-center p-4">
                    <div class="eco-icon mb-3">
                        <i class="fas fa-tree fa-3x text-success"></i>
                    </div>
                    <h3 class="counter text-success">5,480</h3>
                    <p class="text-muted">Trees Protected</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="eco-stat text-center p-4">
                    <div class="eco-icon mb-3">
                        <i class="fas fa-tint fa-3x text-success"></i>
                    </div>
                    <h3 class="counter text-success">8,750</h3>
                    <p class="text-muted">Cubic Meters of Water Saved</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="eco-stat text-center p-4">
                    <div class="eco-icon mb-3">
                        <i class="fas fa-bolt fa-3x text-success"></i>
                    </div>
                    <h3 class="counter text-success">12,600</h3>
                    <p class="text-muted">Kilowatt-Hours of Energy Saved</p>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-12 text-center">
                <p class="text-muted">Data updated as of <?= date('F Y') ?></p>
            </div>
        </div>
    </div>
</section>

<!-- Social Responsibility Report -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="section-title text-center">Social Responsibility Report Summary</h2>
                <p class="text-muted">Our commitments and contributions to society and the environment</p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4 p-md-5">
                        <h5 class="card-title mb-4">2024 Social Responsibility Report Highlights</h5>
                        <div class="report-item mb-4">
                            <h6 class="fw-bold"><i class="fas fa-check-circle text-success me-2"></i>Community Environmental Education Projects</h6>
                            <p class="text-muted">Conducted 25 community environmental education activities in 12 cities across the country, reaching over 5,000 community residents, raising awareness about waste sorting and recycling.</p>
                        </div>
                        <div class="report-item mb-4">
                            <h6 class="fw-bold"><i class="fas fa-check-circle text-success me-2"></i>Campus Environmental Action</h6>
                            <p class="text-muted">Collaborated with 30 schools to implement the "Green Campus" project, cultivating students' environmental awareness and action capabilities through interactive courses and practical activities.</p>
                        </div>
                        <div class="report-item mb-4">
                            <h6 class="fw-bold"><i class="fas fa-check-circle text-success me-2"></i>Corporate Environmental Training</h6>
                            <p class="text-muted">Provided environmental management and sustainable development training for 15 companies, helping them develop and implement environmental strategies to reduce resource consumption and waste emissions.</p>
                        </div>
                        <div class="report-item mb-4">
                            <h6 class="fw-bold"><i class="fas fa-check-circle text-success me-2"></i>Public Environmental Activities</h6>
                            <p class="text-muted">Organized 8 large-scale environmental volunteer activities, including beach clean-ups, tree planting, and waste collection, with over 1,200 volunteers participating.</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Our Values Section -->
<section class="py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="section-title text-center">Our Values</h2>
                <p class="text-muted">We adhere to the following core values, guiding our educational practices and platform development</p>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="value-icon mb-3">
                            <i class="fas fa-leaf fa-3x text-success"></i>
                        </div>
                        <h5 class="card-title">Environment First</h5>
                        <p class="card-text text-muted">We prioritize environmental protection, with all decisions and actions guided by the principle of reducing environmental impact.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="value-icon mb-3">
                            <i class="fas fa-book-open fa-3x text-primary"></i>
                        </div>
                        <h5 class="card-title">Educational Innovation</h5>
                        <p class="card-text text-muted">We continuously explore innovative educational methods to make environmental knowledge more accessible and applicable.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="value-icon mb-3">
                            <i class="fas fa-users fa-3x text-warning"></i>
                        </div>
                        <h5 class="card-title">Community Engagement</h5>
                        <p class="card-text text-muted">We encourage community participation and collective action, because environmental protection requires everyone's joint efforts.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="value-icon mb-3">
                            <i class="fas fa-globe-asia fa-3x text-info"></i>
                        </div>
                        <h5 class="card-title">Global Perspective</h5>
                        <p class="card-text text-muted">We view environmental issues from a global perspective, sharing international best practices and innovative solutions.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Partners Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="section-title text-center">Our Partners</h2>
                <p class="text-muted">Thanks to these organizations and institutions for their support of environmental education</p>
            </div>
        </div>
        <div class="partners-container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="partners-grid">
                        <div class="partner-item">
                            <img src="<?= base_url('assets/images/WWF.png') ?>" alt="World Wildlife Fund" class="img-fluid">
                            <div class="partner-overlay">
                                <h5>World Wildlife Fund</h5>
                                <p>Dedicated to wildlife conservation and reducing human impact on the environment</p>
                            </div>
                        </div>
                        <div class="partner-item">
                            <img src="<?= base_url('assets/images/greenpeace.jpg') ?>" alt="Greenpeace" class="img-fluid">
                            <div class="partner-overlay">
                                <h5>Greenpeace</h5>
                                <p>International organization focused on environmental protection and sustainable development</p>
                            </div>
                        </div>
                        
                        <div class="partner-item">
                            <img src="<?= base_url('assets/images/UNEP.png') ?>" alt="United Nations Environment Programme" class="img-fluid">
                            <div class="partner-overlay">
                                <h5>United Nations Environment Programme</h5>
                                <p>Main coordinating body for United Nations environmental activities</p>
                            </div>
                        </div>
                        
                        <div class="partner-item">
                            <img src="<?= base_url('assets/images/CACE.png') ?>" alt="Circular Economy Association" class="img-fluid">
                            <div class="partner-overlay">
                                <h5>Circular Economy Association</h5>
                                <p>Promotes resource recycling and sustainable production and consumption patterns</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-5 bg-success text-white">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h2 class="mb-4">Join Our Environmental Action</h2>
                <p class="mb-4">Register as a member of ours to get professional environmental recycling knowledge, and work together with like-minded partners to contribute to the sustainable development of the planet.</p>
                <div class="d-flex justify-content-center">
                    <a href="<?= base_url('auth/register') ?>" class="btn btn-light btn-lg me-3">Register Now</a>
                    <a href="<?= base_url('contact') ?>" class="btn btn-outline-light btn-lg">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* About Hero Section */
.about-hero-section {
    position: relative;
    height: 50vh;
    min-height: 300px;
    background-image: url('https://images.unsplash.com/photo-1493246507139-91e8fad9978e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');
    background-size: cover;
    background-position: center;
    color: white;
    display: flex;
    align-items: center;
    text-align: center;
    margin-bottom: 2rem;
}

.about-hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.6);
    display: flex;
    align-items: center;
}

/* Value Icon */
.value-icon {
    height: 80px;
    width: 80px;
    margin: 0 auto;
    background-color: rgba(var(--bs-light-rgb), 0.5);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Partner Logos */
.partner-logo {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s;
}

.grayscale {
    filter: grayscale(100%);
    opacity: 0.7;
    transition: all 0.3s;
}

.grayscale:hover {
    filter: grayscale(0%);
    opacity: 1;
}

/* Achievements */
.achievement-item {
    padding: 2rem;
    border-radius: 0.5rem;
    background-color: white;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    transition: transform 0.3s;
}

.achievement-item:hover {
    transform: translateY(-5px);
}

/* Environmental Data Statistics */
.eco-stat {
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    transition: all 0.3s ease;
}

.eco-stat:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
}

.eco-icon {
    height: 70px;
    width: 70px;
    margin: 0 auto;
    background-color: rgba(40, 167, 69, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.counter {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

/* Social Responsibility Report */
.report-item {
    border-left: 3px solid #28a745;
    padding-left: 1.5rem;
}

/* Partners Section */
.partners-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.partner-item {
    position: relative;
    background-color: white;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    height: 150px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 15px;
}

.partner-item img {
    max-height: 80px;
    max-width: 100%;
    transition: all 0.3s ease;
}

.partner-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.partner-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: rgba(40, 167, 69, 0.9);
    color: white;
    padding: 15px;
    transform: translateY(100%);
    transition: transform 0.3s ease;
}

.partner-item:hover .partner-overlay {
    transform: translateY(0);
}

.partner-overlay h5 {
    margin-bottom: 5px;
    font-size: 16px;
    font-weight: 600;
}

.partner-overlay p {
    margin-bottom: 0;
    font-size: 12px;
    opacity: 0.9;
}

@media (max-width: 768px) {
    .partners-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 480px) {
    .partners-grid {
        grid-template-columns: 1fr;
    }
}
</style>
<?= $this->endSection() ?> 