<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="certificate-container bg-white p-5 shadow-lg position-relative">
                <!-- Decorative Elements -->
                <div class="certificate-decoration position-absolute top-0 start-0 w-100 h-100">
                    <div class="certificate-border position-absolute top-0 start-0 w-100 h-100 border border-4 border-primary m-3" style="pointer-events: none;"></div>
                    <div class="certificate-corner-tl position-absolute top-0 start-0 border-top border-start border-5 border-primary" style="width: 50px; height: 50px;"></div>
                    <div class="certificate-corner-tr position-absolute top-0 end-0 border-top border-end border-5 border-primary" style="width: 50px; height: 50px;"></div>
                    <div class="certificate-corner-bl position-absolute bottom-0 start-0 border-bottom border-start border-5 border-primary" style="width: 50px; height: 50px;"></div>
                    <div class="certificate-corner-br position-absolute bottom-0 end-0 border-bottom border-end border-5 border-primary" style="width: 50px; height: 50px;"></div>
                </div>
                
                <!-- Certificate Content -->
                <div class="certificate-content text-center py-4 position-relative">
                    <!-- Certificate Header -->
                    <div class="certificate-header mb-4">
                        <div class="certificate-logo mb-3">
                            <img src="<?= base_url('assets/images/logo.png') ?>" alt="Logo" class="img-fluid" style="max-height: 80px;">
                        </div>
                        <p class="certificate-subtitle fs-5 text-muted">Environmental Recycling Learning Platform</p>
                        <h2 class="certificate-title fw-bold text-primary">Certificate of Completion</h2>
                    </div>
                    
                    <!-- Certificate Body -->
                    <div class="certificate-body mb-5">
                        <p class="fs-5 mb-3">This certifies that</p>
                        <h3 class="certificate-name display-6 fw-bold mb-3"><?= $certificate['user_name'] ?></h3>
                        <p class="fs-5 mb-3">has successfully completed the course</p>
                        <h4 class="certificate-course fw-bold mb-4 text-primary"><?= $certificate['course_title'] ?></h4>
                        <p class="certificate-description mb-3">
                            This student has achieved a score of <span class="fw-bold"><?= number_format($certificate['score'], 1) ?>%</span> in the course quiz,
                            demonstrating understanding and mastery of environmental recycling knowledge.
                        </p>
                    </div>
                    
                    <!-- Certificate Footer -->
                    <div class="certificate-footer">
                        <div class="row align-items-end">
                            <div class="col-md-4">
                                <div class="qr-code">
                                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=<?= base_url('certificates/verify/' . $certificate['certificate_number']) ?>" alt="QR Code" class="img-fluid">
                                    <p class="small mt-2">Scan to verify</p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="text-center">
                                    <div class="certificate-date mb-2"><?= date('F j, Y', strtotime($certificate['created_at'])) ?></div>
                                    <div class="certificate-line border-top border-dark w-75 mx-auto"></div>
                                    <div class="certificate-label small">Issue Date</div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="text-center">
                                    <div class="signature">
                                        <img src="<?= base_url('assets/images/signature.png') ?>" alt="Signature" class="img-fluid mb-2" style="max-height: 60px;">
                                        <p class="mb-0 fw-bold">Environmental Recycling Learning Platform</p>
                                        <p class="small text-muted">Certificate No: <?= $certificate['certificate_number'] ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Action Buttons -->
            <div class="text-center mt-4">
                <a href="<?= base_url('certificates/download/' . $certificate['id']) ?>" class="btn btn-primary me-2">
                    <i class="fas fa-download me-2"></i> Download Certificate
                </a>
                <a href="<?= base_url('dashboard') ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<style>
    .certificate-container {
        overflow: hidden;
        background-color: #fff;
    }
    
    .certificate-title {
        color: #0d6efd;
    }
    
    .certificate-name {
        font-family: 'Times New Roman', Times, serif;
    }
    
    @media print {
        body { margin: 0; padding: 20px; }
        .certificate-container { border: 2px solid #0d6efd; page-break-inside: avoid; }
        .action-buttons { display: none; }
    }
</style>
<?= $this->endSection() ?>