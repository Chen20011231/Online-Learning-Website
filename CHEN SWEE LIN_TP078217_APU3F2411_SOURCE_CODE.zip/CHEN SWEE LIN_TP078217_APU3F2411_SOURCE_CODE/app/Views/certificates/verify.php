<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-shield-alt me-2"></i> Certificate Verification</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($isValid) && $isValid): ?>
                        <!-- Valid Certificate -->
                        <div class="text-center mb-4">
                            <div class="verification-success mb-3">
                                <i class="fas fa-check-circle fa-5x text-success"></i>
                            </div>
                            <h3 class="text-success">Certificate Verification Successful</h3>
                            <p class="text-muted">This is a valid certificate issued by the Environmental Recycling Learning Platform</p>
                        </div>
                        
                        <div class="certificate-details p-4 border rounded bg-light mb-4">
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Certificate Number:</div>
                                <div class="col-md-8"><?= $certificate['certificate_number'] ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Student Name:</div>
                                <div class="col-md-8"><?= $certificate['user_name'] ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Course Title:</div>
                                <div class="col-md-8"><?= $certificate['course_title'] ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Issue Date:</div>
                                <div class="col-md-8"><?= date('F d, Y', strtotime($certificate['issue_date'])) ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Quiz Score:</div>
                                <div class="col-md-8">
                                    <?php 
                                    $scoreClass = '';
                                    if ($certificate['score'] >= 80) {
                                        $scoreClass = 'text-success';
                                    } elseif ($certificate['score'] >= 60) {
                                        $scoreClass = 'text-primary';
                                    } else {
                                        $scoreClass = 'text-danger';
                                    }
                                    ?>
                                    <span class="<?= $scoreClass ?> fw-bold"><?= round($certificate['score'], 0) ?>%</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <a href="<?= base_url('courses/certificate/' . $certificate['id']) ?>" class="btn btn-primary">
                                <i class="fas fa-eye me-1"></i> View Full Certificate
                            </a>
                        </div>
                    <?php else: ?>
                        <!-- Certificate Verification Form -->
                        <div class="text-center mb-4">
                            <i class="fas fa-certificate fa-4x text-primary mb-3"></i>
                            <h3>Verify Certificate Authenticity</h3>
                            <p class="text-muted">Enter the certificate number to verify its authenticity</p>
                        </div>
                        
                        <?php if (session()->getFlashdata('error')): ?>
                            <div class="alert alert-danger">
                                <?= session()->getFlashdata('error') ?>
                            </div>
                        <?php endif; ?>
                        
                        <form action="<?= base_url('courses/verifyCertificate') ?>" method="get">
                            <div class="mb-4">
                                <label for="number" class="form-label">Certificate Number</label>
                                <input type="text" class="form-control form-control-lg" id="number" name="number" placeholder="Enter certificate number, e.g.: CERT-123-456-789" required>
                                <div class="form-text">The certificate number is usually displayed at the bottom or top right corner of the certificate</div>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-search me-1"></i> Verify Certificate
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Certificate Verification Information -->
            <div class="card mt-4">
                <div class="card-body">
                    <h5><i class="fas fa-info-circle me-2"></i> About Certificate Verification</h5>
                    <p class="mb-0">All certificates from the Environmental Recycling Learning Platform can be verified through this page. Each certificate has a unique certificate number that can be used to verify the validity and authenticity of the certificate. If you have any questions, please contact our customer service team.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .verification-success {
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% {
            transform: scale(1);
            opacity: 1;
        }
        50% {
            transform: scale(1.05);
            opacity: 0.8;
        }
        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
<?= $this->endSection() ?> 