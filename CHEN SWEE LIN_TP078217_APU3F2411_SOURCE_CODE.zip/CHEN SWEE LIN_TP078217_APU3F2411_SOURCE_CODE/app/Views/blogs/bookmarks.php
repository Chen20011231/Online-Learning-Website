<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- My Blog Bookmarks Page Header -->
<div class="page-header py-4" style="background-color: #f8f9fa;">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= base_url() ?>" class="text-decoration-none"><i class="fas fa-home"></i> Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url('blogs') ?>" class="text-decoration-none">Blogs</a></li>
                <li class="breadcrumb-item active" aria-current="page">My Bookmarks</li>
            </ol>
        </nav>
    </div>
</div>

<!-- My Blog Bookmarks Content Area -->
<div class="container py-5">
    <!-- Bookmarks Page Title and Icon -->
    <div class="text-center mb-5">
        <div class="bookmark-icon mb-3">
            <i class="fas fa-bookmark fa-3x text-success"></i>
        </div>
        <h1 class="fw-bold">My Blog Bookmarks</h1>
        <p class="text-muted">View your bookmarked environmental blog articles</p>
    </div>
    
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <span class="badge bg-success rounded-pill py-2 px-3 fs-6">
                        <i class="fas fa-bookmark me-1"></i> 
                        Total <?= count($bookmarkedBlogs ?? []) ?> bookmarks
                    </span>
                </div>
                <a href="<?= base_url('blogs') ?>" class="btn btn-outline-success">
                    <i class="fas fa-search me-1"></i> Browse More Blogs
                </a>
            </div>
            
            <?php if (empty($bookmarkedBlogs)): ?>
            <div class="empty-state text-center py-5">
                <div class="empty-state-icon mb-4">
                    <i class="fas fa-bookmark fa-5x text-muted opacity-25"></i>
                </div>
                <h3>You haven't bookmarked any blogs yet</h3>
                <p class="text-muted mb-4">Browse blogs and click the "Bookmark" button to add blogs to your bookmarks</p>
                <a href="<?= base_url('blogs') ?>" class="btn btn-success px-4 py-2">
                    <i class="fas fa-search me-2"></i> Browse Blog Articles
                </a>
            </div>
            <?php else: ?>
            
            <div class="row g-4">
                <?php foreach ($bookmarkedBlogs as $blog): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 border-0 shadow-sm rounded-4 blog-card overflow-hidden">
                        <div class="position-relative">
                            <?php if (!empty($blog['image'])): ?>
                            <img src="<?= base_url('uploads/blogs/' . $blog['image']) ?>" class="card-img-top" alt="<?= $blog['title'] ?>" style="height: 200px; object-fit: cover;">
                            <?php else: ?>
                            <img src="<?= base_url('assets/images/blogb.jpg') ?>" class="card-img-top" alt="Default Blog Image" style="height: 200px; object-fit: cover;">
                            <?php endif; ?>
                            <div class="bookmark-ribbon">
                                <i class="fas fa-bookmark"></i>
                            </div>
                            <div class="blog-date">
                                <span class="day"><?= date('d', strtotime($blog['created_at'])) ?></span>
                                <span class="month"><?= date('M', strtotime($blog['created_at'])) ?></span>
                            </div>
                        </div>
                        
                        <div class="card-body p-4">
                            <h5 class="card-title fw-bold mb-3"><?= $blog['title'] ?></h5>
                            <p class="card-text text-muted mb-3"><?= substr(strip_tags($blog['content']), 0, 100) ?>...</p>
                            
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="badge bg-light text-success">
                                    <i class="fas fa-leaf me-1"></i> Environmental Blog
                                </span>
                                <span class="text-muted small">
                                    <i class="fas fa-calendar-alt me-1"></i> <?= date('Y-m-d', strtotime($blog['created_at'])) ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="card-footer bg-white border-0 p-4 pt-0">
                            <div class="d-flex justify-content-between">
                                <a href="<?= base_url('blogs/view/' . $blog['id']) ?>" class="btn btn-outline-primary">
                                    <i class="fas fa-eye me-1"></i> View Blog
                                </a>
                                <button class="btn btn-outline-danger remove-bookmark" data-blog-id="<?= $blog['id'] ?>" data-blog-title="<?= $blog['title'] ?>">
                                    <i class="fas fa-trash-alt me-1"></i> Remove Bookmark
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Toast notification for bookmark actions -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
    <div id="bookmarkToast" class="toast align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas fa-check-circle me-2"></i> <span id="toast-message">Operation Successful</span>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>

<style>
/* Blog Card Styles */
.blog-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    position: relative;
}

.blog-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
}

.blog-card:hover .card-img-top {
    transform: scale(1.05);
}

.card-img-top {
    transition: transform 0.5s ease;
}

/* Bookmark Icon Styles */
.bookmark-icon {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background-color: rgba(25, 135, 84, 0.1);
    color: #198754;
}

/* Bookmark Ribbon Styles */
.bookmark-ribbon {
    position: absolute;
    top: 0;
    right: 20px;
    color: #FFC107;
    font-size: 24px;
    filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
}

/* Date Label Styles */
.blog-date {
    position: absolute;
    bottom: 0;
    left: 20px;
    background-color: #198754;
    color: white;
    padding: 5px 15px;
    border-radius: 8px 8px 0 0;
    text-align: center;
    line-height: 1.2;
}

.blog-date .day {
    display: block;
    font-size: 18px;
    font-weight: bold;
}

.blog-date .month {
    display: block;
    font-size: 12px;
    text-transform: uppercase;
}

/* Empty State Styles */
.empty-state {
    padding: 60px 0;
    background-color: #f8f9fa;
    border-radius: 12px;
}

.empty-state-icon {
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0px); }
}

/* Button Hover Effects */
.btn-outline-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.btn-outline-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle remove bookmark button click events
    const removeButtons = document.querySelectorAll('.remove-bookmark');
    removeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const blogId = this.dataset.blogId;
            const blogTitle = this.dataset.blogTitle;
            
            if (confirm(`Are you sure you want to remove "${blogTitle}" from your bookmarks?`)) {
                // Send AJAX request to remove bookmark
                fetch('<?= base_url('blogs/unbookmark/') ?>' + blogId, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update toast message
                        const toastMessage = document.getElementById('toast-message');
                        if (toastMessage) {
                            toastMessage.textContent = data.message;
                        }
                        
                        // Show toast
                        const toastContainer = document.getElementById('bookmarkToast');
                        if (toastContainer) {
                            const toast = new bootstrap.Toast(toastContainer, {
                                autohide: true,
                                delay: 3000
                            });
                            toast.show();
                        }
                        
                        // Remove card with animation
                        const card = this.closest('.col-md-6');
                        if (card) {
                            card.style.transform = 'scale(0.8)';
                            card.style.opacity = '0';
                            card.style.transition = 'all 0.5s ease';
                            setTimeout(() => {
                                card.remove();
                                
                                // Update bookmark count
                                const bookmarkCount = document.querySelector('.badge.bg-success.rounded-pill');
                                if (bookmarkCount) {
                                    const currentCount = parseInt(bookmarkCount.textContent.match(/\d+/)[0]) - 1;
                                    bookmarkCount.innerHTML = `<i class="fas fa-bookmark me-1"></i> Total ${currentCount} bookmarks`;
                                }
                                
                                // Check if there are still blog cards
                                const remainingCards = document.querySelectorAll('.blog-card');
                                if (remainingCards.length === 0) {
                                    // If no cards left, show empty state
                                    const container = document.querySelector('.row.g-4');
                                    if (container) {
                                        container.parentElement.innerHTML = `
                                            <div class="empty-state text-center py-5">
                                                <div class="empty-state-icon mb-4">
                                                    <i class="fas fa-bookmark fa-5x text-muted opacity-25"></i>
                                                </div>
                                                <h3>You haven't bookmarked any blogs yet</h3>
                                                <p class="text-muted mb-4">Browse blogs and click the "Bookmark" button to add blogs to your bookmarks</p>
                                                <a href="<?= base_url('blogs') ?>" class="btn btn-success px-4 py-2">
                                                    <i class="fas fa-search me-2"></i> Browse Blog Articles
                                                </a>
                                            </div>
                                        `;
                                    }
                                }
                            }, 500);
                        }
                    } else {
                        alert('Removal failed: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error removing bookmark:', error);
                    alert('Removal failed, please try again later.');
                });
            }
        });
    });
});
</script>
<?= $this->endSection() ?> 