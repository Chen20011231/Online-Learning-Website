<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Blog Header -->
<div class="blog-header bg-light py-4 mb-5">
<div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= base_url() ?>" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url('blogs') ?>" class="text-decoration-none">Blogs</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $blog['title'] ?></li>
        </ol>
    </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <!-- Main Content Column -->
        <div class="col-lg-8">
            <article class="blog-post">
                <!-- Article Header -->
                <header class="mb-4">
                    <h1 class="fw-bold mb-3 display-5"><?= $blog['title'] ?></h1>
                    <div class="d-flex align-items-center mb-4">
                        
                        <div>
                            <h6 class="mb-1"><?= $author ?></h6>
                            <div class="text-muted small">
                        <i class="fas fa-calendar-alt me-1"></i> <?= date('F d, Y', strtotime($blog['created_at'])) ?>
                                <span class="mx-2">•</span>
                                <i class="fas fa-clock me-1"></i> 15 minute read
                            </div>
                        </div>
                        <div class="ms-auto d-flex">
                            <button id="bookmarkButton" class="btn <?= $isBookmarked ? 'btn-warning' : 'btn-light' ?> rounded-3 shadow-sm" style="background-color: #f0f0f0;" data-blog-id="<?= $blog['id'] ?>">
                                <i class="<?= $isBookmarked ? 'fas' : 'far' ?> fa-bookmark me-1"></i> 
                                <span id="bookmark-text"><?= $isBookmarked ? 'Remove Bookmark' : 'Bookmark Blog' ?></span>
                            </button>
                        </div>
                    </div>
                </header>

                <!-- Featured Image -->
                <?php if (!empty($blog['image'])): ?>
                <figure class="blog-featured-image mb-5">
                    <img class="img-fluid rounded-4 shadow" src="<?= base_url('uploads/blogs/' . $blog['image']) ?>" alt="<?= $blog['title'] ?>">
                </figure>
                <?php endif; ?>

                <!-- Article Content -->
                <section class="blog-content mb-5">
                    <h4 class="fw-bold mb-4"><i class="fas fa-file-alt me-2 text-success"></i>Blog Content</h4>
                    <div class="card border-0 shadow-sm">
                        <div class="card-body p-md-5">
                            <div class="blog-text">
                            <?= $blog['content'] ?>
                            </div>
                            
                            
                        </div>
                    </div>
                </section>
                
                
            
            <!-- Comments Section -->
                <section class="comments mb-5">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-light border-0 py-3">
                            <h4 class="mb-0"><i class="fas fa-comments me-2"></i> Comments (<span id="commentCount">0</span>)</h4>
                    </div>
                        <div class="card-body p-4">
                        <?php if (session()->get('isLoggedIn')): ?>
                        <form id="commentForm" class="mb-4">
                            <div class="mb-3">
                                <label for="comment" class="form-label">Leave a Comment</label>
                                    <textarea class="form-control" id="comment" name="comment" rows="4" placeholder="Share your thoughts..."></textarea>
                                </div>
                                <div class="d-flex justify-content-end align-items-center">
                                    
                                    <div>
                                        <?php if (session()->get('role') == 'admin'): ?>
                                        
                                        <?php endif; ?>
                                        <button type="submit" id="submitComment" class="btn btn-success">
                                            <i class="fas fa-paper-plane me-1"></i> Submit Comment
                                        </button>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <small class="text-muted"><i class="fas fa-info-circle me-1"></i> You can only delete comments and replies that you've posted</small>
                                    <input type="hidden" id="currentUserId" value="<?= session()->get('id') ?? '' ?>">
                            </div>
                        </form>
                        <?php else: ?>
                            <div class="alert alert-info d-flex align-items-center">
                                <i class="fas fa-info-circle fa-lg me-3"></i>
                                <div>
                            Please <a href="<?= base_url('auth/login') ?>" class="alert-link">login</a> to leave a comment.
                                </div>
                        </div>
                        <?php endif; ?>
                        
                            <!-- Comments display area -->
                            <div id="commentsContainer">
                                <!-- No comments placeholder (will be hidden when comments are added) -->
                                <div id="noCommentsMessage" class="text-center py-5">
                                    <i class="fas fa-comments fa-4x text-muted mb-3 opacity-50"></i>
                                    <h5>No Comments Yet</h5>
                            <p class="text-muted">Be the first to comment!</p>
                                </div>
                                
                                <!-- Comments will be added here by JavaScript -->
                                <div id="commentsList"></div>
                        </div>
                    </div>
                </div>
            </section>
            </article>
        </div>
        
        <!-- Sidebar Column -->
        <div class="col-lg-4">
            
            <!-- Popular Posts -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-3"><i class="fas fa-fire-alt me-2 text-success"></i> Popular Articles</h5>
                    <div class="popular-posts">
                        <?php 
                        // Get popular blog posts (except current post)
                        $blogModel = new \App\Models\BlogModel();
                        $popularBlogs = $blogModel->where('id !=', $blog['id'])
                                                 ->orderBy('created_at', 'DESC')
                                                 ->limit(3)
                                                 ->find();
                        
                        if (empty($popularBlogs)): ?>
                            <div class="text-center py-3">
                                <p class="text-muted mb-0">No popular articles available</p>
                </div>
                        <?php else: ?>
                            <?php foreach($popularBlogs as $index => $popularBlog): 
                                // Check if this is the last article
                                $isLast = $index === count($popularBlogs) - 1;
                            ?>
                            <a href="<?= base_url('blogs/view/' . $popularBlog['id']) ?>" class="text-decoration-none text-dark">
                                <div class="d-flex popular-post-item <?= !$isLast ? 'mb-3 pb-3 border-bottom' : '' ?>">
                                    <div class="flex-shrink-0" style="width: 80px; height: 80px;">
                                        <?php if (!empty($popularBlog['image'])): ?>
                                        <img src="<?= base_url('uploads/blogs/' . $popularBlog['image']) ?>" class="img-fluid rounded" alt="<?= $popularBlog['title'] ?>" style="width: 80px; height: 80px; object-fit: cover;">
                                        <?php else: ?>
                                        <img src="<?= base_url('assets/images/blogb.jpg') ?>" class="img-fluid rounded" alt="Default Blog Image" style="width: 80px; height: 80px; object-fit: cover;">
                                        <?php endif; ?>
                        </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-1 popular-post-title"><?= $popularBlog['title'] ?></h6>
                                        <p class="text-muted small mb-1">
                                            <i class="far fa-calendar-alt me-1"></i> <?= date('F d, Y', strtotime($popularBlog['created_at'])) ?>
                                        </p>
                                        <p class="small text-muted mb-0 d-none d-sm-block">
                                            <?= substr(strip_tags($popularBlog['content']), 0, 40) . '...' ?>
                                        </p>
                </div>
            </div>
                            </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            </div>
            
            
        </div>
    </div>
</div>

<!-- Back to Top Button -->
<a id="back-to-top" href="#" class="btn btn-success btn-lg back-to-top rounded-circle" role="button">
    <i class="fas fa-arrow-up"></i>
</a>

<!-- CSS Styles -->
<style>
    /* Blog content styling */
    .blog-text {
        font-size: 1.1rem;
        line-height: 1.8;
    }
    
    .blog-text h2 {
        margin-top: 2rem;
        margin-bottom: 1rem;
        font-weight: 600;
    }
    
    .blog-text p {
        margin-bottom: 1.5rem;
    }
    
    /* Back to top button */
    .back-to-top {
        position: fixed;
        bottom: 25px;
        right: 25px;
        display: none;
        width: 45px;
        height: 45px;
        padding: 0;
        text-align: center;
        line-height: 45px;
        z-index: 99;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    /* Card hover effects */
    .card {
        transition: transform 0.2s, box-shadow 0.2s;
    }
    
    .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
    }
    
    /* Comment styles */
    .comment-item {
        transition: background-color 0.2s;
    }
    
    .comment-item:hover {
        background-color: #f8f9fa;
    }
    
    .comment-item:last-child {
        border-bottom: none !important;
        margin-bottom: 0 !important;
        padding-bottom: 0 !important;
    }
    
    .like-button:hover, .reply-button:hover {
        color: #198754 !important;
    }
    
    .like-button.active {
        color: #198754 !important;
    }
    
    #commentForm .form-control:focus {
        border-color: #198754;
        box-shadow: 0 0 0 0.25rem rgba(25, 135, 84, 0.25);
    }
    
    /* Delete button styles */
    .delete-button, .delete-reply-button {
        opacity: 1;
        transition: all 0.2s;
        padding: 0.25rem 0.5rem;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 0.25rem;
        background-color: rgba(220, 53, 69, 0.1);
        color: #dc3545 !important;
        font-size: 0.8rem;
    }
    
    .delete-button:hover, .delete-reply-button:hover {
        background-color: rgba(220, 53, 69, 0.15);
        color: #dc3545 !important;
        text-decoration: none;
    }
    
    .delete-button i, .delete-reply-button i {
        margin-right: 4px;
    }
    
    .comment-item, .reply-item {
        transition: opacity 0.3s ease, transform 0.3s ease;
    }
    
    /* Comment deletion animation */
    .deleting {
        animation: fadeOutUp 0.3s forwards;
    }
    
    @keyframes fadeOutUp {
        from {
            opacity: 1;
            transform: translateY(0);
        }
        to {
            opacity: 0;
            transform: translateY(-10px);
        }
    }
    
    /* Reply styles */
    .replies-container {
        border-color: rgba(25, 135, 84, 0.3) !important;
    }
    
    .reply-item {
        position: relative;
        padding: 0.75rem;
        border-radius: 0.5rem;
        transition: background-color 0.2s;
    }
    
    .reply-item:hover {
        background-color: #f8f9fa;
    }
    
    .reply-item:last-child {
        margin-bottom: 0 !important;
    }
    
    /* Reply mode */
    #commentForm.replying {
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
        border-left: 4px solid #198754;
        margin-bottom: 20px;
        transition: all 0.3s;
    }
    
    #commentForm.replying label {
        color: #198754;
        font-weight: 500;
    }
    
    #commentForm.replying .form-control {
        border-left: 3px solid #198754;
        background-color: #fff;
    }
    
    #cancelReply {
        transition: all 0.3s;
        border: 1px solid #dee2e6;
        background-color: #f8f9fa;
        color: #6c757d;
    }
    
    #cancelReply:hover {
        background-color: #e9ecef;
        color: #495057;
        border-color: #ced4da;
    }
    
    /* Popular Articles and Related Articles Styles */
    .popular-post-item,
    .related-post-item {
        transition: all 0.2s ease;
        padding: 8px;
        border-radius: 8px;
    }
    .popular-post-item:hover,
    .related-post-item:hover {
        transform: translateX(5px);
        background-color: rgba(25, 135, 84, 0.05);
    }
    .popular-post-item:hover .popular-post-title,
    .related-post-item:hover .related-title {
        color: #198754;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Back to top button functionality
        window.addEventListener('scroll', function() {
            const backToTopButton = document.getElementById('back-to-top');
            if (window.scrollY > 300) {
                backToTopButton.style.display = 'block';
            } else {
                backToTopButton.style.display = 'none';
            }
        });
        
        document.getElementById('back-to-top').addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({top: 0, behavior: 'smooth'});
        });
        
        // Comments functionality
        const commentForm = document.getElementById('commentForm');
        const commentsList = document.getElementById('commentsList');
        const noCommentsMessage = document.getElementById('noCommentsMessage');
        const commentCount = document.getElementById('commentCount');
        const blogId = <?= $blog['id'] ?? 0 ?>;
        let replyingTo = null; // Track which comment we're replying to
        
        // Set current login user ID - use server-provided real user ID first
        let CURRENT_USER_ID = document.getElementById('currentUserId')?.value || '';
        
        // If server doesn't provide ID (not logged in), use local storage ID
        if (!CURRENT_USER_ID) {
            CURRENT_USER_ID = getUserId();
        }
        
         console.log('Current user ID:', CURRENT_USER_ID); // Debug output current user ID
        
        // Load comments from localStorage
        loadComments();
        
        // If comment form exists (user is logged in)
        if (commentForm) {
            commentForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const commentText = document.getElementById('comment').value.trim();
                if (!commentText) {
                    alert('Please enter a comment');
                    return;
                }
                
                if (replyingTo) {
                    // Add as a reply
                    addReply(commentText, replyingTo);
                    
                    // Reset reply state
                    cancelReply();
                } else {
                    // Add as a new comment
                    addComment(commentText);
                }
                
                // Clear form
                document.getElementById('comment').value = '';
            });
        }
        
        // Add reply functionality
        function setupReplyButton(button, commentId) {
            button.addEventListener('click', function() {
                replyingTo = commentId;
                
                // Update form appearance
                const form = document.getElementById('commentForm');
                const commentTextarea = document.getElementById('comment');
                const label = form.querySelector('label[for="comment"]');
                
                // Find original comment author
                const comments = getCommentsFromStorage();
                const originalComment = findCommentById(comments, commentId);
                
                if (originalComment) {
                    // Smooth transition to reply mode
                    label.innerHTML = `Reply to <strong>${originalComment.author}</strong>:`;
                    
                    // Create cancel button if it doesn't exist
                    if (!document.getElementById('cancelReply')) {
                        const cancelButton = document.createElement('button');
                        cancelButton.id = 'cancelReply';
                        cancelButton.className = 'btn btn-sm btn-outline-secondary rounded-pill me-2';
                        cancelButton.innerHTML = '<i class="fas fa-times me-1"></i> Cancel Reply';
                        cancelButton.addEventListener('click', function(e) {
                            e.preventDefault();
                            cancelReply();
                        });
                        
                        // Add cancel button before submit button
                        const submitButton = form.querySelector('[type="submit"]');
                        submitButton.parentNode.insertBefore(cancelButton, submitButton);
                    }
                    
                    // Add replying class with a slight delay for animation effect
                    setTimeout(() => {
                        form.classList.add('replying');
                        // Scroll to form and focus textarea
                        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        commentTextarea.focus();
                    }, 50);
                }
            });
        }
        
        // Cancel reply mode
        function cancelReply() {
            replyingTo = null;
            
            const form = document.getElementById('commentForm');
            if (form) {
                const label = form.querySelector('label[for="comment"]');
                
                // Remove cancel button with fade effect
                const cancelButton = document.getElementById('cancelReply');
                if (cancelButton) {
                    cancelButton.style.opacity = '0';
                    setTimeout(() => {
                        cancelButton.remove();
                    }, 200);
                }
                
                // Smooth transition back to normal mode
                form.style.opacity = '0.8';
                setTimeout(() => {
                    label.innerHTML = 'Leave a Comment';
                    form.classList.remove('replying');
                    form.style.opacity = '1';
                }, 200);
            }
        }
        
        function addComment(text) {
            // Use global constant CURRENT_USER_ID as user identifier
            const currentUserId = CURRENT_USER_ID;
            console.log('Adding comment as user:', currentUserId); // Debug log

            // Create comment data
            const commentData = {
                id: Date.now(), // Use timestamp as unique ID
                text: text,
                author: '<?= session()->get('name') ?? "Current User" ?>',
                date: new Date().toISOString(),
                likes: 0,
                likedBy: [], // Track users who liked this comment
                replies: [], // Store replies to this comment
                userId: currentUserId // Store the user ID who created this comment
            };
            
            console.log('Created comment with user ID:', commentData.userId); // Debug user ID storage
            
            // Add to localStorage
            const comments = getCommentsFromStorage();
            comments.push(commentData);
            saveCommentsToStorage(comments);
            
            // Add to DOM
            renderComment(commentData);
            
            // Update count and hide no comments message
            updateCommentCount();
        }
        
        function addReply(text, parentId) {
            // Use global constant CURRENT_USER_ID as user identifier
            const currentUserId = CURRENT_USER_ID;
            console.log('Adding reply as user:', currentUserId); // Debug log

            const comments = getCommentsFromStorage();
            const parentComment = findCommentById(comments, parentId);
            
            if (!parentComment) return;
            
            // Create reply data
            const replyData = {
                id: Date.now(),
                text: text,
                author: '<?= session()->get('name') ?? "Current User" ?>',
                date: new Date().toISOString(),
                likes: 0,
                likedBy: [],
                isReply: true,
                parentId: parentId,
                userId: currentUserId // Store the user ID who created this reply
            };
            
            // Add to parent comment's replies
            if (!parentComment.replies) parentComment.replies = [];
            parentComment.replies.push(replyData);
            
            saveCommentsToStorage(comments);
            
            // Render the reply
            const parentElement = document.querySelector(`.comment-item[data-id="${parentId}"]`);
            if (parentElement) {
                let repliesContainer = parentElement.querySelector('.replies-container');
                
                // Create replies container if it doesn't exist
                if (!repliesContainer) {
                    repliesContainer = document.createElement('div');
                    repliesContainer.className = 'replies-container mt-3 ms-4 ps-2 border-start border-2';
                    parentElement.appendChild(repliesContainer);
                }
                
                renderReply(replyData, repliesContainer);
            }
            
            // Update count
            updateCommentCount();
        }
        
        function renderReply(reply, container) {
            const replyDate = new Date(reply.date);
            const formattedDate = `${replyDate.getFullYear()}/${replyDate.getMonth() + 1}/${replyDate.getDate()} ${replyDate.getHours()}:${replyDate.getMinutes().toString().padStart(2, '0')}`;
            
            // Strictly compare user IDs to check if they are the same user
            const isCurrentUserReply = reply.userId && CURRENT_USER_ID && (String(reply.userId) === String(CURRENT_USER_ID));
            console.log('Rendering reply:', reply.id, 'Author ID:', reply.userId, 'Current user:', CURRENT_USER_ID, 'Can delete:', isCurrentUserReply); // Debug log
            
            const replyElement = document.createElement('div');
            replyElement.className = 'reply-item mb-3';
            replyElement.dataset.id = reply.id;
            replyElement.dataset.parentId = reply.parentId;
            replyElement.dataset.userId = reply.userId || ''; // Save user ID for debugging
            
            replyElement.innerHTML = `
                <div class="d-flex">
                    <div class="flex-shrink-0">
                        <div class="bg-light rounded-circle d-flex justify-content-center align-items-center" style="width: 35px; height: 35px;">
                            <i class="fas fa-user text-secondary small"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1 ms-2">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <h6 class="mb-0 small fw-bold">${reply.author}${isCurrentUserReply ? ' <span class="badge bg-secondary">You</span>' : ''}</h6>
                            <div>
                                <small class="text-muted">${formattedDate}</small>
                                ${isCurrentUserReply ? `
                                <button class="btn btn-sm text-danger delete-reply-button ms-2" data-id="${reply.id}" data-parent-id="${reply.parentId}" title="Delete Reply">
                                    <i class="fas fa-trash-alt small"></i> Delete
                                </button>` : ''}
                            </div>
                        </div>
                        <p class="mb-2 small">${reply.text}</p>
                        <div class="d-flex align-items-center">
                            <button class="btn btn-sm text-muted like-button small ${reply.likedBy.includes(CURRENT_USER_ID) ? 'active' : ''}" data-id="${reply.id}" data-parent-id="${reply.parentId}">
                                <i class="far ${reply.likedBy.includes(CURRENT_USER_ID) ? 'fas' : 'far'} fa-thumbs-up me-1"></i> <span class="like-count">${reply.likes}</span>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            // Add to DOM
            container.appendChild(replyElement);
            
            // Add like functionality
            const likeButton = replyElement.querySelector('.like-button');
            likeButton.addEventListener('click', function() {
                const replyId = this.dataset.id;
                const parentId = this.dataset.parentId;
                likeReply(parentId, replyId);
            });
            
            // Add delete functionality only if it's the user's reply
            if (isCurrentUserReply) {
                const deleteButton = replyElement.querySelector('.delete-reply-button');
                if (deleteButton) {
                    deleteButton.addEventListener('click', function() {
                        if (confirm('Are you sure you want to delete this reply?')) {
                            deleteReply(reply.parentId, reply.id);
                        }
                    });
                }
            }
        }
        
        function renderComment(comment) {
            const commentDate = new Date(comment.date);
            const formattedDate = `${commentDate.getFullYear()}/${commentDate.getMonth() + 1}/${commentDate.getDate()} ${commentDate.getHours()}:${commentDate.getMinutes().toString().padStart(2, '0')}`;
            
            // Strictly compare user IDs to check if they are the same user
            const isCurrentUserComment = comment.userId && CURRENT_USER_ID && (String(comment.userId) === String(CURRENT_USER_ID));
            console.log('Rendering comment:', comment.id, 'Author ID:', comment.userId, 'Current user:', CURRENT_USER_ID, 'Can delete:', isCurrentUserComment); // Debug log
            
            const commentElement = document.createElement('div');
            commentElement.className = 'comment-item border-bottom pb-3 mb-3';
            commentElement.dataset.id = comment.id;
            commentElement.dataset.userId = comment.userId || ''; // Save user ID for debugging
            
            commentElement.innerHTML = `
                <div class="d-flex">
                    <div class="flex-shrink-0">
                        <div class="bg-light rounded-circle d-flex justify-content-center align-items-center" style="width: 45px; height: 45px;">
                            <i class="fas fa-user text-secondary"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <h6 class="mb-0">${comment.author}${isCurrentUserComment ? ' <span class="badge bg-secondary">You</span>' : ''}</h6>
                            <div>
                                <small class="text-muted">${formattedDate}</small>
                                ${isCurrentUserComment ? `
                                <button class="btn btn-sm text-danger delete-button ms-2" data-id="${comment.id}" title="Delete Comment">
                                    <i class="fas fa-trash-alt"></i> Delete
                                </button>` : ''}
                            </div>
                        </div>
                        <p class="mb-2">${comment.text}</p>
                        <div class="d-flex align-items-center">
                            <button class="btn btn-sm text-muted like-button ${comment.likedBy && comment.likedBy.includes(CURRENT_USER_ID) ? 'active' : ''}" data-id="${comment.id}">
                                <i class="${comment.likedBy && comment.likedBy.includes(CURRENT_USER_ID) ? 'fas' : 'far'} fa-thumbs-up me-1"></i> <span class="like-count">${comment.likes}</span>
                            </button>
                            <button class="btn btn-sm text-muted reply-button ms-2" data-id="${comment.id}">
                                <i class="far fa-comment me-1"></i> Reply
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            // Add replies if they exist
            if (comment.replies && comment.replies.length > 0) {
                const repliesContainer = document.createElement('div');
                repliesContainer.className = 'replies-container mt-3 ms-4 ps-2 border-start border-2';
                comment.replies.forEach(reply => {
                    renderReply(reply, repliesContainer);
                });
                commentElement.appendChild(repliesContainer);
            }
            
            // Add to DOM
            commentsList.prepend(commentElement);
            
            // Hide the "no comments" message if it's visible
            noCommentsMessage.style.display = 'none';
            
            // Add like functionality
            const likeButton = commentElement.querySelector('.like-button');
            likeButton.addEventListener('click', function() {
                const commentId = this.dataset.id;
                likeComment(commentId);
            });
            
            // Add reply functionality
            const replyButton = commentElement.querySelector('.reply-button');
            setupReplyButton(replyButton, comment.id);
            
            // Add delete functionality only if it's the user's comment
            if (isCurrentUserComment) {
                const deleteButton = commentElement.querySelector('.delete-button');
                if (deleteButton) {
                    deleteButton.addEventListener('click', function() {
                        if (confirm('Are you sure you want to delete this comment?')) {
                            deleteComment(comment.id);
                        }
                    });
                }
            }
        }
        
        function likeComment(commentId) {
            const comments = getCommentsFromStorage();
            const comment = findCommentById(comments, commentId);
            
            if (comment) {
                // Use global constant CURRENT_USER_ID
                const userId = CURRENT_USER_ID;
                
                // Initialize likedBy array if it doesn't exist
                if (!comment.likedBy) comment.likedBy = [];
                
                // Check if user already liked this comment
                const alreadyLiked = comment.likedBy.includes(userId);
                
                if (alreadyLiked) {
                    // Unlike
                    comment.likes = Math.max(0, comment.likes - 1);
                    comment.likedBy = comment.likedBy.filter(id => id !== userId);
                } else {
                    // Like
                    comment.likes++;
                    comment.likedBy.push(userId);
                }
                
                saveCommentsToStorage(comments);
                
                // Update the UI
                const likeButton = document.querySelector(`.like-button[data-id="${commentId}"]`);
                const likeCount = likeButton.querySelector('.like-count');
                const likeIcon = likeButton.querySelector('i');
                
                likeCount.textContent = comment.likes;
                
                if (comment.likedBy.includes(userId)) {
                    likeButton.classList.add('active');
                    likeIcon.classList.remove('far');
                    likeIcon.classList.add('fas');
                } else {
                    likeButton.classList.remove('active');
                    likeIcon.classList.remove('fas');
                    likeIcon.classList.add('far');
                }
            }
        }
        
        function likeReply(parentId, replyId) {
            const comments = getCommentsFromStorage();
            const parentComment = findCommentById(comments, parentId);
            
            if (parentComment && parentComment.replies) {
                const reply = parentComment.replies.find(r => r.id == replyId);
                
                if (reply) {
                    // Use global constant CURRENT_USER_ID
                    const userId = CURRENT_USER_ID;
                    
                    // Initialize likedBy array if it doesn't exist
                    if (!reply.likedBy) reply.likedBy = [];
                    
                    // Check if user already liked this reply
                    const alreadyLiked = reply.likedBy.includes(userId);
                    
                    if (alreadyLiked) {
                        // Unlike
                        reply.likes = Math.max(0, reply.likes - 1);
                        reply.likedBy = reply.likedBy.filter(id => id !== userId);
                    } else {
                        // Like
                        reply.likes++;
                        reply.likedBy.push(userId);
                    }
                    
                    saveCommentsToStorage(comments);
                    
                    // Update the UI
                    const replyElement = document.querySelector(`.reply-item[data-id="${replyId}"]`);
                    if (replyElement) {
                        const likeButton = replyElement.querySelector('.like-button');
                        const likeCount = likeButton.querySelector('.like-count');
                        const likeIcon = likeButton.querySelector('i');
                        
                        likeCount.textContent = reply.likes;
                        
                        if (reply.likedBy.includes(userId)) {
                            likeButton.classList.add('active');
                            likeIcon.classList.remove('far');
                            likeIcon.classList.add('fas');
                        } else {
                            likeButton.classList.remove('active');
                            likeIcon.classList.remove('fas');
                            likeIcon.classList.add('far');
                        }
                    }
                }
            }
        }
        
        function deleteComment(commentId) {
            const comments = getCommentsFromStorage();
            const commentToDelete = findCommentById(comments, commentId);
            
            // Additional security check: ensure only comment author can delete comment
            if (!commentToDelete || String(commentToDelete.userId) !== String(CURRENT_USER_ID)) {
                console.error('Permission error: attempt to delete comment not owned by current user', commentToDelete?.userId, CURRENT_USER_ID);
                alert('You can only delete comments you posted');
                return;
            }
            
            const updatedComments = comments.filter(comment => comment.id != commentId);
            saveCommentsToStorage(updatedComments);
            
            // Remove the comment element from DOM
            const commentElement = document.querySelector(`.comment-item[data-id="${commentId}"]`);
            if (commentElement) {
                // Add fade-out effect
                    commentElement.classList.add('deleting');
                    
                setTimeout(() => {
                    commentElement.remove();
                    
                    // Show "no comments" message if there are no comments left
                    if (updatedComments.length === 0) {
                        noCommentsMessage.style.display = 'block';
                    }
                }, 300);
            }
            
            // Update comment count
            updateCommentCount();
        }
        
        function deleteReply(parentId, replyId) {
            const comments = getCommentsFromStorage();
            const parentComment = findCommentById(comments, parentId);
            
            if (parentComment && parentComment.replies) {
                // Find the reply to delete
                const replyToDelete = parentComment.replies.find(reply => reply.id == replyId);
                
                // Additional security check: ensure only reply author can delete reply
                if (!replyToDelete || String(replyToDelete.userId) !== String(CURRENT_USER_ID)) {
                    console.error('Permission error: attempt to delete reply not owned by current user', replyToDelete?.userId, CURRENT_USER_ID);
                    alert('You can only delete replies you posted');
                    return;
                }
                
                // Filter out the reply to be deleted
                parentComment.replies = parentComment.replies.filter(reply => reply.id != replyId);
                saveCommentsToStorage(comments);
                
                // Remove the reply element from DOM
                const replyElement = document.querySelector(`.reply-item[data-id="${replyId}"]`);
                if (replyElement) {
                    // Add fade-out effect
                    replyElement.classList.add('deleting');
                    
                    setTimeout(() => {
                        replyElement.remove();
                        
                        // Remove the replies container if there are no replies left
                        const repliesContainer = document.querySelector(`.comment-item[data-id="${parentId}"] .replies-container`);
                        if (repliesContainer && parentComment.replies.length === 0) {
                            repliesContainer.remove();
                        }
                    }, 300);
                }
                
                // Update comment count
                updateCommentCount();
            }
        }
        
        // Helper function to find a comment by ID
        function findCommentById(comments, id) {
            return comments.find(c => c.id == id);
        }
        
        function loadComments() {
            const comments = getCommentsFromStorage();
            
            if (comments.length > 0) {
                // Hide the "no comments" message
                noCommentsMessage.style.display = 'none';
                
                // Render all comments
                comments.forEach(comment => {
                    renderComment(comment);
                });
            }
            
            updateCommentCount();
        }
        
        function updateCommentCount() {
            const comments = getCommentsFromStorage();
            let totalCount = comments.length;
            
            // Count replies too
            comments.forEach(comment => {
                if (comment.replies && comment.replies.length) {
                    totalCount += comment.replies.length;
                }
            });
            
            commentCount.textContent = totalCount;
        }
        
        function getCommentsFromStorage() {
            const storageKey = `blog_${blogId}_comments`;
            const storedComments = localStorage.getItem(storageKey);
            
            return storedComments ? JSON.parse(storedComments) : [];
        }
        
        function saveCommentsToStorage(comments) {
            const storageKey = `blog_${blogId}_comments`;
            localStorage.setItem(storageKey, JSON.stringify(comments));
        }
        
        // Utility to get or generate a user ID
        function getUserId() {
            let userId = localStorage.getItem('blog_user_id');
            
            if (!userId) {
                // Generate a random ID if none exists
                userId = 'user_' + Math.random().toString(36).substring(2, 15) + '_' + Date.now();
                localStorage.setItem('blog_user_id', userId);
            }
            
            return userId;
        }
        
        // Debug functions to help diagnose user ID issues
        function resetUserIdForTesting() {
            localStorage.removeItem('blog_user_id');
            location.reload();
        }
        
        // Diagnostic function - clear all comments and reset
        function clearAllCommentsForTesting() {
            if (confirm('Are you sure you want to clear all comment data? This action cannot be undone.')) {
                const blogId = <?= $blog['id'] ?? 0 ?>;
                localStorage.removeItem(`blog_${blogId}_comments`);
                location.reload();
            }
        }
        
        // Export comment data for debugging
        function exportCommentsForDebugging() {
            const blogId = <?= $blog['id'] ?? 0 ?>;
            const comments = getCommentsFromStorage();
            console.log('Current comment data:', comments);
            alert(`Exported ${comments.length} comments to the console`);
        }
        
        // For debugging purposes, expose these functions to global scope
        window.debugComments = {
            reset: resetUserIdForTesting,
            clear: clearAllCommentsForTesting,
            export: exportCommentsForDebugging
        };
    });
</script>

<!-- Bookmark functionality -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const bookmarkButton = document.getElementById('bookmarkButton');
        
        if (bookmarkButton) {
            bookmarkButton.addEventListener('click', function() {
                const blogId = this.getAttribute('data-blog-id');
                const isCurrentlyBookmarked = this.classList.contains('btn-warning');
                
                // Check if user is logged in
                const isLoggedIn = <?= session()->get('isLoggedIn') ? 'true' : 'false' ?>;
                
                if (!isLoggedIn) {
                    // Show login prompt
                    alert('Please login to bookmark');
                    window.location.href = '<?= base_url('auth/login') ?>';
                    return;
                }
                
                // Perform bookmark or unbookmark operation
                const url = isCurrentlyBookmarked 
                    ? `<?= base_url('blogs/unbookmark/') ?>${blogId}`
                    : `<?= base_url('blogs/bookmark/') ?>${blogId}`;
                
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update button state
                        if (isCurrentlyBookmarked) {
                            // Unbookmark
                            bookmarkButton.classList.replace('btn-warning', 'btn-light');
                            const icon = bookmarkButton.querySelector('i');
                            if (icon) icon.className = 'far fa-bookmark me-1';
                            const textSpan = bookmarkButton.querySelector('#bookmark-text');
                            if (textSpan) textSpan.textContent = 'Bookmark Blog';
                        } else {
                            // Bookmark
                            bookmarkButton.classList.replace('btn-light', 'btn-warning');
                            const icon = bookmarkButton.querySelector('i');
                            if (icon) icon.className = 'fas fa-bookmark me-1';
                            const textSpan = bookmarkButton.querySelector('#bookmark-text');
                            if (textSpan) textSpan.textContent = 'Remove Bookmark';
                        }
                        
                        // Show toast message
                        const toastEl = document.createElement('div');
                        toastEl.className = 'position-fixed bottom-0 end-0 p-3';
                        toastEl.style.zIndex = '1050';
                        toastEl.innerHTML = `
                            <div class="toast align-items-center bg-success text-white border-0" role="alert" aria-live="assertive" aria-atomic="true">
                                <div class="d-flex">
                                    <div class="toast-body">
                                        ${data.message}
                                    </div>
                                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                                </div>
                            </div>
                        `;
                        document.body.appendChild(toastEl);
                        
                        // Show Toast
                        const toast = new bootstrap.Toast(toastEl.querySelector('.toast'));
                        toast.show();
                        
                        // Auto remove Toast element
                        setTimeout(() => {
                            toastEl.remove();
                        }, 3000);
                    } else {
                        // Show error message
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Bookmark operation failed:', error);
                    alert('Operation failed, please try again later');
                });
            });
        }
    });
</script>
<?= $this->endSection() ?> 