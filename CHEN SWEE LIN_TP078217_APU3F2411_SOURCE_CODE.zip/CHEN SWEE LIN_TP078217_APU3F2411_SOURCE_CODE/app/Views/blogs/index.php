<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Hero Section -->
<div class="py-5 mb-5" style="background-image: url('<?= base_url('assets/images/blogb.jpg') ?>'); background-size: cover; background-position: center; min-height: 500px; display: flex; align-items: center;">
<div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <h1 class="display-4 fw-bold text-success" style="text-shadow: 1px 1px 3px rgba(255, 255, 255, 0.8);">Environmental Blog</h1>
                <p class="lead mb-4 text-dark" style="text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.8);">Explore the concept of sustainable development, learn the latest knowledge and practical techniques for environmental recycling</p>
            </div>
        </div>
        </div>
    </div>

<div class="container">
    <?php if (empty($blogs)): ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-5">
                    <i class="fas fa-newspaper fa-4x text-success mb-4 opacity-75"></i>
                    <h3>No Blog Posts Available</h3>
                    <p class="text-muted">We are currently writing exciting environmental blog content, stay tuned!</p>
                    <a href="<?= base_url() ?>" class="btn btn-success mt-3">Return to Homepage</a>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    
    <!-- Featured Blog -->
        <?php if (isset($blogs[0])): $featuredBlog = $blogs[0]; ?>
    <div class="mb-5">
        <h2 class="fw-bold mb-4"><i class="fas fa-star text-warning me-2"></i>Featured Recommendation</h2>
        <div class="card border-0 rounded-4 shadow overflow-hidden">
                <div class="row g-0">
                <div class="col-lg-6">
                        <?php if (!empty($featuredBlog['image'])): ?>
                    <img src="<?= base_url('uploads/blogs/' . $featuredBlog['image']) ?>" class="img-fluid" alt="<?= $featuredBlog['title'] ?>" style="height: 100%; object-fit: cover;">
                        <?php else: ?>
                    <img src="<?= base_url('assets/images/blogb.jpg') ?>" class="img-fluid" alt="Default Blog Image" style="height: 100%; object-fit: cover;">
                    <?php endif; ?>
                </div>
                <div class="col-lg-6">
                    <div class="card-body d-flex flex-column p-4 p-lg-5 h-100">
                        <div class="mb-3">
                            <span class="badge bg-success rounded-pill">Recommended Reading</span>
                            <span class="ms-2 text-muted"><i class="far fa-calendar-alt me-1"></i><?= date('F d, Y', strtotime($featuredBlog['created_at'])) ?></span>
                        </div>
                        <h3 class="card-title fw-bold mb-3"><?= $featuredBlog['title'] ?></h3>
                        <p class="card-text flex-grow-1 mb-4"><?= substr(strip_tags($featuredBlog['content']), 0, 300) . '...' ?></p>
                        <div class="d-flex align-items-center justify-content-between">
                            <a href="<?= base_url('blogs/view/' . $featuredBlog['id']) ?>" class="btn btn-outline-success px-4">
                                    Read More <i class="fas fa-arrow-right ms-1"></i>
                                </a>
                            <?php if (session()->get('isLoggedIn')): ?>
                            <button class="btn <?= in_array($featuredBlog['id'], $bookmarkedBlogIds ?? []) ? 'btn-warning' : 'btn-light' ?> rounded-3 shadow-sm bookmark-btn" style="background-color: #f0f0f0;" data-blog-id="<?= $featuredBlog['id'] ?>" title="<?= in_array($featuredBlog['id'], $bookmarkedBlogIds ?? []) ? 'Remove Bookmark' : 'Bookmark Blog' ?>">
                                <i class="<?= in_array($featuredBlog['id'], $bookmarkedBlogIds ?? []) ? 'fas' : 'far' ?> fa-bookmark me-1"></i> 
                                <span><?= in_array($featuredBlog['id'], $bookmarkedBlogIds ?? []) ? 'Remove Bookmark' : 'Bookmark Blog' ?></span>
                            </button>
                            <?php endif; ?>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

    <!-- Latest Articles -->
    <div class="mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold"><i class="fas fa-newspaper text-primary me-2"></i>Latest Articles</h2>
            <div class="btn-group" role="group">
                <button type="button" class="btn btn-outline-success active">All</button>
                
            </div>
        </div>
        
        <div class="row g-4">
            <?php 
            // Ensure displayed blogs don't include the featured blog (if any)
            $displayBlogs = isset($blogs[0]) ? array_slice($blogs, 1) : $blogs;
            
            // Loop through blog posts
            foreach ($displayBlogs as $blog): 
            ?>
        <div class="col-md-6 col-lg-4">
                <div class="card h-100 border-0 shadow-sm rounded-3 overflow-hidden">
                <?php if (!empty($blog['image'])): ?>
                <div style="height: 200px; overflow: hidden;">
                        <img src="<?= base_url('uploads/blogs/' . $blog['image']) ?>" class="card-img-top" alt="<?= $blog['title'] ?>" style="height: 100%; object-fit: cover; transition: transform 0.3s;">
                </div>
                <?php else: ?>
                    <div style="height: 200px; overflow: hidden;">
                        <img src="<?= base_url('assets/images/blogb.jpg') ?>" class="card-img-top" alt="Default Blog Image" style="height: 100%; object-fit: cover; transition: transform 0.3s;">
                </div>
                <?php endif; ?>
                
                    <div class="card-body d-flex flex-column p-4">
                        <p class="text-muted small mb-2"><i class="far fa-calendar-alt me-1"></i><?= date('F d, Y', strtotime($blog['created_at'])) ?></p>
                        <h5 class="card-title fw-bold mb-3"><?= $blog['title'] ?></h5>
                    <p class="card-text text-muted mb-4"><?= substr(strip_tags($blog['content']), 0, 120) . '...' ?></p>
                        <div class="mt-auto d-flex justify-content-between align-items-center">
                            <a href="<?= base_url('blogs/view/' . $blog['id']) ?>" class="text-success text-decoration-none">
                            Read More <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                            <?php if (session()->get('isLoggedIn')): ?>
                            <button class="btn <?= in_array($blog['id'], $bookmarkedBlogIds ?? []) ? 'btn-warning' : 'btn-light' ?> rounded-3 shadow-sm bookmark-btn" style="background-color: #f0f0f0;" data-blog-id="<?= $blog['id'] ?>" title="<?= in_array($blog['id'], $bookmarkedBlogIds ?? []) ? 'Remove Bookmark' : 'Bookmark Blog' ?>">
                                <i class="<?= in_array($blog['id'], $bookmarkedBlogIds ?? []) ? 'fas' : 'far' ?> fa-bookmark me-1"></i> 
                                <span><?= in_array($blog['id'], $bookmarkedBlogIds ?? []) ? 'Remove Bookmark' : 'Bookmark Blog' ?></span>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Pagination Links -->
        <div class="d-flex justify-content-center mt-5">
            <?= $pager_links ?>
        </div>
    </div>
    
    
    <?php endif; ?>
</div>

<!-- Toast notification for bookmark actions -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
    <div id="bookmarkToast" class="toast align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas fa-check-circle me-2"></i> <span id="toast-message">Operation Successful</span>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>

<!-- CSS for hover effects -->
<style>
    .card {
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
    }
    .card:hover .card-img-top {
        transform: scale(1.05);
    }
    .bookmark-btn {
        transition: all 0.2s ease;
    }
    .bookmark-btn.btn-light {
        background-color: #f0f0f0 !important;
        color: #333;
    }
    .bookmark-btn.btn-light:hover {
        background-color: #e9e9e9 !important;
        color: #000;
    }
    .bookmark-btn.btn-warning {
        background-color: #ffc107;
        color: #000;
        border-color: #ffc107;
    }
    
    /* Custom Pagination Styles */
    .pagination .page-item .page-link {
        width: 45px;
        height: 45px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #198754;
        border: none;
        background-color: #f8f9fa;
        transition: all 0.3s ease;
    }
    
    .pagination .page-item.active .page-link {
        background-color: #198754;
        color: white;
        transform: scale(1.1);
    }
    
    .pagination .page-item .page-link:hover {
        background-color: #e9ecef;
        transform: translateY(-3px);
        box-shadow: 0 5px 10px rgba(0,0,0,0.1) !important;
    }
    
    .pagination .page-item.active .page-link:hover {
        background-color: #198754;
    }
</style>
<?= $this->endSection() ?> 

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle bookmark button clicks
    const bookmarkButtons = document.querySelectorAll('.bookmark-btn');
    
    bookmarkButtons.forEach(button => {
        button.addEventListener('click', function() {
            const blogId = this.getAttribute('data-blog-id');
            const isBookmarked = this.classList.contains('btn-warning');
            
            // Send bookmark/unbookmark request
            const url = isBookmarked 
                ? `<?= base_url('blogs/unbookmark/') ?>${blogId}`
                : `<?= base_url('blogs/bookmark/') ?>${blogId}`;
            
            fetch(url, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update button state
                    if (isBookmarked) {
                        // Remove bookmark
                        this.classList.replace('btn-warning', 'btn-light');
                        const icon = this.querySelector('i');
                        if (icon) icon.className = 'far fa-bookmark me-1';
                        const textSpan = this.querySelector('span');
                        if (textSpan) textSpan.textContent = 'Bookmark Blog';
                        this.title = 'Bookmark Blog';
                    } else {
                        // Add bookmark
                        this.classList.replace('btn-light', 'btn-warning');
                        const icon = this.querySelector('i');
                        if (icon) icon.className = 'fas fa-bookmark me-1';
                        const textSpan = this.querySelector('span');
                        if (textSpan) textSpan.textContent = 'Remove Bookmark';
                        this.title = 'Remove Bookmark';
                    }
                    
                    // Update toast message
                    const toastMessage = document.getElementById('toast-message');
                    if (toastMessage) {
                        toastMessage.textContent = data.message;
                    }
                    
                    // Show toast
                    const toastContainer = document.getElementById('bookmarkToast');
                    if (toastContainer) {
                        const toast = new bootstrap.Toast(toastContainer, {
                            autohide: true,
                            delay: 3000
                        });
                        toast.show();
                    }
                } else {
                    // If it's an unauthorized error, redirect to login page
                    if (data.message.includes('login')) {
                        window.location.href = '<?= base_url('auth/login') ?>';
                    } else {
                        alert(data.message);
                    }
                }
            })
            .catch(error => {
                console.error('Bookmark operation failed:', error);
                alert('Operation failed, please try again later');
            });
        });
    });
});
</script>
<?= $this->endSection() ?> 