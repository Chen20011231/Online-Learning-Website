<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Hero Section with Full Screen Background -->
<section class="hero-section">
    <div class="hero-overlay">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="hero-title mb-4">Smart Waste Sorting Assistant</h1>
                    <p class="hero-subtitle mb-5">Raise environmental awareness through professional courses, building a green future together</p>
                    <div class="hero-buttons">
                        <a href="<?= base_url('courses') ?>" class="btn btn-primary btn-lg px-4 me-sm-3">Start Learning</a>                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <h2 class="section-title">About Our Platform</h2>
                <p class="text-muted mb-4">We are an online learning platform focused on environmental recycling education, committed to providing high-quality environmental knowledge and practical guidance. Our mission is to raise public environmental awareness and promote sustainable development through education.</p>
                <ul class="feature-list">
                    <li><i class="fas fa-check-circle text-success me-2"></i> Professional environmental recycling courses</li>
                    <li><i class="fas fa-check-circle text-success me-2"></i> Interactive learning experience</li>
                    <li><i class="fas fa-check-circle text-success me-2"></i> Certification upon course completion</li>
                    <li><i class="fas fa-check-circle text-success me-2"></i> Real-time updated environmental knowledge base</li>
                </ul>
                <a href="<?= base_url('about') ?>" class="btn btn-outline-primary mt-3">Explore More</a>
            </div>
        </div>
    </div>
</section>

<!-- Featured Courses Section -->
<section class="py-5">
    <div class="container">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2 class="section-title">Featured Courses</h2>
                <p class="text-muted">Begin your environmental recycling learning journey</p>
            </div>
            <div class="col-md-4 text-end">
                <a href="<?= base_url('courses') ?>" class="btn btn-outline-primary">View All Courses</a>
            </div>
        </div>
        
        <div class="position-relative">
            <!-- Course Carousel -->
            <div id="courseCarousel" class="carousel slide" data-bs-ride="carousel">
                <!-- 添加轮播指示器 -->
                <div class="carousel-indicators">
                    <?php if (!empty($featuredCourses)): ?>
                        <?php 
                        $totalCourses = count($featuredCourses);
                        $coursesPerSlide = 3;
                        $totalSlides = ceil($totalCourses / $coursesPerSlide);
                        
                        for ($i = 0; $i < $totalSlides; $i++): ?>
                            <button type="button" data-bs-target="#courseCarousel" data-bs-slide-to="<?= $i ?>" <?= ($i === 0) ? 'class="active"' : '' ?> aria-current="<?= ($i === 0) ? 'true' : 'false' ?>" aria-label="Slide <?= $i+1 ?>"></button>
                        <?php endfor; ?>
                    <?php endif; ?>
                </div>
                
                <div class="carousel-inner">
                    <?php if (empty($featuredCourses)): ?>
                        <div class="carousel-item active">
                            <div class="row g-4">
                                <div class="col-12">
                                    <div class="card shadow-sm h-100">
                                        <div class="card-body text-center py-5">
                                            <i class="fas fa-book-open fa-3x text-muted mb-3"></i>
                                            <h5>No Courses Available</h5>
                                            <p class="text-muted">Stay tuned for our exciting courses coming soon!</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php 
                        $totalCourses = count($featuredCourses);
                        $coursesPerSlide = 3;
                        $totalSlides = ceil($totalCourses / $coursesPerSlide);
                        
                        for ($slide = 0; $slide < $totalSlides; $slide++): 
                            $startIndex = $slide * $coursesPerSlide;
                            $endIndex = min(($slide + 1) * $coursesPerSlide, $totalCourses);
                        ?>
                            <div class="carousel-item <?= ($slide === 0) ? 'active' : '' ?>">
                                <div class="row g-4">
                                    <?php for ($i = $startIndex; $i < $endIndex; $i++): 
                                        $course = $featuredCourses[$i];
                                    ?>
                                    <div class="col-md-6 col-lg-4">
                                        <div class="card course-card h-100">
                                            <div class="course-image">
                                                <?php if (!empty($course['image'])): ?>
                                                    <img src="<?= base_url('uploads/courses/' . $course['image']) ?>" class="card-img-top" alt="<?= $course['title'] ?>">
                                                <?php else: ?>
                                                    <div class="placeholder-image">
                                                        <i class="fas fa-recycle"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="course-overlay">
                                                    <a href="<?= base_url('courses/view/' . $course['id']) ?>" class="btn btn-sm btn-light">View Details</a>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title"><?= $course['title'] ?></h5>
                                                <p class="card-text text-muted small"><?= substr(strip_tags($course['description']), 0, 120) . (strlen($course['description']) > 120 ? '...' : '') ?></p>
                                            </div>
                                            <div class="card-footer bg-transparent border-top-0">
                                                <a href="<?= base_url('courses/view/' . $course['id']) ?>" class="btn btn-outline-primary btn-sm">Start Learning</a>
                                                <small class="text-muted float-end"><i class="fas fa-calendar-alt me-1"></i> <?= date('Y-m-d', strtotime($course['created_at'])) ?></small>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        <?php endfor; ?>
                    <?php endif; ?>
                </div>
                
                <!-- Carousel Navigation Arrows -->
                <button class="carousel-control-prev" type="button" data-bs-target="#courseCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#courseCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="py-5 bg-primary text-white">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="stats-item">
                    <i class="fas fa-users fa-3x mb-3"></i>
                    <h3>1000+</h3>
                    <p class="mb-0">Registered Students</p>
                </div>
            </div>
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="stats-item">
                    <i class="fas fa-book fa-3x mb-3"></i>
                    <h3>50+</h3>
                    <p class="mb-0">Quality Courses</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-item">
                    <i class="fas fa-certificate fa-3x mb-3"></i>
                    <h3>500+</h3>
                    <p class="mb-0">Course Completion Certificates</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Recent Blogs Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2 class="section-title">Environmental Blog</h2>
                <p class="text-muted">Learn about the latest environmental knowledge and insights</p>
            </div>
            <div class="col-md-4 text-end">
                <a href="<?= base_url('blogs') ?>" class="btn btn-outline-success">View All Blogs</a>
            </div>
        </div>
        
        <div class="position-relative">
            <!-- Blog Carousel -->
            <div id="blogCarousel" class="carousel slide" data-bs-ride="carousel">
                <!-- Add carousel indicators -->
                <div class="carousel-indicators">
                    <?php if (!empty($recentBlogs)): ?>
                        <?php 
                        $totalBlogs = count($recentBlogs);
                        $blogsPerSlide = 3;
                        $totalSlides = ceil($totalBlogs / $blogsPerSlide);
                        
                        for ($i = 0; $i < $totalSlides; $i++): ?>
                            <button type="button" data-bs-target="#blogCarousel" data-bs-slide-to="<?= $i ?>" <?= ($i === 0) ? 'class="active"' : '' ?> aria-current="<?= ($i === 0) ? 'true' : 'false' ?>" aria-label="Slide <?= $i+1 ?>"></button>
                        <?php endfor; ?>
                    <?php endif; ?>
                </div>
                
                <div class="carousel-inner">
                    <?php if (empty($recentBlogs)): ?>
                        <div class="carousel-item active">
                            <div class="row g-4">
                                <div class="col-12">
                                    <div class="card shadow-sm h-100">
                                        <div class="card-body text-center py-5">
                                            <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
                                            <h5>No Blogs Available</h5>
                                            <p class="text-muted">Stay tuned for our exciting blog posts coming soon!</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php 
                        $totalBlogs = count($recentBlogs);
                        $blogsPerSlide = 3;
                        $totalSlides = ceil($totalBlogs / $blogsPerSlide);
                        
                        for ($slide = 0; $slide < $totalSlides; $slide++): 
                            $startIndex = $slide * $blogsPerSlide;
                            $endIndex = min(($slide + 1) * $blogsPerSlide, $totalBlogs);
                        ?>
                            <div class="carousel-item <?= ($slide === 0) ? 'active' : '' ?>">
                                <div class="row g-4">
                                    <?php for ($i = $startIndex; $i < $endIndex; $i++): 
                                        $blog = $recentBlogs[$i];
                                    ?>
                                    <div class="col-md-6 col-lg-4">
                                        <div class="card blog-card h-100">
                                            <div class="blog-image">
                                                <?php if (!empty($blog['image'])): ?>
                                                    <img src="<?= base_url('uploads/blogs/' . $blog['image']) ?>" class="card-img-top" alt="<?= $blog['title'] ?>">
                                                <?php else: ?>
                                                    <div class="placeholder-image">
                                                        <i class="fas fa-leaf"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="blog-date">
                                                    <span><?= date('d', strtotime($blog['created_at'])) ?></span>
                                                    <span><?= date('M', strtotime($blog['created_at'])) ?></span>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title"><?= $blog['title'] ?></h5>
                                                <p class="card-text text-muted small"><?= substr(strip_tags($blog['content']), 0, 120) . (strlen($blog['content']) > 120 ? '...' : '') ?></p>
                                            </div>
                                            <div class="card-footer bg-transparent border-top-0">
                                                <a href="<?= base_url('blogs/view/' . $blog['id']) ?>" class="btn btn-outline-success btn-sm">Read Full Article</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        <?php endfor; ?>
                    <?php endif; ?>
                </div>
                
                <!-- Carousel Navigation Arrows -->
                <button class="carousel-control-prev" type="button" data-bs-target="#blogCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#blogCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-5 bg-success text-white">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h2 class="mb-4">Ready to start your environmental learning journey?</h2>
                <p class="mb-4">Join our platform to get professional environmental recycling knowledge and contribute to the sustainable development of our planet.</p>
                <a href="<?= base_url('auth/register') ?>" class="btn btn-light btn-lg">Register Now</a>
            </div>
        </div>
    </div>
</section>

<style>
/* Hero Section Styles */
.hero-section {
    position: relative;
    height: 100vh;
    min-height: 600px;
    background-image: url('<?= base_url('assets/images/environment-recolored_option-2.png') ?>');
    background-size: cover;
    background-position: center;
    color: white;
    display: flex;
    align-items: center;
    text-align: center;
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
}

.hero-title {
    font-size: 3.5rem;
    font-weight: 700;
    margin-bottom: 1rem;
}

.hero-subtitle {
    font-size: 1.5rem;
    font-weight: 300;
    max-width: 800px;
    margin: 0 auto;
}

.hero-buttons {
    margin-top: 2rem;
}

.btn-video {
    background: transparent;
    color: white;
    border: 2px solid white;
    padding: 0.5rem 1rem;
    border-radius: 50px;
    transition: all 0.3s;
}

.btn-video:hover {
    background: white;
    color: #212529;
}

/* Section Styles */
.section-title {
    font-weight: 700;
    margin-bottom: 1rem;
    position: relative;
    padding-bottom: 0.5rem;
}

.section-title:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 50px;
    height: 3px;
    background-color: #0d6efd;
}

/* Course Card Styles */
.course-card, .blog-card {
    transition: transform 0.3s, box-shadow 0.3s;
    overflow: hidden;
}

.course-card:hover, .blog-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.course-image, .blog-image {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.course-image img, .blog-image img {
    height: 100%;
    width: 100%;
    object-fit: cover;
    transition: transform 0.5s;
}

.course-card:hover .course-image img, .blog-card:hover .blog-image img {
    transform: scale(1.1);
}

.placeholder-image {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #e9ecef;
    color: #6c757d;
}

.placeholder-image i {
    font-size: 3rem;
}

.course-overlay {
    position: absolute;
    bottom: -50px;
    left: 0;
    width: 100%;
    background-color: rgba(255, 255, 255, 0.9);
    padding: 10px;
    transition: bottom 0.3s;
    text-align: center;
}

.course-card:hover .course-overlay {
    bottom: 0;
}

/* Course Carousel Controls */
.carousel-control-prev, .carousel-control-next {
    width: 40px;
    height: 40px;
    background-color: rgba(13, 110, 253, 0.7);
    border-radius: 50%;
    top: 50%;
    transform: translateY(-50%);
    opacity: 0.8;
}

.carousel-control-prev {
    left: -50px;
}

.carousel-control-next {
    right: -50px;
}

.carousel-control-prev-icon, .carousel-control-next-icon {
    width: 20px;
    height: 20px;
}

.carousel-control-prev:hover, .carousel-control-next:hover {
    opacity: 1;
    background-color: rgba(13, 110, 253, 0.9);
}

.carousel-indicators {
    bottom: -40px;
}

.carousel-indicators button {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background-color: rgba(13, 110, 253, 0.5);
    margin: 0 5px;
}

.carousel-indicators button.active {
    background-color: rgba(13, 110, 253, 1);
}

#courseCarousel {
    padding-bottom: 50px;
}

/* Blog Carousel Styles */
#blogCarousel {
    padding-bottom: 50px;
}

#blogCarousel .carousel-control-prev, 
#blogCarousel .carousel-control-next {
    background-color: rgba(25, 135, 84, 0.7);
}

#blogCarousel .carousel-control-prev:hover, 
#blogCarousel .carousel-control-next:hover {
    background-color: rgba(25, 135, 84, 0.9);
}

#blogCarousel .carousel-indicators button {
    background-color: rgba(25, 135, 84, 0.5);
}

#blogCarousel .carousel-indicators button.active {
    background-color: rgba(25, 135, 84, 1);
}

/* Blog Date */
.blog-date {
    position: absolute;
    top: 10px;
    right: 10px;
    background-color: rgba(255, 255, 255, 0.9);
    color: #212529;
    padding: 5px 10px;
    border-radius: 5px;
    text-align: center;
    line-height: 1;
    z-index: 5;
}

.blog-date span {
    display: block;
}

.blog-date span:first-child {
    font-size: 1.5rem;
    font-weight: 700;
}

@media (max-width: 992px) {
    .carousel-control-prev {
        left: -20px;
    }
    
    .carousel-control-next {
        right: -20px;
    }
}

/* Stats Section Styles */
.stats-item {
    padding: 20px;
}

.stats-item h3 {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

/* Feature List */
.feature-list {
    list-style: none;
    padding-left: 0;
}

.feature-list li {
    padding: 8px 0;
}

/* About Image */
.about-image-container {
    position: relative;
    overflow: hidden;
    border-radius: 0.25rem;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}
</style>
<?= $this->endSection() ?> 

<?= $this->section('scripts') ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize course carousel
        initCarousel('courseCarousel');
        
        // Initialize blog carousel
        initCarousel('blogCarousel');
        
        // Generic carousel initialization function
        function initCarousel(carouselId) {
            const carouselElement = document.getElementById(carouselId);
            if (!carouselElement) return;
            
            const carouselItems = document.querySelectorAll(`#${carouselId} .carousel-item`);
            console.log(`Found ${carouselItems.length} ${carouselId} carousel items`);
            
            if (carouselItems.length > 1) {
                // Initialize carousel
                const carousel = new bootstrap.Carousel(carouselElement, {
                    interval: 5000,
                    wrap: true,
                    keyboard: true,
                    pause: 'hover',
                    touch: true
                });
                
                // Add navigation arrow controls
                const prevButton = carouselElement.querySelector('.carousel-control-prev');
                const nextButton = carouselElement.querySelector('.carousel-control-next');
                
                if (prevButton) {
                    prevButton.onclick = function(e) {
                        e.preventDefault();
                        carousel.prev();
                        console.log(`${carouselId} left arrow clicked`);
                        return false;
                    };
                }
                
                if (nextButton) {
                    nextButton.onclick = function(e) {
                        e.preventDefault();
                        carousel.next();
                        console.log(`${carouselId} right arrow clicked`);
                        return false;
                    };
                }
                
                // Add indicator controls
                carouselElement.querySelectorAll('.carousel-indicators button').forEach(function(button, index) {
                    button.onclick = function() {
                        carousel.to(index);
                        console.log(`${carouselId} indicator clicked - jump to slide ${index}`);
                    };
                });
                
                console.log(`${carouselId} carousel initialization complete`);
            } else {
                console.log(`${carouselId} has only one carousel item or no items, no need to initialize`);
            }
        }
    });
</script>
<?= $this->endSection() ?> 