<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Quiz Page Header -->
<div class="quiz-header py-4 mb-4 bg-light">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= base_url() ?>" class="text-decoration-none"><i class="fas fa-home"></i> Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url('courses') ?>" class="text-decoration-none">Courses</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url('courses/view/' . $courseId) ?>" class="text-decoration-none"><?= $courseTitle ?></a></li>
                <li class="breadcrumb-item active" aria-current="page">Quiz</li>
            </ol>
        </nav>
    </div>
</div>

<div class="container">
            <?php if (empty($questions)): ?>
    <!-- No Quiz Questions State -->
    <div class="text-center py-5">
        <div class="empty-state-icon mb-4">
            <i class="fas fa-clipboard-list fa-5x text-muted opacity-25"></i>
        </div>
        <h3>No Quiz Questions Available</h3>
        <p class="text-muted mb-4">This course does not have any quiz questions yet. Please try again later.</p>
        <a href="<?= base_url('courses/view/' . $courseId) ?>" class="btn btn-primary px-4 py-2">
            <i class="fas fa-arrow-left me-2"></i> Return to Course
                    </a>
                </div>
    <?php else: ?>
    <!-- Quiz Card -->
    <div class="card border-0 shadow-sm mb-5">
        <!-- Quiz Header -->
        <div class="card-header bg-primary text-white py-3">
            <div class="d-flex align-items-center justify-content-between">
                <h4 class="mb-0"><i class="fas fa-clipboard-check me-2"></i><?= $courseTitle ?></h4>
                <p class="mb-0 mt-1 opacity-75">Course Quiz</p>
                    </div>
                </div>
                
        <form id="quizForm" method="post" action="<?= base_url('courses/submitQuiz/' . $courseId) ?>">
            <div class="card-body p-4">
                <!-- Quiz Progress Indicator -->
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <div class="progress flex-grow-1 me-3" style="height: 10px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 0%;" id="quiz-progress"></div>
                    </div>
                    <div>
                        <small><span id="currentQuestion">0</span>/<span id="totalQuestions"><?= count($questions) ?></span> questions</small>
                    </div>
                </div>
                
                <!-- Quiz Content -->
                <div id="quiz-content">
                    <!-- Introduction Screen -->
                    <div id="quiz-intro" class="text-center py-4">
                        <div class="mb-4">
                            <i class="fas fa-file-alt fa-3x text-primary mb-3"></i>
                            <h5 class="mb-1">Quiz Instructions</h5>
                            <p class="mb-0">This quiz has <strong><?= count($questions) ?></strong> questions. Please carefully read each question and select the correct answer. Click the submit button after completing all questions.</p>
                        </div>
                        
                        <button type="button" id="startQuizBtn" class="btn btn-primary px-4 py-2">
                            <i class="fas fa-play-circle me-2"></i> Start Quiz
                        </button>
                    </div>
                    
                    <!-- Questions -->
                    <?php foreach($questions as $index => $question): ?>
                    <div class="question-item" data-question="<?= $index + 1 ?>" style="display: none;">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title mb-0 fw-bold">Question <?= $index + 1 ?></h5>
                                <div class="divider my-3"></div>
                                <p class="mb-4"><?= $question['question'] ?></p>
                                
                                <?php if ($question['type'] == 'multiple_choice'): ?>
                                <div class="options-list">
                                        <?php 
                                        $options = json_decode($question['options'], true);
                                    if (empty($options) || !is_array($options)) {
                                        echo '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i> Question options configuration error. Please contact the administrator.</div>';
                                    } else {
                                        foreach ($options as $key => $option): 
                                    ?>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="radio" name="answer[<?= $question['id'] ?>]" id="option_<?= $question['id'] ?>_<?= $key ?>" value="<?= $key ?>">
                                        <label class="form-check-label" for="option_<?= $question['id'] ?>_<?= $key ?>">
                                                            <?= $option ?>
                                                </label>
                                            </div>
                                    <?php 
                                        endforeach;
                                    }
                                    ?>
                                        </div>
                                        <?php else: ?>
                                        <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i> This question options configuration is incorrect. Please contact the administrator.
                                        </div>
                                        <?php endif; ?>
                                    </div>
                        </div>
                        
                        <!-- Navigation Buttons -->
                                        <div class="d-flex justify-content-between">
                                            <?php if ($index > 0): ?>
                            <button type="button" class="btn btn-outline-secondary prev-question">
                                <i class="fas fa-arrow-left me-1"></i> Previous Question
                                            </button>
                                            <?php else: ?>
                                            <div></div>
                                            <?php endif; ?>
                                            
                                            <?php if ($index < count($questions) - 1): ?>
                            <button type="button" class="btn btn-primary next-question">
                                Next Question <i class="fas fa-arrow-right ms-1"></i>
                                            </button>
                                            <?php else: ?>
                            <button type="button" class="btn btn-success finish-btn">
                                Finish Quiz <i class="fas fa-check ms-1"></i>
                                            </button>
                                            <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                    
                    <!-- Submission Section -->
                    <div id="submit-section" style="display: none;">
                        <div class="card text-center">
                            <div class="card-body py-5">
                                <h4 class="card-title mb-4"><i class="fas fa-clipboard-check text-success me-2"></i> Quiz Completed</h4>
                                
                                <div class="row justify-content-center mb-4">
                                            <div class="col-md-4">
                                        <div class="card bg-light mb-3">
                                            <div class="card-body py-3">
                                                <h5 class="mb-1">Total Questions</h5>
                                                <h2 class="mb-0 fw-bold"><?= count($questions) ?></h2>
                                            </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                        <div class="card bg-light mb-3">
                                            <div class="card-body py-3">
                                                <h5 class="mb-1">Answered Questions</h5>
                                                <h2 class="mb-0 fw-bold" id="answeredCount">0</h2>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card bg-light">
                                            <div class="card-body py-3">
                                                <h5 class="mb-1">Unanswered Questions</h5>
                                                <h2 class="mb-0 fw-bold" id="unansweredCount"><?= count($questions) ?></h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div id="warning-unanswered" class="alert alert-warning mb-4" style="display: none;">
                                    <i class="fas fa-exclamation-triangle me-2"></i> You still have unanswered questions. Are you sure you want to submit?
                                    </div>
                                    
                                <div>
                                    <button type="button" id="review-btn" class="btn btn-outline-primary me-2">
                                        <i class="fas fa-eye me-1"></i> Review Answers
                                        </button>
                                    <button type="submit" id="submit-btn" class="btn btn-success">
                                        <i class="fas fa-paper-plane me-2"></i> Submit Quiz
                                        </button>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            
                <!-- Question Navigation -->
                <div id="question-nav" class="mt-4 p-3 bg-light rounded" style="display: none;">
                    <h5 class="mb-3">Question Navigation</h5>
                    <div class="d-flex flex-wrap gap-2" id="question-nav-buttons">
                        <?php foreach($questions as $index => $question): ?>
                        <button type="button" class="btn btn-outline-secondary question-nav-btn" data-question="<?= $index + 1 ?>"><?= $index + 1 ?></button>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>

<!-- Result Modal -->
<div class="modal fade" id="resultModal" tabindex="-1" aria-labelledby="resultModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="resultModalLabel">Quiz Results</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <div id="result-spinner" class="mb-3">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Processing your results...</p>
                </div>
                
                <div id="result-content" style="display: none;">
                    <h3 class="mb-2">Your Score: <span id="scoreValue" class="text-primary fw-bold">0</span>%</h3>
                    <p class="text-muted mb-0">You answered <span id="correctAnswers">0</span> questions correctly out of <span id="totalQuestions2">0</span> questions</p>
                    
                    <div class="mt-4">
                        <div id="certificate-section">
                            <div class="alert alert-success mt-3">
                                <div class="d-flex">
                                    <div class="me-3">
                                        <i class="fas fa-certificate fa-2x"></i>
                                    </div>
                                    <div class="text-start">
                                        Congratulations! You passed the quiz!
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <a href="<?= base_url('courses/view/' . $courseId) ?>" class="btn btn-outline-secondary me-2">
                                <i class="fas fa-book me-1"></i> Return to Course
                            </a>
                            <a href="<?= base_url('dashboard') ?>" class="btn btn-primary">
                                <i class="fas fa-user me-1"></i> My Profile
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Quiz Styles */
.question-item {
    animation: fadeIn 0.5s;
}

.options-list {
    padding-left: 1rem;
}

.form-check {
    padding: 10px 10px 10px 35px;
    border-radius: 5px;
    transition: background-color 0.2s;
}

.form-check:hover {
    background-color: #f8f9fa;
}

.form-check-input {
    cursor: pointer;
}

.form-check-input:checked + .form-check-label {
    font-weight: 500;
    color: #0d6efd;
}

.form-check-label {
    cursor: pointer;
}

.divider {
    height: 1px;
    background-color: #e9ecef;
}

.question-nav-btn {
    width: 40px;
    height: 40px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.question-nav-btn.answered {
    background-color: #0d6efd;
    border-color: #0d6efd;
    color: white;
}

.question-nav-btn.active {
    background-color: #198754;
    border-color: #198754;
    color: white;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}
</style>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialization
    let currentQuestion = 0;
    const totalQuestions = <?= count($questions) ?>;
    const answers = {};
    
    // Option click events
    document.querySelectorAll('.form-check-input').forEach(input => {
        input.addEventListener('change', function() {
            // Get question id from input name attribute
            const questionId = this.name.match(/\[(\d+)\]/)[1];
            
            // Remove selection from all options
            document.querySelectorAll(`input[name="answer[${questionId}]"]`).forEach(inp => {
                inp.closest('.form-check').classList.remove('bg-light');
            });
            
            // Add selection to current option
            this.closest('.form-check').classList.add('bg-light');
            
            // Store the answer in answers object using question ID as key
            answers[questionId] = this.value;
            
            // Update navigation buttons
            updateNavButtons();
            
            // Update progress indicator
            updateProgress();
            
            // Debug
            console.log(`Question ${questionId} answer set to: ${this.value}`);
        });
    });
    
    // Next question button
    document.querySelectorAll('.next-question').forEach(button => {
        button.addEventListener('click', function() {
            showQuestion(currentQuestion + 1);
        });
    });
    
    // Previous question button
    document.querySelectorAll('.prev-question').forEach(button => {
        button.addEventListener('click', function() {
            showQuestion(currentQuestion - 1);
        });
    });
    
    // Question navigation buttons
    document.querySelectorAll('.question-nav-btn').forEach(button => {
        button.addEventListener('click', function() {
            const questionIndex = parseInt(this.dataset.question);
            showQuestion(questionIndex);
        });
    });
    
    // Finish button
    document.querySelector('.finish-btn').addEventListener('click', function() {
        showSubmitSection();
    });
    
    // Calculate answered and unanswered questions
    function updateCounts() {
        const answeredCount = Object.keys(answers).length;
        const unansweredCount = totalQuestions - answeredCount;
        
        document.getElementById('answeredCount').textContent = answeredCount;
        document.getElementById('unansweredCount').textContent = unansweredCount;
        
        if (unansweredCount > 0) {
            document.getElementById('warning-unanswered').style.display = 'block';
            } else {
            document.getElementById('warning-unanswered').style.display = 'none';
        }
    }
    
    // Show submit section
    function showSubmitSection() {
        document.querySelectorAll('.question-item').forEach(item => {
            item.style.display = 'none';
        });
        
        document.getElementById('submit-section').style.display = 'block';
        updateCounts();
    }
    
    // Review button click
    document.getElementById('review-btn').addEventListener('click', function() {
        document.getElementById('submit-section').style.display = 'none';
        showQuestion(1);
    });
    
    // Start quiz button click
    document.getElementById('startQuizBtn').addEventListener('click', function() {
        document.getElementById('quiz-intro').style.display = 'none';
        document.getElementById('question-nav').style.display = 'block';
        showQuestion(1);
    });
    
    // Show a specific question
    function showQuestion(questionNumber) {
        document.querySelectorAll('.question-item').forEach(item => {
            item.style.display = 'none';
        });
        
        document.querySelector(`.question-item[data-question="${questionNumber}"]`).style.display = 'block';
        currentQuestion = questionNumber;
        
        // Update current question indicator
        document.getElementById('currentQuestion').textContent = currentQuestion;
        
        // Update navigation buttons
        updateNavButtons();
        
        // Update progress bar
        updateProgress();
    }
    
    // Update navigation buttons highlighting
    function updateNavButtons() {
        // Reset all buttons
        document.querySelectorAll('.question-nav-btn').forEach(btn => {
            btn.classList.remove('answered', 'active');
        });
        
        // Highlight answered questions
        Object.keys(answers).forEach(questionId => {
            const btn = document.querySelector(`.question-nav-btn[data-question="${questionId}"]`);
            if (btn) btn.classList.add('answered');
        });
        
        // Highlight current question
        const currentBtn = document.querySelector(`.question-nav-btn[data-question="${currentQuestion}"]`);
        if (currentBtn) currentBtn.classList.add('active');
    }
    
    // Update progress bar
    function updateProgress() {
        const progress = (Object.keys(answers).length / totalQuestions) * 100;
        document.getElementById('quiz-progress').style.width = `${progress}%`;
    }
    
    // Quiz form submission
    document.getElementById('quizForm').addEventListener('submit', function(event) {
        event.preventDefault();
        
        // Show the result modal
        const resultModal = new bootstrap.Modal(document.getElementById('resultModal'));
        resultModal.show();
        
        // Collect all answers - use the answers object directly
        // We don't need to re-query the DOM as we've been tracking answers
        let questionAnswers = answers;
        console.log('Submitting answers:', questionAnswers);
        
        // Prepare data for submission
        const data = {
            quiz_id: <?= $quiz['id'] ?>,
            course_id: <?= $courseId ?>,
            answers: questionAnswers
        };
        
        // Submit quiz via AJAX
        fetch('<?= base_url('courses/submitQuiz') ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(result => {
            console.log('Result from server:', result);
            document.getElementById('result-spinner').style.display = 'none';
            document.getElementById('result-content').style.display = 'block';
            
            // Display real score from server
            const score = result.percentage;
            const correct = result.score;
            
            document.getElementById('scoreValue').textContent = Math.round(score);
            document.getElementById('correctAnswers').textContent = correct;
            document.getElementById('totalQuestions2').textContent = result.total;
            
            // Hide certificate section if failed (less than 60%)
            if (score < 60) {
                document.getElementById('certificate-section').style.display = 'none';
            } else {
                // If certificate was issued, you could add code here to link to it
                if (result.certificateIssued && result.certificateId) {
                    const certificateLink = document.createElement('a');
                    certificateLink.href = '<?= base_url('courses/certificate/') ?>' + result.certificateId;
                    certificateLink.className = 'btn btn-success mt-3';
                    certificateLink.innerHTML = '<i class="fas fa-certificate me-1"></i> View Certificate';
                    document.getElementById('certificate-section').appendChild(certificateLink);
                }
            }
        })
        .catch(error => {
            console.error('Error submitting quiz:', error);
            document.getElementById('result-spinner').style.display = 'none';
            document.getElementById('result-content').innerHTML = '<div class="alert alert-danger">An error occurred while submitting your quiz. Please try again.</div>';
        });
    });
});
</script>
<?= $this->endSection() ?> 