<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Course Page Top Banner -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <h1 class="display-4 fw-bold text-primary">Environmental Recycling Courses</h1>
                <p class="lead mb-4">Explore our carefully designed environmental recycling courses to enhance your environmental awareness and practical skills.</p>
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <span class="badge rounded-pill bg-success fs-6 px-3 py-2">
                            <i class="fas fa-leaf me-1"></i> <?= count($courses) ?> Courses
                        </span>
                    </div>
                    <div class="text-muted">
                        <i class="fas fa-info-circle me-1"></i> Certificates available upon course completion
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

<!-- Filter and Search Section -->
<section class="py-4 border-bottom bg-white">
    <div class="container">
        <div class="row g-3">
            <div class="col-lg-8">
                <form action="<?= base_url('courses/search') ?>" method="get" class="mb-0">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="fas fa-search text-muted"></i></span>
                        <input type="text" id="courseSearch" name="q" class="form-control border-0 bg-light" placeholder="Search courses..." value="<?= isset($searchTerm) ? $searchTerm : '' ?>">
                        <button type="submit" class="btn btn-primary">Search</button>
                    </div>
                </form>
            </div>
            <div class="col-lg-4">
                <div class="d-flex justify-content-lg-end gap-2 flex-wrap">
                    <a href="<?= base_url('courses') ?>" class="btn btn-sm btn-outline-primary course-filter <?= !isset($searchTerm) ? 'active' : '' ?>">All Courses</a>
                    <?php if (isset($searchTerm)): ?>
                    <span class="btn btn-sm btn-outline-secondary">
                        Search: "<?= $searchTerm ?>" (<?= count($courses) ?> results)
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Course List Section -->
<section class="py-5">
    <div class="container">
        <?php if (empty($courses)): ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm border-0 rounded-3">
                    <div class="card-body text-center py-5">
                        <i class="fas fa-book-open fa-4x text-muted mb-4"></i>
                        <h3>No Courses Available</h3>
                        <p class="text-muted">We are carefully preparing course content, please stay tuned!</p>
                        <a href="<?= base_url() ?>" class="btn btn-primary mt-3">Return to Homepage</a>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <!-- No Search Results Notice -->
        <div id="noResultsMessage" class="row justify-content-center" style="display: none;">
            <div class="col-md-8">
                <div class="card shadow-sm border-0 rounded-3">
                    <div class="card-body text-center py-5">
                        <i class="fas fa-search fa-4x text-muted mb-4"></i>
                        <h3>No Matching Courses Found</h3>
                        <p class="text-muted">Please try searching with different keywords</p>
                        <?php if (isset($searchTerm)): ?>
                        <a href="<?= base_url('courses') ?>" class="btn btn-primary mt-3">View All Courses</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4" id="courseList">
            <?php foreach ($courses as $course): ?>
            <div class="col course-item">
                <div class="card h-100 border-0 shadow-sm rounded-3 overflow-hidden course-card">
                    <?php if (!empty($course['image'])): ?>
                    <div class="position-relative course-image-container">
                        <img src="<?= base_url('uploads/courses/' . $course['image']) ?>" class="card-img-top" alt="<?= $course['title'] ?>" style="height: 200px; object-fit: cover;">
                        <div class="course-overlay">
                            <a href="<?= base_url('courses/view/' . $course['id']) ?>" class="btn btn-light btn-sm rounded-circle">
                                <i class="fas fa-eye"></i>
                            </a>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="bg-light d-flex justify-content-center align-items-center position-relative course-image-container" style="height: 200px;">
                        <i class="fas fa-recycle fa-4x text-muted"></i>
                        <div class="course-overlay">
                            <a href="<?= base_url('courses/view/' . $course['id']) ?>" class="btn btn-light btn-sm rounded-circle">
                                <i class="fas fa-eye"></i>
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="card-body d-flex flex-column p-4">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="badge bg-light text-primary px-3 py-2 rounded-pill">Environmental Course</span>
                            <small class="text-muted"><i class="far fa-calendar-alt me-1"></i> <?= date('Y-m-d', strtotime($course['created_at'])) ?></small>
                        </div>
                        <h5 class="card-title fw-bold mb-3"><?= $course['title'] ?></h5>
                        <p class="card-text text-muted mb-4"><?= substr(strip_tags($course['description']), 0, 120) . (strlen($course['description']) > 120 ? '...' : '') ?></p>
                        <div class="mt-auto">
                            <a href="<?= base_url('courses/view/' . $course['id']) ?>" class="btn btn-primary w-100">
                                <i class="fas fa-eye me-1"></i> View
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <!-- Pagination Links -->
        <?php if (!empty($courses)): ?>
        <div class="d-flex justify-content-center mt-5">
            <?= $pager_links ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<style>
/* Course Card Styles */
.course-card {
    transition: all 0.3s ease;
}

.course-card:hover {
    transform: translateY(-5px);
}

.course-image-container {
    overflow: hidden;
}

.course-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: all 0.3s ease;
}

.course-card:hover .course-overlay {
    opacity: 1;
}

/* Filter Button Styles */
.course-filter {
    transition: all 0.2s ease;
    border-radius: 20px;
    padding: 0.5rem 1rem;
}

.course-filter.active {
    background-color: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
}

/* Custom Pagination Styles */
.pagination .page-item .page-link {
    width: 45px;
    height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #0d6efd;
    border: none;
    background-color: #f8f9fa;
    transition: all 0.3s ease;
}

.pagination .page-item.active .page-link {
    background-color: #0d6efd;
    color: white;
    transform: scale(1.1);
}

.pagination .page-item .page-link:hover {
    background-color: #e9ecef;
    transform: translateY(-3px);
    box-shadow: 0 5px 10px rgba(0,0,0,0.1) !important;
}

.pagination .page-item.active .page-link:hover {
    background-color: #0d6efd;
}
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Course search functionality - client-side real-time filtering
    const searchInput = document.getElementById('courseSearch');
    if(searchInput) {
        // Real-time filtering (client-side)
        let typingTimer;
        const doneTypingInterval = 300; // Waiting time after input, in milliseconds
        
        searchInput.addEventListener('input', function() {
            clearTimeout(typingTimer);
            const searchValue = this.value.toLowerCase();
            
            // If search box is empty, show all courses
            if(searchValue === '') {
                document.querySelectorAll('.course-item').forEach(course => {
                    course.style.display = 'block';
                });
                // Hide no results message
                const noResultsMessage = document.getElementById('noResultsMessage');
                if(noResultsMessage) {
                    noResultsMessage.style.display = 'none';
                }
                return;
            }
            
            // Set timer to reduce frequent filtering
            typingTimer = setTimeout(function() {
                const courses = document.querySelectorAll('.course-item');
                let hasResults = false;
                
                courses.forEach(course => {
                    const title = course.querySelector('.card-title').textContent.toLowerCase();
                    const description = course.querySelector('.card-text').textContent.toLowerCase();
                    
                    if(title.includes(searchValue) || description.includes(searchValue)) {
                        course.style.display = 'block';
                        hasResults = true;
                    } else {
                        course.style.display = 'none';
                    }
                });
                
                // Show/hide no results message
                const noResultsMessage = document.getElementById('noResultsMessage');
                if(noResultsMessage) {
                    noResultsMessage.style.display = hasResults ? 'none' : 'flex';
                }
                
            }, doneTypingInterval);
        });
    }
});
</script>
<?= $this->endSection() ?> 