<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Course Detail Page Top Background -->
<div class="course-header py-4" style="background-color: #f8f9fa;">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= base_url() ?>" class="text-decoration-none"><i class="fas fa-home"></i> Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url('courses') ?>" class="text-decoration-none">Courses</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= $course['title'] ?></li>
            </ol>
        </nav>
    </div>
</div>

<!-- Course Main Content Area -->
<div class="container py-5">
    <!-- Toast notification for bookmark actions -->
    <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
        <div id="bookmarkToast" class="toast align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fas fa-check-circle me-2"></i> <span id="toast-message">Operation Successful</span>
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Course Content Left Side -->
        <div class="col-lg-8">
            <!-- Course Title and Tags -->
            <div class="course-title-section mb-4">
                <h1 class="fw-bold mb-3"><?= $course['title'] ?></h1>
                <div class="d-flex flex-wrap align-items-center mb-3">
                    <span class="badge bg-primary rounded-pill me-2 mb-2"><i class="fas fa-calendar-alt me-1"></i> <?= date('Y-m-d', strtotime($course['created_at'])) ?></span>
                    <span class="badge bg-success rounded-pill me-2 mb-2"><i class="fas fa-user-graduate me-1"></i> Environmental Course</span>
                    <span class="badge bg-info rounded-pill me-2 mb-2"><i class="fas fa-clock me-1"></i> Approximately 30 minutes</span>
                    <!-- Bookmark Button - Right Side -->
                    <div class="ms-auto">
                        <button id="bookmark-btn" class="btn <?= isset($isBookmarked) && $isBookmarked ? 'btn-warning' : 'btn-light' ?>" data-course-id="<?= $course['id'] ?>">
                            <i class="<?= isset($isBookmarked) && $isBookmarked ? 'fas' : 'far' ?> fa-bookmark me-1"></i> 
                            <span id="bookmark-text"><?= isset($isBookmarked) && $isBookmarked ? 'Remove Bookmark' : 'Bookmark Course' ?></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Course Cover Image -->
            <?php if (!empty($course['image'])): ?>
            <div class="course-image mb-4 position-relative">
                <img src="<?= base_url('uploads/courses/' . $course['image']) ?>" alt="<?= $course['title'] ?>" class="img-fluid rounded-3 shadow" style="width: 100%; max-height: 450px; object-fit: cover;">
                <div class="position-absolute bottom-0 end-0 p-3">
                    <button type="button" class="btn btn-light btn-sm rounded-circle shadow" data-bs-toggle="tooltip" title="Fullscreen View">
                        <i class="fas fa-expand"></i>
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <!-- Course Navigation Menu -->
            <div class="course-nav mb-4 bg-white pt-3">
                <ul class="nav nav-pills nav-fill border-bottom">
                    <li class="nav-item">
                        <a class="nav-link active" href="#course-intro" data-bs-toggle="tab">
                            <i class="fas fa-info-circle me-1"></i> Course Introduction
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#course-quiz" data-bs-toggle="tab">
                            <i class="fas fa-tasks me-1"></i> Course Quiz
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Course Content Tabs -->
            <div class="tab-content course-tab-content">
                <!-- Course Introduction Tab -->
                <div class="tab-pane fade show active" id="course-intro">
                    <div class="card border-0 shadow-sm rounded-3 mb-4">
                        <div class="card-header bg-white py-3 border-0">
                            <h4 class="card-title mb-0"><i class="fas fa-info-circle me-2 text-primary"></i> Course Introduction</h4>
                        </div>
                        <div class="card-body">
                            <p class="lead"><?= $course['description'] ?></p>
                            
                            <div class="row mt-4 g-4">
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center">
                                        <div class="feature-icon bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                                            <i class="fas fa-award text-primary"></i>
                                        </div>
                                        <div>
                                            <h5 class="mb-1">Earn Certificate</h5>
                                            <p class="mb-0 text-muted">Receive a course certificate after completing the quiz</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center">
                                        <div class="feature-icon bg-success bg-opacity-10 p-3 rounded-circle me-3">
                                            <i class="fas fa-leaf text-success"></i>
                                        </div>
                                        <div>
                                            <h5 class="mb-1">Environmental Contribution</h5>
                                            <p class="mb-0 text-muted">Learning helps reduce environmental pollution</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Learning Objectives -->
                    <div class="card border-0 shadow-sm rounded-3 mb-4">
                        <div class="card-header bg-white py-3 border-0">
                            <h4 class="card-title mb-0"><i class="fas fa-bullseye me-2 text-primary"></i> Learning Objectives</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled">
                                <li class="mb-3 d-flex">
                                    <i class="fas fa-check-circle text-success me-2 mt-1"></i>
                                    <span>Understand the basic concepts and importance of environmental recycling</span>
                                </li>
                                <li class="mb-3 d-flex">
                                    <i class="fas fa-check-circle text-success me-2 mt-1"></i>
                                    <span>Master the classification methods for different recyclable materials</span>
                                </li>
                                <li class="mb-3 d-flex">
                                    <i class="fas fa-check-circle text-success me-2 mt-1"></i>
                                    <span>Learn how to practice environmental recycling in daily life</span>
                                </li>
                                <li class="d-flex">
                                    <i class="fas fa-check-circle text-success me-2 mt-1"></i>
                                    <span>Understand the positive impact of environmental recycling on the environment and society</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                
                
                <!-- Course Quiz Tab -->
                <div class="tab-pane fade" id="course-quiz">
                    <div class="card border-0 shadow-sm rounded-3 mb-4">
                        <div class="card-header bg-white py-3 border-0">
                            <h4 class="card-title mb-0"><i class="fas fa-tasks me-2 text-primary"></i> Course Quiz</h4>
                        </div>
                        <div class="card-body">
                            <div class="quiz-info mb-4">
                                <div class="row g-4">
                                    <div class="col-md-4">
                                        <div class="d-flex align-items-center">
                                            <div class="bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                                                <i class="fas fa-question text-primary"></i>
                                            </div>
                                            <div>
                                                <h5 class="mb-1">Quiz Questions</h5>
                                                <p class="mb-0 text-primary fw-bold"><?= $questionCount ?? 0 ?> Questions</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="d-flex align-items-center">
                                            <div class="bg-warning bg-opacity-10 p-3 rounded-circle me-3">
                                                <i class="fas fa-clock text-warning"></i>
                                            </div>
                                            <div>
                                                <h5 class="mb-1">Completion Time</h5>
                                                <p class="mb-0 text-warning fw-bold">No Time Limit</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="d-flex align-items-center">
                                            <div class="bg-success bg-opacity-10 p-3 rounded-circle me-3">
                                                <i class="fas fa-trophy text-success"></i>
                                            </div>
                                            <div>
                                                <h5 class="mb-1">Passing Score</h5>
                                                <p class="mb-0 text-success fw-bold">60 points</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="quiz-action text-center py-3">
                                <?php if (session()->get('isLoggedIn')): ?>
                                <p class="text-muted mt-3">Please complete the course content before taking the quiz</p>
                                <?php else: ?>
                                <div class="alert alert-warning py-4">
                                    <i class="fas fa-exclamation-triangle me-2"></i> You need to <a href="<?= base_url('auth/login') ?>" class="alert-link">login</a> to take the quiz and earn a certificate
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Start Learning Button -->
            <div class="text-center mb-5">
                <a href="<?= base_url('courses/learn/' . $course['id']) ?>" class="btn btn-success btn-lg px-5">
                    <i class="fas fa-book-reader me-2"></i> Start Learning
                </a>
            </div>
            
            
        </div>
        
        <!-- Right Sidebar -->
        <div class="col-lg-4">
            <!-- Course Action Card -->
            <div class="card border-0 shadow-sm rounded-3 mb-4" style="z-index: 1;">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="card-title mb-0"><i class="fas fa-graduation-cap me-2"></i> Course Details</h5>
                </div>
                <div class="card-body p-4">
                    <!-- Course Stats -->
                    <div class="course-stats mb-4">
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="border rounded-3 p-3 text-center">
                                    <h5 class="mb-0"><i class="fas fa-users text-primary me-1"></i> <?= $enrollmentCount ?? 0 ?></h5>
                                    <small class="text-muted">Enrolled</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="border rounded-3 p-3 text-center">
                                    <h5 class="mb-0"><i class="fas fa-certificate text-success me-1"></i> <?= $certificateCount ?? 0 ?></h5>
                                    <small class="text-muted">Certificates</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Course Info List -->
                    <ul class="list-group list-group-flush mb-4">
                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-clock text-muted me-2"></i> Duration</span>
                            <span>30 minutes</span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-list-ul text-muted me-2"></i> Difficulty</span>
                            <span>Beginner</span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-book text-muted me-2"></i> Language</span>
                            <span>English</span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-calendar-alt text-muted me-2"></i> Last Update</span>
                            <span><?= date('Y-m-d', strtotime($course['updated_at'])) ?></span>
                        </li>
                    </ul>
                    
                    <!-- Action Buttons -->
                    <div class="d-grid gap-2">
                        <a href="<?= base_url('courses/learn/' . $course['id']) ?>" class="btn btn-success">
                            <i class="fas fa-book-reader me-1"></i> Start Learning
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Related Courses -->
            <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-header bg-white py-3 border-0">
                    <h5 class="card-title mb-0"><i class="fas fa-link me-2 text-primary"></i> Related Courses</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($relatedCourses)): ?>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($relatedCourses as $relatedCourse): ?>
                        <li class="list-group-item px-0">
                            <a href="<?= base_url('courses/view/' . $relatedCourse['id']) ?>" class="text-decoration-none">
                                <div class="d-flex align-items-center">
                                    <?php if (!empty($relatedCourse['image'])): ?>
                                    <div class="flex-shrink-0">
                                        <img src="<?= base_url('uploads/courses/' . $relatedCourse['image']) ?>" class="rounded" width="60" height="45" alt="<?= $relatedCourse['title'] ?>" style="object-fit: cover;">
                                    </div>
                                    <?php else: ?>
                                    <div class="flex-shrink-0 bg-light rounded d-flex justify-content-center align-items-center" style="width: 60px; height: 45px;">
                                        <i class="fas fa-recycle text-muted"></i>
                                    </div>
                                    <?php endif; ?>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-0"><?= $relatedCourse['title'] ?></h6>
                                        <small class="text-muted"><?= date('Y-m-d', strtotime($relatedCourse['created_at'])) ?></small>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-info-circle mb-2"></i>
                        <p class="mb-0">No related courses available at this time</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Share Card -->
            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-header bg-white py-3 border-0">
                    <h5 class="card-title mb-0"><i class="fas fa-share-alt me-2 text-primary"></i> Share This Course</h5>
                </div>
                <div class="card-body">
                    <div class="social-share d-flex justify-content-center gap-2">
                        <a href="#" class="btn btn-outline-primary rounded-circle social-btn" title="Share on Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="btn btn-outline-info rounded-circle social-btn" title="Share on Twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="btn btn-outline-success rounded-circle social-btn" title="Share on WhatsApp">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                        <a href="#" class="btn btn-outline-secondary rounded-circle social-btn" title="Share via Email">
                            <i class="fas fa-envelope"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Custom Course Styles */
.course-content img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin: 1rem 0;
}

.course-tab-content {
    min-height: 400px;
}

.nav-pills .nav-link {
    color: var(--dark-color);
    border-radius: 0;
    padding: 0.75rem 1rem;
    font-weight: 500;
    border-bottom: 2px solid transparent;
}

.nav-pills .nav-link.active {
    background-color: transparent;
    color: var(--primary-color);
    border-bottom: 2px solid var(--primary-color);
}

.feature-icon {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Fade In Animation */
.tab-pane.fade {
    transition: all 0.3s ease;
}

.tab-pane.fade.show {
    opacity: 1;
}
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Check course completion status and set quiz button behavior
    const courseId = '<?= $course['id'] ?>';
    const isCourseCompleted = localStorage.getItem('course_' + courseId + '_completed') === 'true';
    
    // Get all quiz buttons
    const quizButtons = document.querySelectorAll('a[href*="startQuiz/' + courseId + '"]');
    
    quizButtons.forEach(button => {
        // Update button style based on completion status
        if (!isCourseCompleted) {
            button.classList.remove('btn-primary');
            button.classList.add('btn-secondary');
            
            // Add lock icon
            const icon = button.querySelector('i');
            if (icon) {
                icon.className = 'fas fa-lock me-1';
            }
            
            // Add tooltip text
            const tooltipText = document.createElement('small');
            tooltipText.className = 'd-block text-muted mt-1';
            tooltipText.innerHTML = '<i class="fas fa-info-circle"></i> Please complete the course content first';
            
            // For large buttons, add directly to the button
            if (button.classList.contains('btn-lg')) {
                button.innerHTML += ' <small class="d-block mt-1"><i class="fas fa-info-circle"></i> Please complete the course content first</small>';
            } else {
                // For small buttons, add to parent element
                button.parentNode.appendChild(tooltipText);
            }
        }
        
        button.addEventListener('click', function(e) {
            if (!isCourseCompleted) {
                e.preventDefault();
                if (confirm('You must complete the course before taking the quiz. Would you like to be redirected to the course learning page?')) {
                    window.location.href = '<?= base_url('courses/learn/' . $course['id']) ?>';
                }
            }
        });
    });
    
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Handle bookmark button click event
    document.getElementById('bookmark-btn').addEventListener('click', function() {
        const courseId = this.dataset.courseId;
        const isBookmarked = this.classList.contains('btn-warning');
        
        // Send AJAX request to update bookmark status
        fetch('<?= base_url('courses/bookmark/' . $course['id']) ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: ''
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update button text and icon
                const bookmarkText = document.getElementById('bookmark-text');
                if (bookmarkText) {
                    bookmarkText.textContent = isBookmarked ? 'Bookmark Course' : 'Remove Bookmark';
                }
                this.classList.toggle('btn-warning');
                this.classList.toggle('btn-light');
                
                // Update icon
                const bookmarkIcon = this.querySelector('i');
                if (bookmarkIcon) {
                    bookmarkIcon.className = isBookmarked ? 'far fa-bookmark me-1' : 'fas fa-bookmark me-1';
                }
                
                // Show success toast
                const toastContainer = document.getElementById('bookmarkToast');
                if (toastContainer) {
                    // Update toast message
                    const toastMessage = document.getElementById('toast-message');
                    if (toastMessage) {
                        toastMessage.textContent = data.message;
                    }
                    
                    const toast = new bootstrap.Toast(toastContainer, {
                        autohide: true,
                        delay: 3000
                    });
                    toast.show();
                }
            } else {
                alert('Bookmark failed: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error toggling bookmark:', error);
            alert('Bookmark failed, please try again later.');
        });
    });
    
    // Listen for hash changes to activate corresponding tabs
    function activateTabFromHash() {
        const hash = window.location.hash;
        if (hash) {
            const tabTrigger = document.querySelector(`a[href="${hash}"]`);
            if (tabTrigger) {
                new bootstrap.Tab(tabTrigger).show();
            }
        }
    }
    
    // Check on page load
    activateTabFromHash();
    
    // Listen for hash changes
    window.addEventListener('hashchange', activateTabFromHash);
});
</script>
<?= $this->endSection() ?> 