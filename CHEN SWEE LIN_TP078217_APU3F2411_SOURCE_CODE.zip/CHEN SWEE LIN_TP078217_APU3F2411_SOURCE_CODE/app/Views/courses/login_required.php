<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Login Required Page -->
<div class="container py-5">
    <div class="row">
        <!-- Left Column -->
        <div class="col-lg-6 mb-5 mb-lg-0">
            <div class="card border-0 shadow-sm overflow-hidden">
                <div class="card-body p-5">
                    <div class="text-center mb-5">
                        <img src="<?= base_url('assets/images/eco-logo.png') ?>" alt="Platform Logo" class="img-fluid mb-3" style="max-height: 80px;">
                        <h2 class="fw-bold">Smart Waste Sorting Assistant</h2>
                        <p class="lead opacity-75">Raise environmental awareness, learn recycling knowledge</p>
                    </div>
                    
                    <div class="features-list">
                        <div class="d-flex align-items-center mb-4">
                            <div class="feature-icon bg-success bg-opacity-10 text-success rounded-circle p-3 me-3">
                                <i class="fas fa-lock"></i>
                            </div>
                            <div>Get full access to course learning materials</div>
                        </div>
                        
                        <div class="d-flex align-items-center mb-4">
                            <div class="feature-icon bg-success bg-opacity-10 text-success rounded-circle p-3 me-3">
                                <i class="fas fa-certificate"></i>
                            </div>
                            <div>Take course quizzes and get certificates</div>
                        </div>
                        
                        <div class="d-flex align-items-center mb-4">
                            <div class="feature-icon bg-success bg-opacity-10 text-success rounded-circle p-3 me-3">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <div>Track your learning progress and achievements</div>
                        </div>
                        
                        <div class="d-flex align-items-center mb-4">
                            <div class="feature-icon bg-success bg-opacity-10 text-success rounded-circle p-3 me-3">
                                <i class="fas fa-comments"></i>
                            </div>
                            <div>Participate in community discussions, share environmental insights</div>
                        </div>
                        
                        <p class="small opacity-75">Join our environmental community, protect our planet together</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Right Column -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-5 text-center">
                    <h2 class="mb-2">Login Required</h2>
                    <p class="text-muted">Please login or register to access the full course content</p>
                    
                    <div class="row mt-5">
                        <div class="col-md-10 mx-auto">
                            <div class="alert alert-info">
                                <h5 class="alert-heading">Why Login is Required?</h5>
                                <p class="mb-0">After logging in, you will be able to access the full course content, take quizzes, track learning progress, receive personalized recommendations, and more features. We promise not to misuse your personal information.</p>
                            </div>
                            
                            <div class="d-grid gap-3 mt-4">
                                <a href="<?= base_url('auth/login') ?>" class="btn btn-primary btn-lg">
                                    <i class="fas fa-sign-in-alt me-2"></i> Login to Your Account
                                </a>
                                <a href="<?= base_url('auth/register') ?>" class="btn btn-outline-primary btn-lg">
                                    <i class="fas fa-user-plus me-2"></i> Register a New Account
                                </a>
                            </div>
                            
                            <div class="mt-4 text-center">
                                <a href="<?= base_url() ?>" class="btn btn-link text-decoration-none">
                                    <i class="fas fa-home me-1"></i> Return to Homepage
                                </a>
                                <a href="<?= base_url('about') ?>" class="btn btn-link text-decoration-none ms-3">
                                    <i class="fas fa-info-circle me-1"></i> About Us
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Trust Indicators -->
            <div class="text-center mt-5">
                <h6 class="text-muted mb-4">Trusted Partners</h6>
                <div class="row g-4">
                    <div class="col-4">
                        <img src="https://via.placeholder.com/100x50?text=Partner" class="img-fluid opacity-50" alt="Partner">
                    </div>
                    <div class="col-4">
                        <img src="https://via.placeholder.com/100x50?text=Partner" class="img-fluid opacity-50" alt="Partner">
                    </div>
                    <div class="col-4">
                        <img src="https://via.placeholder.com/100x50?text=Partner" class="img-fluid opacity-50" alt="Partner">
                    </div>
                    <div class="col-4">
                        <img src="https://via.placeholder.com/100x50?text=Partner" class="img-fluid opacity-50" alt="Partner">
                    </div>
                    <div class="col-4">
                        <img src="https://via.placeholder.com/100x50?text=Partner" class="img-fluid opacity-50" alt="Partner">
                    </div>
                    <div class="col-4">
                        <img src="https://via.placeholder.com/100x50?text=Partner" class="img-fluid opacity-50" alt="Partner">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .feature-icon {
        min-width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .feature-icon i {
        font-size: 1.2rem;
    }
</style>
<?= $this->endSection() ?> 