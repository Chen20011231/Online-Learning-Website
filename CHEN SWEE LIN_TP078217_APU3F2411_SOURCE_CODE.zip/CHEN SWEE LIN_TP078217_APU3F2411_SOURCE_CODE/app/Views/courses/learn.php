<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Course Learning Page Header -->
<div class="course-header py-4" style="background-color: #f8f9fa;">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= base_url() ?>" class="text-decoration-none"><i class="fas fa-home"></i> Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url('courses') ?>" class="text-decoration-none">Courses</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url('courses/view/' . $course['id']) ?>" class="text-decoration-none"><?= $course['title'] ?></a></li>
                <li class="breadcrumb-item active" aria-current="page">Learning Content</li>
            </ol>
        </nav>
    </div>
</div>

<!-- Course Learning Main Content Area -->
<div class="container py-5">
    <div class="row">
        <!-- Left Content Area -->
        <div class="col-lg-8">
            <!-- Course Title -->
            <div class="course-title-section mb-4">
                <h1 class="fw-bold mb-3"><?= $course['title'] ?> <span class="badge bg-success">Learning in Progress</span></h1>
                <div class="d-flex flex-wrap align-items-center mb-3">
                    <span class="badge bg-primary rounded-pill me-2 mb-2"><i class="fas fa-calendar-alt me-1"></i> <?= date('Y-m-d', strtotime($course['created_at'])) ?></span>
                    <span class="badge bg-success rounded-pill me-2 mb-2"><i class="fas fa-user-graduate me-1"></i> Environmental Course</span>
                    <span class="badge bg-info rounded-pill me-2 mb-2"><i class="fas fa-clock me-1"></i> Approximately 30 minutes</span>
                </div>
                <div class="progress mb-4" style="height: 10px;">
                    <div class="progress-bar bg-success" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="course-progress">0%</div>
                </div>
            </div>

            <!-- Course Content -->
            <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-header bg-white py-3 border-0 d-flex justify-content-between align-items-center">
                    <h4 class="card-title mb-0"><i class="fas fa-book me-2 text-primary"></i> Course Content</h4>
                    <div>
                        <button id="fullscreen-btn" class="btn btn-light btn-sm rounded-circle" title="Fullscreen Mode">
                            <i class="fas fa-expand"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="course-content" id="learning-content">
                        <?= $course['content'] ?>
                    </div>
                </div>
            </div>

            <!-- Course Navigation Buttons -->
            <div class="d-flex justify-content-between mb-5">
                <a href="<?= base_url('courses/view/' . $course['id']) ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Return to Course
                </a>
                <button id="nav-quiz-btn" class="btn btn-primary disabled" aria-disabled="true">
                    Take Quiz <i class="fas fa-arrow-right ms-1"></i>
                </button>
            </div>

            
        </div>
        
        <!-- Right Sidebar -->
        <div class="col-lg-4">
            <!-- Course Progress Card -->
            <div class="card border-0 shadow-sm rounded-3 mb-4" style="z-index: 99;">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="card-title mb-0"><i class="fas fa-graduation-cap me-2"></i> Learning Progress</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <span>Completion Progress</span>
                        <span class="badge bg-success" id="progress-percentage">0%</span>
                    </div>
                    <div class="progress mb-4" style="height: 8px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="sidebar-progress">0%</div>
                    </div>
                    
                    <div class="d-grid gap-2 mb-3">
                        <button id="mark-complete-btn" class="btn btn-success">
                            <i class="fas fa-check-circle me-1"></i> Mark as Completed
                        </button>
                        <button id="quiz-btn" class="btn btn-primary disabled" aria-disabled="true">
                            <i class="fas fa-tasks me-1"></i> Take Quiz
                        </button>
                    </div>
                    
                    <div class="alert alert-light border">
                        <div class="d-flex">
                            <div class="me-3">
                                <i class="fas fa-trophy text-warning fa-2x"></i>
                            </div>
                            <div>
                                <h6 class="mb-1">Complete Quiz to Get Certificate</h6>
                                <p class="mb-0 small text-muted">After completing the course and passing the quiz, you will receive a course completion certificate</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>

<style>
/* Course Content Styles */
.course-content {
    font-size: 1.05rem;
    line-height: 1.7;
}

.course-content img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin: 1rem 0;
}

.course-content h2, .course-content h3, .course-content h4 {
    margin-top: 1.5rem;
    margin-bottom: 1rem;
    font-weight: 600;
}

.course-content p {
    margin-bottom: 1.2rem;
}

.course-content ul, .course-content ol {
    margin-bottom: 1.2rem;
    padding-left: 1.5rem;
}

.course-content li {
    margin-bottom: 0.5rem;
}

/* Fullscreen Mode */
.fullscreen-mode {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: white;
    z-index: 1050;
    padding: 2rem;
    overflow-y: auto;
}

/* Button Pulse Effect */
@keyframes pulse {
    0% {
        box-shadow: 0 0 0 0 rgba(13, 110, 253, 0.7);
    }
    70% {
        box-shadow: 0 0 0 10px rgba(13, 110, 253, 0);
    }
    100% {
        box-shadow: 0 0 0 0 rgba(13, 110, 253, 0);
    }
}

.btn-pulse {
    animation: pulse 1.5s infinite;
}
</style>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Fullscreen functionality
    const fullscreenBtn = document.getElementById('fullscreen-btn');
    const learningContent = document.getElementById('learning-content');
    
    if (fullscreenBtn && learningContent) {
        fullscreenBtn.addEventListener('click', function() {
            if (learningContent.classList.contains('fullscreen-mode')) {
                // Exit fullscreen
                learningContent.classList.remove('fullscreen-mode');
                fullscreenBtn.innerHTML = '<i class="fas fa-expand"></i>';
                fullscreenBtn.setAttribute('title', 'Fullscreen Mode');
            } else {
                // Enter fullscreen
                learningContent.classList.add('fullscreen-mode');
                fullscreenBtn.innerHTML = '<i class="fas fa-compress"></i>';
                fullscreenBtn.setAttribute('title', 'Exit Fullscreen');
                
                // Add close button
                const closeBtn = document.createElement('button');
                closeBtn.className = 'btn btn-light btn-sm position-absolute top-0 end-0 m-3';
                closeBtn.innerHTML = '<i class="fas fa-times"></i> Exit Fullscreen';
                closeBtn.addEventListener('click', function() {
                    learningContent.classList.remove('fullscreen-mode');
                    fullscreenBtn.innerHTML = '<i class="fas fa-expand"></i>';
                    fullscreenBtn.setAttribute('title', 'Fullscreen Mode');
                    this.remove();
                });
                learningContent.appendChild(closeBtn);
            }
        });
    }
    
    // Progress bar functionality
    const markCompleteBtn = document.getElementById('mark-complete-btn');
    const progressBar = document.getElementById('course-progress');
    const sidebarProgress = document.getElementById('sidebar-progress');
    const progressPercentage = document.getElementById('progress-percentage');
    const quizBtn = document.getElementById('quiz-btn');
    const navQuizBtn = document.getElementById('nav-quiz-btn');
    
    if (markCompleteBtn && progressBar && sidebarProgress && progressPercentage && quizBtn && navQuizBtn) {
        // Initialize quiz buttons based on course completion status
        const isCourseCompleted = <?= $isCourseCompleted ? 'true' : 'false' ?>;
        
        if (isCourseCompleted) {
            // Enable quiz buttons if course is completed
            quizBtn.classList.remove('disabled');
            quizBtn.removeAttribute('aria-disabled');
            quizBtn.style.pointerEvents = 'auto';
            quizBtn.style.opacity = '1';
            
            navQuizBtn.classList.remove('disabled');
            navQuizBtn.removeAttribute('aria-disabled');
            
            // Set progress bar to 100%
            progressBar.style.width = '100%';
            progressBar.setAttribute('aria-valuenow', 100);
            progressBar.textContent = '100%';
            
            sidebarProgress.style.width = '100%';
            sidebarProgress.setAttribute('aria-valuenow', 100);
            
            progressPercentage.textContent = '100%';
            
            // Update button state to "Cancel Completion"
            markCompleteBtn.innerHTML = '<i class="fas fa-times-circle me-1"></i> Cancel Completion';
            markCompleteBtn.classList.remove('btn-success');
            markCompleteBtn.classList.add('btn-danger');
        } else {
            // Disable quiz buttons if course is not completed
            quizBtn.classList.add('disabled');
            quizBtn.setAttribute('aria-disabled', 'true');
            quizBtn.style.pointerEvents = 'none';
            quizBtn.style.opacity = '0.65';
            
            navQuizBtn.classList.add('disabled');
            navQuizBtn.setAttribute('aria-disabled', 'true');
            
            // Set progress bar to 0%
            progressBar.style.width = '0%';
            progressBar.setAttribute('aria-valuenow', 0);
            progressBar.textContent = '0%';
            
            sidebarProgress.style.width = '0%';
            sidebarProgress.setAttribute('aria-valuenow', 0);
            
            progressPercentage.textContent = '0%';
        }
        
        markCompleteBtn.addEventListener('click', function() {
            // Check current status - determine by button class
            const isCurrentlyCompleted = this.classList.contains('btn-danger');
            
            // Show Loading Indicator   
            const originalBtnText = this.innerHTML;
            this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> 處理中...';
            this.disabled = true;
            
            // Send request to server using AJAX
            fetch('<?= base_url('courses/updateCourseCompletion') ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
                },
                body: JSON.stringify({
                    course_id: <?= $course['id'] ?>,
                    completed: !isCurrentlyCompleted
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(result => {
                // Restore button state
                this.disabled = false;
                
                if (!isCurrentlyCompleted) {
                    // Mark as completed
                    progressBar.style.width = '100%';
                    progressBar.setAttribute('aria-valuenow', 100);
                    progressBar.textContent = '100%';
                    
                    sidebarProgress.style.width = '100%';
                    sidebarProgress.setAttribute('aria-valuenow', 100);
                    
                    progressPercentage.textContent = '100%';
                    
                    // Update button state
                    this.innerHTML = '<i class="fas fa-times-circle me-1"></i> Cancel Completion';
                    this.classList.remove('btn-success');
                    this.classList.add('btn-danger');
                    
                    // Enable quiz button
                    quizBtn.classList.remove('disabled');
                    quizBtn.removeAttribute('aria-disabled');
                    quizBtn.style.pointerEvents = 'auto';
                    quizBtn.style.opacity = '1';
                    quizBtn.classList.add('btn-pulse');
                    
                    navQuizBtn.classList.remove('disabled');
                    navQuizBtn.removeAttribute('aria-disabled');
                    navQuizBtn.classList.add('btn-pulse');
                    
                    // Show alert
                    alert('Congratulations! You have completed the course! Now you can take the quiz.');
                } else {
                    // Cancel completion status
                    progressBar.style.width = '0%';
                    progressBar.setAttribute('aria-valuenow', 0);
                    progressBar.textContent = '0%';
                    
                    sidebarProgress.style.width = '0%';
                    sidebarProgress.setAttribute('aria-valuenow', 0);
                    
                    progressPercentage.textContent = '0%';
                    
                    // Update button state
                    this.innerHTML = '<i class="fas fa-check-circle me-1"></i> Mark as Completed';
                    this.classList.remove('btn-danger');
                    this.classList.add('btn-success');
                    
                    // Disable quiz button
                    quizBtn.classList.add('disabled');
                    quizBtn.setAttribute('aria-disabled', 'true');
                    quizBtn.style.pointerEvents = 'none';
                    quizBtn.style.opacity = '0.65';
                    quizBtn.classList.remove('btn-pulse');
                    
                    navQuizBtn.classList.add('disabled');
                    navQuizBtn.setAttribute('aria-disabled', 'true');
                    navQuizBtn.classList.remove('btn-pulse');
                    
                    // Show alert
                    alert('You have cancelled the course completion status. Please continue to learn the course content.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                this.innerHTML = originalBtnText;
                this.disabled = false;
                alert('An error occurred while updating the course status. Please try again later.');
            });
        });
        
        // Sidebar quiz button click event
        quizBtn.addEventListener('click', function() {
            // If button is enabled, navigate to quiz page
            if (!this.classList.contains('disabled')) {
                window.location.href = '<?= base_url('courses/startQuiz/' . $course['id']) ?>';
            } else {
                alert('Please complete the course learning before taking the quiz!');
            }
        });
        
        // Navigation area quiz button click event
        navQuizBtn.addEventListener('click', function() {
            // If button is enabled, navigate to quiz page
            if (!this.classList.contains('disabled')) {
                window.location.href = '<?= base_url('courses/startQuiz/' . $course['id']) ?>';
            } else {
                alert('Please complete the course learning before taking the quiz!');
            }
        });
    }
    
    // Learning checklist functionality
    const checklistItems = document.querySelectorAll('.form-check-input');
    checklistItems.forEach(item => {
        item.addEventListener('change', function() {
            if (this.checked) {
                this.closest('.list-group-item').classList.add('text-muted');
                this.closest('.list-group-item').style.textDecoration = 'line-through';
            } else {
                this.closest('.list-group-item').classList.remove('text-muted');
                this.closest('.list-group-item').style.textDecoration = 'none';
            }
        });
    });
});
</script>
<?= $this->endSection() ?> 