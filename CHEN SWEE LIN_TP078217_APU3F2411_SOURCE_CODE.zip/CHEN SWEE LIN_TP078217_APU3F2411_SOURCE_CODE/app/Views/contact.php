<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Hero Section -->
<section class="contact-hero-section">
    <div class="contact-hero-overlay">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="hero-title mb-4">Contact Us</h1>
                    <p class="hero-subtitle mb-0">Have any questions or suggestions? We'd love to hear from you</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Info Section -->
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="contact-card h-100 text-center">
                    <div class="contact-icon mb-4">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h5>Our Location</h5>
                    <p class="text-muted mb-0">Jalan Teknologi 5, <br>Taman Teknologi Malaysia,<br>57000 Kuala Lumpur, Malaysia</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="contact-card h-100 text-center">
                    <div class="contact-icon mb-4">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <h5>Contact Phone</h5>
                    <p class="text-muted mb-2">Customer Service: +6012-3456789</p>
                    <p class="text-muted mb-0">Technical Support: +6017-7463839</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="contact-card h-100 text-center">
                    <div class="contact-icon mb-4">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h5>Email</h5>
                    <p class="text-muted mb-2">Customer Service: service@email.com</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Form Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-lg-8 text-center">
                <h2 class="section-title text-center">Send Message</h2>
                <p class="text-muted">Fill out the form below, and we will get back to you as soon as possible</p>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4 p-md-5">
                        <?php if (session()->getFlashdata('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <i class="fas fa-check-circle me-2"></i>
                                <?= session()->getFlashdata('success') ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (session()->getFlashdata('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <i class="fas fa-exclamation-circle me-2"></i>
                                <?= session()->getFlashdata('error') ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form action="<?= base_url('contact/submit') ?>" method="post" id="contactForm">
                            <?= csrf_field() ?>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control <?= session()->getFlashdata('errors.name') ? 'is-invalid' : '' ?>" id="name" name="name" placeholder="Your Name" value="<?= old('name') ?>" required>
                                        <label for="name">Your Name</label>
                                        <?php if (session()->getFlashdata('errors.name')): ?>
                                            <div class="invalid-feedback"><?= session()->getFlashdata('errors.name') ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="email" class="form-control <?= session()->getFlashdata('errors.email') ? 'is-invalid' : '' ?>" id="email" name="email" placeholder="Your Email" value="<?= old('email') ?>" required>
                                        <label for="email">Your Email</label>
                                        <?php if (session()->getFlashdata('errors.email')): ?>
                                            <div class="invalid-feedback"><?= session()->getFlashdata('errors.email') ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="tel" class="form-control" id="phone" name="phone" placeholder="Contact Phone" value="<?= old('phone') ?>">
                                        <label for="phone">Contact Phone</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <select class="form-select <?= session()->getFlashdata('errors.subject') ? 'is-invalid' : '' ?>" id="subject" name="subject" required>
                                            <option value="" selected disabled>Please select...</option>
                                            <option value="General Inquiry" <?= old('subject') == 'General Inquiry' ? 'selected' : '' ?>>General Inquiry</option>
                                            <option value="Technical Support" <?= old('subject') == 'Technical Support' ? 'selected' : '' ?>>Technical Support</option>
                                            <option value="Cooperation" <?= old('subject') == 'Cooperation' ? 'selected' : '' ?>>Cooperation</option>
                                            <option value="Feedback" <?= old('subject') == 'Feedback' ? 'selected' : '' ?>>Feedback</option>
                                        </select>
                                        <label for="subject">Subject</label>
                                        <?php if (session()->getFlashdata('errors.subject')): ?>
                                            <div class="invalid-feedback"><?= session()->getFlashdata('errors.subject') ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating mb-3">
                                        <textarea class="form-control <?= session()->getFlashdata('errors.message') ? 'is-invalid' : '' ?>" placeholder="Please enter your message" id="message" name="message" style="height: 200px" required><?= old('message') ?></textarea>
                                        <label for="message">Your Message</label>
                                        <?php if (session()->getFlashdata('errors.message')): ?>
                                            <div class="invalid-feedback"><?= session()->getFlashdata('errors.message') ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="checkbox" value="1" name="privacy_policy" id="privacyPolicy" required>
                                        <label class="form-check-label text-muted" for="privacyPolicy">
                                            I have read and agree to the <a href="#" class="text-decoration-none">Privacy Policy</a>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <button class="btn btn-primary btn-lg px-5" type="submit" id="submitBtn">
                                        <i class="fas fa-paper-plane me-2"></i>Send Message
                                    </button>
                                </div>
                            </div>
                        </form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Get the form element
    const contactForm = document.getElementById('contactForm');
    
    // Add submit event listener
    contactForm.addEventListener('submit', function(event) {
        // Get form fields
        const nameField = document.getElementById('name');
        const emailField = document.getElementById('email');
        const subjectField = document.getElementById('subject');
        const messageField = document.getElementById('message');
        const privacyCheckbox = document.getElementById('privacyPolicy');
        
        let isValid = true;
        
        // Validate name (at least 3 characters)
        if (nameField.value.trim().length < 3) {
            nameField.classList.add('is-invalid');
            isValid = false;
        } else {
            nameField.classList.remove('is-invalid');
        }
        
        // Validate email
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(emailField.value.trim())) {
            emailField.classList.add('is-invalid');
            isValid = false;
        } else {
            emailField.classList.remove('is-invalid');
        }
        
        // Validate subject
        if (subjectField.value === '') {
            subjectField.classList.add('is-invalid');
            isValid = false;
        } else {
            subjectField.classList.remove('is-invalid');
        }
        
        // Validate message (at least 3 characters)
        if (messageField.value.trim().length < 3) {
            messageField.classList.add('is-invalid');
            isValid = false;
        } else {
            messageField.classList.remove('is-invalid');
        }
        
        // Validate privacy policy checkbox
        if (!privacyCheckbox.checked) {
            privacyCheckbox.classList.add('is-invalid');
            isValid = false;
        } else {
            privacyCheckbox.classList.remove('is-invalid');
        }
        
        // If form is not valid, prevent submission
        if (!isValid) {
            event.preventDefault();
            alert('Please check the form for errors.');
        }
    });
});
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Map Section -->
<section class="map-section">
    <div class="container-fluid px-0">
        <div class="row g-0">
            <div class="col-12">
                <div class="map-container">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.1033207385705!2d101.69936807490718!3d3.0567754539407077!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc4abb795025d9%3A0x1c37182a714ba968!2sJalan%20Teknologi%205%2C%20Taman%20Teknologi%20Malaysia%2C%2057000%20Kuala%20Lumpur%2C%20Wilayah%20Persekutuan%20Kuala%20Lumpur%2C%20Malaysia!5e0!3m2!1sen!2s!4v1689321234567!5m2!1sen!2s" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-lg-8 text-center">
                <h2 class="section-title text-center">Frequently Asked Questions</h2>
                <p class="text-muted">Here are some common questions and answers we receive</p>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item border-0 mb-3 shadow-sm">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                How do I register as a member?
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                You can click on the "Register" button in the top right corner of the website and fill in the relevant information to become our member. After successful registration, you will be able to access all course content and participate in quizzes.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item border-0 mb-3 shadow-sm">
                        <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Are the platform's courses free?
                            </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                Currently, all our basic courses are completely free as part of our environmental education promotion. We may introduce some advanced courses or professional certifications in the future, which may require paid access.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item border-0 mb-3 shadow-sm">
                        <h2 class="accordion-header" id="headingThree">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Can I submit my own environmental content?
                            </button>
                        </h2>
                        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                We welcome you to submit your environmental content! Please contact us through the form above and explain the type of content you would like to share. Our content team will review your proposal and add it to our platform when appropriate.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item border-0 mb-3 shadow-sm">
                        <h2 class="accordion-header" id="headingFour">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                How do I get a course completion certificate?
                            </button>
                        </h2>
                        <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                After completing all sections of the course and passing the quiz, the system will automatically issue you a digital certificate. You can view and download these certificates in your personal center, and you can also share them on social media platforms.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Contact Hero Section */
.contact-hero-section {
    position: relative;
    height: 50vh;
    min-height: 300px;
    background-image: url('https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');
    background-size: cover;
    background-position: center;
    color: white;
    display: flex;
    align-items: center;
    text-align: center;
    margin-bottom: 2rem;
}

.contact-hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.6);
    display: flex;
    align-items: center;
}

/* Contact Cards */
.contact-card {
    padding: 2rem;
    border-radius: 10px;
    background-color: white;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    transition: all 0.3s;
}

.contact-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

.contact-icon {
    height: 70px;
    width: 70px;
    margin: 0 auto;
    background-color: rgba(var(--bs-primary-rgb), 0.1);
    color: var(--primary-color);
    border-radius: 50%;
    font-size: 1.75rem;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Map */
.map-container {
    width: 100%;
    height: 450px;
}

/* Accordion */
.accordion-button {
    font-weight: 500;
}

.accordion-button:not(.collapsed) {
    background-color: rgba(var(--bs-primary-rgb), 0.1);
    color: var(--primary-color);
}

.accordion-button:focus {
    box-shadow: none;
    border-color: rgba(var(--bs-primary-rgb), 0.2);
}

/* Form */
.form-floating > .form-control,
.form-floating > .form-select {
    height: calc(3.5rem + 2px);
}

.form-check-input:checked {
    background-color: var(--primary-color);
    border-color: var(--primary-color);
}
</style>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Form validation is handled by HTML5 required attributes
    // No need to prevent the default form submission
});
</script>
<?= $this->endSection() ?>

<?= $this->endSection() ?> 