<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? $title . ' - ' : '' ?>Smart Waste Sorting Assistant</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #24a148;
            --secondary-color: #0d6efd;
            --dark-color: #213547;
            --light-color: #f8f9fa;
        }
        
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            font-family: 'Poppins', sans-serif;
        }
        
        main {
            flex: 1;
        }
        
        .footer {
            margin-top: auto;
            padding: 3rem 0;
            background-color: var(--dark-color);
            color: white;
        }
        
        /* Navigation Styles */
        .navbar {
            padding: 1rem 0;
            transition: all 0.3s ease;
        }
        
        .navbar-dark {
            background-color: rgba(33, 53, 71, 0.9) !important;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
        }
        
        .navbar-brand .brand-icon {
            margin-right: 10px;
            font-size: 24px;
            color: var(--primary-color);
        }
        
        /* Logo styling enhancements */
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            letter-spacing: 0.5px;
        }
        
        .navbar-brand .brand-icon {
            margin-right: 12px;
            display: flex;
            align-items: center;
        }
        
        .navbar-brand .brand-icon img {
            height: 50px;
            width: auto;
            filter: drop-shadow(0 2px 3px rgba(0,0,0,0.2));
            transition: transform 0.3s ease;
        }
        
        .navbar-brand:hover .brand-icon img {
            transform: rotate(10deg);
        }
        
        .navbar-brand .brand-text {
            color: white;
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
        }
        
        .navbar-brand .brand-text-wrapper {
            display: flex;
            flex-direction: column;
            line-height: 1.1;
        }
        
        .navbar-brand .brand-text-primary,
        .navbar-brand .brand-text-secondary {
            font-size: 1.5rem;
        }
        
        .navbar-nav .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            margin: 0 0.2rem;
            transition: all 0.3s;
        }
        
        .navbar-dark .navbar-nav .nav-link {
            color: rgba(255, 255, 255, 0.8);
        }
        
        .navbar-dark .navbar-nav .nav-link:hover,
        .navbar-dark .navbar-nav .nav-link:focus {
            color: white;
        }
        
        .navbar-dark .navbar-nav .active .nav-link {
            color: white;
            border-bottom: 2px solid var(--primary-color);
        }
        
        .navbar-toggler {
            border: none;
            padding: 0.5rem;
        }
        
        .login-btn {
            background-color: var(--primary-color);
            color: white !important;
            border-radius: 50px;
            padding: 0.5rem 1.5rem !important;
            transition: all 0.3s;
        }
        
        .login-btn:hover {
            background-color: #198039;
            transform: translateY(-2px);
        }
        
        /* Scrolled Navbar */
        .navbar-scrolled {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 0;
        }
        
        /* Footer Styles */
        .footer-heading {
            font-weight: 600;
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 0.5rem;
        }
        
        .footer-heading:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 30px;
            height: 2px;
            background-color: var(--primary-color);
        }
        
        .footer-links {
            list-style: none;
            padding-left: 0;
        }
        
        .footer-links li {
            margin-bottom: 0.75rem;
        }
        
        .footer-links a {
            color: #adb5bd;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: white;
        }
        
        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            margin-right: 0.5rem;
            transition: all 0.3s;
        }
        
        .social-links a:hover {
            background-color: var(--primary-color);
            transform: translateY(-3px);
        }
        
        /* Responsive adjustments */
        @media (max-width: 992px) {
            .navbar-nav .nav-link {
                padding: 0.5rem 0 !important;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="<?= base_url() ?>">
                    <span class="brand-icon"><img src="<?= base_url('assets/images/eco-logo.png') ?>" alt="Eco Logo"></span>
                    <span class="brand-text-wrapper">
                        <span class="brand-text brand-text-primary">Smart Waste</span>
                        <span class="brand-text brand-text-secondary">Sorting Assistant</span>
                    </span>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="<?= base_url() ?>">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('about') ?>">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('courses') ?>">Courses</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('blogs') ?>">Blog</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('contact') ?>">Contact Us</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <?php if (session()->get('isLoggedIn')): ?>
                            <?php if (session()->get('role') === 'admin'): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?= base_url('admin') ?>">Admin Panel</a>
                                </li>
                            <?php endif; ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <?= session()->get('name') ?>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="<?= base_url('dashboard') ?>">Personal Center</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="<?= base_url('auth/logout') ?>">Logout</a></li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link login-btn" href="<?= base_url('auth/login') ?>">Login</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show m-3">
                <?= session()->getFlashdata('success') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show m-3">
                <?= session()->getFlashdata('error') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?= $this->renderSection('content') ?>
    </main>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 mb-4 mb-lg-0">
                    <h5 class="footer-heading">Smart Waste Sorting Assistant</h5>
                    <p class="text-white">We are dedicated to providing high-quality environmental recycling education content, helping more people understand the importance of environmental protection, and working together for the sustainable development of our planet.</p>
                    <div class="social-links mt-3">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                
                <div class="col-md-3 col-lg-2 offset-lg-1 mb-4 mb-md-0">
                    <h5 class="footer-heading">Quick Links</h5>
                    <ul class="footer-links">
                        <li><a href="<?= base_url() ?>">Home</a></li>
                        <li><a href="<?= base_url('about') ?>">About Us</a></li>
                        <li><a href="<?= base_url('courses') ?>">Courses</a></li>
                        <li><a href="<?= base_url('blogs') ?>">Blog</a></li>
                        <li><a href="<?= base_url('contact') ?>">Contact Us</a></li>
                    </ul>
                </div>
                
                <div class="col-md-4 col-lg-3 offset-lg-2">
                    <h5 class="footer-heading">Contact Us</h5>
                    <ul class="footer-links">
                        <li><i class="fas fa-map-marker-alt me-2"></i> Address: Jalan Teknologi 5, Taman Teknologi Malaysia, 57000 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur</li>
                        <li><i class="fas fa-phone me-2"></i> Phone: +86 10 12345678</li>
                        <li><i class="fas fa-envelope me-2"></i> Email: contact@eco-learn.com</li>
                    </ul>
                </div>
            </div>
            <hr class="my-4 bg-light opacity-25">
            <div class="row">
                <div class="col-md-6 mb-3 mb-md-0">
                    <p class="mb-0">&copy; <?= date('Y') ?> Smart Waste Sorting Assistant . All rights reserved.</p>
                </div>
                
            </div>
        </div>
    </footer>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        // Navbar scroll effect
        document.addEventListener('DOMContentLoaded', function() {
            const navbar = document.querySelector('.navbar');
            
            function toggleNavbarClass() {
                if (window.scrollY > 50) {
                    navbar.classList.add('navbar-scrolled');
                } else {
                    navbar.classList.remove('navbar-scrolled');
                }
            }
            
            // Initial check
            toggleNavbarClass();
            
            // Add event listener
            window.addEventListener('scroll', toggleNavbarClass);
            
            // Add body padding for fixed navbar
            document.body.style.paddingTop = navbar.offsetHeight + 'px';
            
            // Handle active navigation links - ONLY in the main navigation menu
            const currentLocation = window.location.pathname;
            // Specifically target only the main navigation (with mx-auto class)
            const mainNavbar = document.querySelector('.navbar-nav.mx-auto');
            const navLinks = mainNavbar.querySelectorAll('.nav-item .nav-link');
            const navItems = mainNavbar.querySelectorAll('.nav-item');
            
            // First, remove active class from all nav items in main menu
            navItems.forEach(item => item.classList.remove('active'));
            
            // Home page special case - add active class if we're on the root path
            if (currentLocation === '/' || currentLocation === '/index.php') {
                mainNavbar.querySelector('.nav-item:first-child').classList.add('active');
            } else {
                // For other pages
                let activeFound = false;
                navLinks.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href) {
                        // Extract the path from the full URL
                        const url = new URL(href, window.location.origin);
                        const linkPath = url.pathname;
                        
                        // Only activate if not the home page and path matches
                        if (linkPath !== '/' && linkPath !== '/index.php' && 
                            (currentLocation === linkPath || currentLocation.startsWith(linkPath))) {
                            // Add 'active' class to the parent nav-item
                            link.closest('.nav-item').classList.add('active');
                            activeFound = true;
                        }
                    }
                });
            }
        });
    </script>

    <?= $this->renderSection('scripts') ?>
    
    <!-- Chatbot -->
    <?= view('layouts/chatbot') ?>
</body>
</html>