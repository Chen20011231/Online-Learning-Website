<!-- Only keep chatbot launcher icon button -->
<button id="chatbot-launcher" class="chatbot-launcher">
    <i class="fas fa-robot"></i>
</button>

<!-- Chatbot Window -->
<div id="chatbot-container" class="chatbot-container" style="display:none;">
    <div class="chatbot-header">
        <h5>Smart Waste Sorting Assistant</h5>
        <button id="chatbot-close" class="chatbot-toggle-btn">×</button>
    </div>
    <div class="chatbot-body" id="chatbot-messages"></div>
    <div class="chatbot-footer">
        <input type="file" id="chatbot-image" accept="image/*" style="display:none;">
        <button id="chatbot-image-btn" title="Upload Image">📷</button>
        <input type="text" id="chatbot-input" placeholder="Type your message...">
        <button id="chatbot-send">Send</button>
    </div>
</div>

<style>
    .chatbot-launcher {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background-color: var(--primary-color);
        color: white;
        border: none;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18);
        font-size: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        z-index: 1000;
        transition: all 0.3s;
    }
    .chatbot-launcher:hover {
        transform: scale(1.1);
        background: linear-gradient(135deg, var(--primary-color), #43cea2);
    }
    .chatbot-container {
        position: fixed;
        bottom: 100px;
        right: 30px;
        width: 370px;
        height: 540px;
        background: #f9f9fb;
        border-radius: 18px;
        box-shadow: 0 8px 32px rgba(60, 60, 120, 0.18);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        z-index: 1001;
        border: 1.5px solid #e0e0e0;
    }
    .chatbot-header {
        background: linear-gradient(90deg, var(--primary-color) 60%, #43cea2 100%);
        color: white;
        padding: 18px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 1.18rem;
        font-weight: 600;
        letter-spacing: 0.5px;
        border-bottom: 1.5px solid #e0e0e0;
    }
    .chatbot-header h5 {
        margin: 0;
        font-size: 1.18rem;
        font-weight: 700;
        letter-spacing: 0.5px;
    }
    .chatbot-toggle-btn {
        background: none;
        border: none;
        color: white;
        font-size: 22px;
        cursor: pointer;
        transition: color 0.2s;
    }
    .chatbot-toggle-btn:hover {
        color: #e0e0e0;
    }
    .chatbot-body {
        flex-grow: 1;
        padding: 18px 14px 10px 14px;
        overflow-y: auto;
        background: #f9f9fb;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .bot-message, .user-message {
        max-width: 85%;
        padding: 13px 16px;
        border-radius: 14px;
        margin-bottom: 8px;
        word-break: break-word;
        font-size: 15.5px;
        line-height: 1.7;
        box-shadow: 0 2px 8px rgba(60, 60, 120, 0.07);
        border: 1.2px solid #e0e0e0;
        opacity: 0;
        animation: fadeInMsg 0.4s forwards;
    }
    @keyframes fadeInMsg {
        from { opacity: 0; transform: translateY(16px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .bot-message {
        align-self: flex-start;
        background: linear-gradient(120deg, #e3f2fd 80%, #f9f9fb 100%);
        color: #222;
        border-top-left-radius: 4px;
    }
    .user-message {
        align-self: flex-end;
        background: linear-gradient(120deg, #e8f5e9 80%, #f9f9fb 100%);
        color: #222;
        margin-left: auto;
        border-top-right-radius: 4px;
    }
    .user-message img {
        display: block;
        max-width: 140px;
        border-radius: 10px;
        margin-bottom: 6px;
        background: #fff;
        border: 1.5px solid #e0e0e0;
        box-shadow: 0 2px 8px rgba(60, 60, 120, 0.10);
        padding: 4px;
    }
    .chatbot-footer {
        padding: 14px 14px 14px 14px;
        display: flex;
        border-top: 1.5px solid #e0e0e0;
        background: #f5f5f7;
        align-items: center;
        gap: 8px;
    }
    #chatbot-input {
        flex-grow: 1;
        padding: 12px 16px;
        border: 1.5px solid #d0d0d0;
        border-radius: 22px;
        margin-right: 8px;
        outline: none;
        font-size: 15.5px;
        background: #fff;
        transition: border 0.2s;
    }
    #chatbot-input:focus {
        border: 1.5px solid var(--primary-color);
        background: #f0f8ff;
    }
    #chatbot-send, #chatbot-image-btn {
        background: linear-gradient(135deg, var(--primary-color), #43cea2);
        color: white;
        border: none;
        border-radius: 50%;
        width: 44px;
        height: 44px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-left: 0;
        font-size: 20px;
        box-shadow: 0 2px 8px rgba(60, 60, 120, 0.10);
        transition: background 0.2s, transform 0.2s;
    }
    #chatbot-send:hover, #chatbot-image-btn:hover {
        background: linear-gradient(135deg, #43cea2, var(--primary-color));
        transform: scale(1.08);
    }
    #chatbot-send {
        font-size: 15px;
    }
</style>

<script>
// Gemini API config
const GEMINI_API_KEY = "AIzaSyAIzdV86p-j-GYvKPX9rlxkmzmkaj1qOrE";
const TEXT_MODEL = "gemini-2.5-flash";
const VISION_MODEL = "gemini-1.5-flash";

// Open/close chatbot window
const launcher = document.getElementById('chatbot-launcher');
const container = document.getElementById('chatbot-container');
const closeBtn = document.getElementById('chatbot-close');
launcher.onclick = () => {
    container.style.display = 'flex';
    launcher.style.display = 'none';
};
closeBtn.onclick = () => {
    container.style.display = 'none';
    launcher.style.display = 'flex';
};

// Send text message
const sendBtn = document.getElementById('chatbot-send');
const inputBox = document.getElementById('chatbot-input');
sendBtn.onclick = async () => {
    const input = inputBox.value.trim();
    if (!input) return;
    addMessage(input, 'user');
    inputBox.value = '';
    addMessage('Thinking...', 'bot');
    const reply = await geminiText(input);
    updateLastBotMessage(reply);
};
// Enter to send
inputBox.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') sendBtn.onclick();
});

// Select image
const imageBtn = document.getElementById('chatbot-image-btn');
const imageInput = document.getElementById('chatbot-image');
imageBtn.onclick = () => imageInput.click();
imageInput.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const base64 = await fileToBase64(file);
    addImageMessage(base64, 'user');
    //addMessage('[Image uploaded]', 'user');
    addMessage('Analyzing image...', 'bot');
    // Optimize prompt to guide AI to return only item names
    const reply = await geminiVision(base64, 'What is the main object in this image? Only reply with the object name.');
    updateLastBotMessage(reply);
};

// Add message to chat window
function addMessage(text, sender) {
    const msgDiv = document.createElement('div');
    msgDiv.className = sender === 'user' ? 'user-message' : 'bot-message';
    msgDiv.innerText = text;
    document.getElementById('chatbot-messages').appendChild(msgDiv);
    document.getElementById('chatbot-messages').scrollTop = 99999;
}
// Update last bot message
function updateLastBotMessage(text) {
    const msgs = document.querySelectorAll('#chatbot-messages .bot-message');
    if (msgs.length > 0) msgs[msgs.length - 1].innerText = text;
}

// Text chat
async function geminiText(text) {
    try {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${GEMINI_API_KEY}`, {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                contents: [{parts: [{text}]}]
            })
        });
        const data = await res.json();
        return (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0] && data.candidates[0].content.parts[0].text) ? data.candidates[0].content.parts[0].text : "No response received.";
    } catch (e) {
        return "Request failed, please try again later.";
    }
}
// Image + text chat
async function geminiVision(base64img, prompt) {
    try {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${VISION_MODEL}:generateContent?key=${GEMINI_API_KEY}`, {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                contents: [{
                    parts: [
                        {text: prompt},
                        {inline_data: {mime_type: "image/jpeg", data: base64img.replace(/^data:image\/[a-zA-Z]+;base64,/, "")}}
                    ]
                }]
            })
        });
        const data = await res.json();
        let fullText = (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0] && data.candidates[0].content.parts[0].text) ? data.candidates[0].content.parts[0].text : "No image analysis result received.";
        // Extract object name (first noun or first line)
        let objectName = extractObjectName(fullText);
        let bin = getRecycleBin(objectName);
        return `Object: ${objectName}\nRecycle Bin: ${bin}`;
    } catch (e) {
        return "Image analysis request failed, please try again later.";
    }
}
// Extract object name from Gemini response (simple: first line or first noun)
function extractObjectName(text) {
    if (!text) return "Unknown";
    // 优先匹配 'a/an/the [object]' 结构
    let match = text.match(/(?:a|an|the) ([a-zA-Z0-9\- ]+)/i);
    if (match && match[1]) {
        let object = match[1].split(/[.\,\n]/)[0].trim();
        if (object.toLowerCase() !== 'object' && object.toLowerCase() !== 'image') {
            return object;
        }
    }
    // 退回用第一行去掉“This is/It is”等
    let firstLine = text.split('\n')[0];
    firstLine = firstLine.replace(/^(This is a|This is an|This is|It is an|It is a|It is|A photo of|An image of|Image of|Photo of)\s+/i, "");
    if (firstLine.length > 40) firstLine = firstLine.split(' ')[0];
    return firstLine.trim();
}
// Map object name to recycle bin
function getRecycleBin(objectName) {
    if (!objectName) return "Unknown";
    const name = objectName.toLowerCase();
    // Blue Bin - Recyclables
    if (/(plastic|bottle|newspaper|magazine|glass|aluminum|steel|cardboard|book|paper|container|can|foil|cap|metal|tin|carton|box|envelope|brochure|catalog|mail|yogurt|jar|lid|flyer|pamphlet|tube|aerosol|spray|wire|folder|egg|comics|hanger)/.test(name)) {
        return "Blue Bin (Recyclables)";
    }
    // Green Bin - Kitchen Waste
    if (/(food|fruit|vegetable|kitchen|leftover|tea|bone|eggshell|coffee|compost|garden|yard|leaves|peel|scraps|meat|fish|shell|nut|waste|plant|bread|milk|cheese|tofu|soy|seaweed)/.test(name)) {
        return "Green Bin (Kitchen Waste)";
    }
    // Red Bin - Hazardous Waste
    if (/(battery|batteries|cell|fluorescent|bulb|paint|medicine|syringe|nail|thermometer|glue|bleach|pesticide|chemical|electronic|e-waste|pill|drug|printer|toner|oil|antifreeze|herbicide|solvent|acid|mercury|fertilizer|disinfectant|medical|phone|computer|laptop|tablet|gadget|tv|monitor|charger|cable|usb|headphones|speaker|camera|scanner|calculator|power bank|remote|console|router|modem|hard drive|flash drive|memory card|cd|dvd|ink|ammonia|cleaner|remover|dye|kerosene|gasoline|propane|lithium|radioactive|prescription|antibiotics|vape|e-cigarette)/.test(name)) {
        return "Red Bin (Hazardous Waste)";
    }
    // Black/Gray Bin - Residual Waste
    if (/(tissue|napkin|paper towel|dust|cigarette|diaper|sanitary|dirty|broken|disposable|straw|styrofoam|cotton|sponge|wrap|gum|hair|vacuum|mop|contaminated|rubber|foam|greasy|bubble|candy|chip|toothpaste|floss|band|parchment|wax|sticker|tape|latex|mask|glass|ceramics|porcelain|tampon|condom|pet|dog|cat|animal|fur|bedding|pencil|pen|marker|eraser|staple|clip|highlighter|chalk|crayon|lotion|makeup|q-tip|razor|shaving|deodorant|lipstick|foundation|toy|balloon|mirror|window|drinking|crystal|pottery|plate|cup|mug|bowl|container|wrapper)/.test(name)) {
        return "Black/Gray Bin (Residual Waste)";
    }
    // Brown Bin - Wet Waste
    if (/(wet|soup|sauce|gravy|liquid|buttermilk|yogurt|soft|sloppy|moist|dairy|leftovers)/.test(name)) {
        return "Brown Bin (Wet Waste)";
    }
    // Special Collection
    if (/(plastic bag|shopping bag|grocery bag|film|bubble wrap|packaging|ziploc|sandwich bag|freezer bag|wrap|cellophane|shrink|dry cleaning|case wrap|sleeve|retail bag|carrier bag|reusable bag|tote bag)/.test(name)) {
        return "Special Collection Point (Plastic Bags)";
    }
    // Textile
    if (/(clothes|textile|fabric|shirt|pants|jeans|dress|socks|jacket|coat|sweater|underwear|bra|hat|scarf|gloves|bedding|sheet|blanket|pillow|towel|curtain|t-shirt|blouse|skirt|shorts|sweatshirt|hoodie|sweatpants|pajamas|robe|suit|tie|belt|handbag|purse|backpack|shoes|sneakers|boots|slippers|sandals|swimwear|bikini|trunks|lingerie|leggings|yoga pants|uniform|costume|wool|cotton|polyester|nylon|silk|linen|denim|leather|suede|fleece|duvet|comforter|rug|carpet|tablecloth|napkin)/.test(name)) {
        return "Textile Bin or Charity";
    }
    return "Unknown Bin";
}
// Utility: file to base64
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}
// 新增：在聊天窗口显示图片
function addImageMessage(base64, sender) {
    const msgDiv = document.createElement('div');
    msgDiv.className = sender === 'user' ? 'user-message' : 'bot-message';
    const img = document.createElement('img');
    img.src = base64;
    img.style.maxWidth = '120px';
    img.style.borderRadius = '8px';
    img.style.marginBottom = '4px';
    msgDiv.appendChild(img);
    document.getElementById('chatbot-messages').appendChild(msgDiv);
    document.getElementById('chatbot-messages').scrollTop = 99999;
}
</script> 