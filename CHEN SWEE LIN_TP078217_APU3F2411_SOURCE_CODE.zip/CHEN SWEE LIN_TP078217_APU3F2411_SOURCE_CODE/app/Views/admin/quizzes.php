<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>
        <?php if (isset($course)): ?>
            Quiz Management for <?= $course['title'] ?>
        <?php else: ?>
            All Quizzes
        <?php endif; ?>
    </h2>
    <div>
        <?php if (isset($course)): ?>
            <a href="<?= base_url('admin/add-quiz/' . $course['id']) ?>" class="btn btn-primary">
                <i class="fas fa-plus-circle me-1"></i> Add Quiz
            </a>
            <a href="<?= base_url('admin/courses') ?>" class="btn btn-secondary ms-2">
                <i class="fas fa-arrow-left me-1"></i> Back to Course List
            </a>
        <?php else: ?>
            <a href="<?= base_url('admin/add-quiz') ?>" class="btn btn-primary">
                <i class="fas fa-plus-circle me-1"></i> Add Quiz
            </a>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <?php if (empty($quizzes)): ?>
            <div class="alert alert-info">
                No quizzes yet. Please click the "Add Quiz" button to create a new quiz.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Course</th>
                            <th>Status</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($quizzes as $index => $quiz): ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td><?= $quiz['title'] ?></td>
                                <td><?= substr($quiz['description'], 0, 80) . (strlen($quiz['description']) > 80 ? '...' : '') ?></td>
                                <td>
                                    <?php if (isset($course)): ?>
                                        <?= $course['title'] ?>
                                    <?php else: ?>
                                        <?php
                                            $courseModel = new \App\Models\CourseModel();
                                            $courseInfo = $courseModel->find($quiz['course_id']);
                                            echo $courseInfo ? $courseInfo['title'] : 'Unknown Course';
                                        ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($quiz['status'] == 'active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($quiz['created_at']) && $quiz['created_at'] != '0000-00-00 00:00:00' && strtotime($quiz['created_at']) > 0): ?>
                                        <?= date('Y-m-d', strtotime($quiz['created_at'])) ?>
                                    <?php else: ?>
                                        <span class="text-muted">Unknown</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?= base_url('admin/questions/' . $quiz['id']) ?>" class="btn btn-sm btn-info me-2" title="Manage Questions">
                                            <i class="fas fa-question-circle"></i>
                                        </a>
                                        <a href="<?= base_url('admin/delete-quiz/' . $quiz['id']) ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this quiz? All related questions will also be deleted.');">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?> 