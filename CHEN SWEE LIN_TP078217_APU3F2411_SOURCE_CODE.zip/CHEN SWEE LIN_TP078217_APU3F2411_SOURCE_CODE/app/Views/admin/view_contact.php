<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <!-- Page header -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="fas fa-envelope-open-text me-2"></i>View Contact Message
        </h1>
        <div>
            <a href="<?= base_url('admin/contacts') ?>" class="btn btn-sm btn-outline-secondary btn-action">
                <i class="fas fa-arrow-left me-1"></i> Back
            </a>
            <button type="button" class="btn btn-sm btn-success btn-action ms-2" id="replyBtn">
                <i class="fas fa-reply me-1"></i> Reply
            </button>
            <button type="button" class="btn btn-sm btn-danger btn-action ms-2" id="deleteContactBtn">
                <i class="fas fa-trash me-1"></i> Delete
            </button>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-4">
            <!-- Sender Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-user-circle me-2"></i>Sender Details
                    </h6>
                    <span class="badge <?= $contact['status'] == 'unread' ? 'bg-danger' : 'bg-success' ?> rounded-pill">
                        <?= $contact['status'] == 'unread' ? 'Unread' : 'Read' ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <div class="avatar-circle mb-3">
                            <span class="avatar-initials"><?= substr($contact['name'], 0, 1) ?></span>
                        </div>
                        <h5 class="mb-1"><?= $contact['name'] ?></h5>
                        <p class="text-muted mb-0">
                            <a href="javascript:void(0)" class="text-decoration-none reply-email-link">
                                <i class="fas fa-envelope me-1"></i><?= $contact['email'] ?>
                            </a>
                        </p>
                        <?php if (!empty($contact['phone'])): ?>
                            <p class="text-muted">
                                <a href="tel:<?= $contact['phone'] ?>" class="text-decoration-none">
                                    <i class="fas fa-phone me-1"></i><?= $contact['phone'] ?>
                                </a>
                            </p>
                        <?php endif; ?>
                    </div>
                    
                    <hr>
                    
                    <div class="mb-0">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted"><i class="far fa-calendar-alt me-1"></i>Submitted:</span>
                            <span class="fw-medium"><?= date('M d, Y', strtotime($contact['created_at'])) ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted"><i class="far fa-clock me-1"></i>Time:</span>
                            <span class="fw-medium"><?= date('h:i A', strtotime($contact['created_at'])) ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span class="text-muted"><i class="fas fa-tag me-1"></i>Subject:</span>
                            <span class="fw-medium"><?= $contact['subject'] ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-bolt me-2"></i>Quick Actions
                    </h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-success btn-action reply-btn">
                            <i class="fas fa-reply me-1"></i> Reply by Email
                        </button>
                        
                        <button type="button" class="btn btn-danger btn-action" id="deleteContactBtnQuick">
                            <i class="fas fa-trash me-1"></i> Delete Message
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-8">
            <!-- Message Content -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-comment-alt me-2"></i>Message Content
                    </h6>
                </div>
                <div class="card-body">
                    <div class="message-header mb-4">
                        <h5 class="message-subject"><?= $contact['subject'] ?></h5>
                        <div class="message-meta text-muted">
                            <small>
                                From: <strong><?= $contact['name'] ?></strong> &lt;<?= $contact['email'] ?>&gt;
                                <span class="mx-2">|</span>
                                <?= date('F d, Y \a\t h:i A', strtotime($contact['created_at'])) ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="message-content p-4 bg-light rounded">
                        <p class="mb-0"><?= nl2br(esc($contact['message'])) ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">
                    <i class="fas fa-exclamation-triangle text-danger me-2"></i>
                    Confirm Deletion
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the contact message from <strong><?= $contact['name'] ?></strong>?</p>
                <p class="text-danger"><small>This action cannot be undone.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-action" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i> Cancel
                </button>
                <form action="<?= base_url('admin/delete-contact') ?>" method="post" style="display: inline;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="contact_id" value="<?= $contact['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-action">
                        <i class="fas fa-trash me-1"></i> Confirm
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Reply Email Modal -->
<div class="modal fade" id="replyModal" tabindex="-1" aria-labelledby="replyModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="replyModalLabel">
                    <i class="fas fa-reply me-2"></i>
                    Reply to <?= $contact['name'] ?>
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="replyForm" action="<?= base_url('admin/send-reply') ?>" method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="contact_id" value="<?= $contact['id'] ?>">
                <input type="hidden" name="recipient_email" value="<?= $contact['email'] ?>">
                <input type="hidden" name="recipient_name" value="<?= $contact['name'] ?>">
                
                <div class="modal-body">
                    <div class="email-header mb-4">
                        <div class="row mb-3">
                            <div class="col-md-2">
                                <label class="col-form-label">To:</label>
                            </div>
                            <div class="col-md-10">
                                <div class="form-control-plaintext">
                                    <strong><?= $contact['name'] ?></strong> &lt;<?= $contact['email'] ?>&gt;
                                </div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-2">
                                <label for="reply-subject" class="col-form-label">Subject:</label>
                            </div>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="reply-subject" name="subject" value="Re: <?= $contact['subject'] ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="reply-message" class="form-label">Message:</label>
                        <textarea class="form-control" id="reply-message" name="message" rows="10" required>Dear <?= $contact['name'] ?>,

Thank you for contacting us regarding "<?= $contact['subject'] ?>".

[Your response here]

Best regards,
Admin Team
</textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-action" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-success btn-action" id="sendReplyBtn">
                        <i class="fas fa-paper-plane me-1"></i> Send Reply
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    /* Avatar styling */
    .avatar-circle {
        width: 80px;
        height: 80px;
        background-color: #4e73df;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 0 auto;
    }
    
    .avatar-initials {
        color: white;
        font-size: 2rem;
        font-weight: bold;
        text-transform: uppercase;
    }
    
    /* Message styling */
    .message-subject {
        font-weight: 600;
        margin-bottom: 0.5rem;
    }
    
    .message-content {
        font-size: 1rem;
        line-height: 1.6;
        white-space: pre-line;
    }
    
    .fw-medium {
        font-weight: 500 !important;
    }
    
    .rounded-pill {
        border-radius: 50rem !important;
    }
    
    /* Card styling */
    .card {
        border: none;
    }
    
    .card-header {
        background-color: #f8f9fc;
        border-bottom: 1px solid #e3e6f0;
    }
    
    /* Action button styling */
    .btn-action {
        min-width: 90px;
        border-radius: 50rem;
        padding: 0.375rem 1rem;
        font-weight: 500;
        transition: all 0.2s ease;
    }
    .btn-action:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .btn-action.btn-success {
        background-color: #2ecc71;
        border-color: #2ecc71;
    }
    .btn-action.btn-danger {
        background-color: #e74c3c;
        border-color: #e74c3c;
    }
    .btn-action.btn-outline-secondary {
        border-color: #95a5a6;
        color: #7f8c8d;
    }
    .btn-action.btn-outline-secondary:hover {
        background-color: #f8f9fa;
    }
    .btn-action.btn-outline-success {
        border-color: #2ecc71;
        color: #2ecc71;
    }
    .btn-action.btn-outline-success:hover {
        background-color: #2ecc71;
        color: white;
    }
    
    /* Reply modal styling */
    .modal-header.bg-success {
        background-color: #2ecc71 !important;
    }
    #reply-message {
        resize: vertical;
    }
    .email-header {
        border-bottom: 1px solid #e3e6f0;
        padding-bottom: 1rem;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle top delete button
    const deleteBtn = document.getElementById('deleteContactBtn');
    if (deleteBtn) {
        deleteBtn.addEventListener('click', function() {
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        });
    }
    
    // Handle quick action area delete button
    const deleteQuickBtn = document.getElementById('deleteContactBtnQuick');
    if (deleteQuickBtn) {
        deleteQuickBtn.addEventListener('click', function() {
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        });
    }
    
    // Handle reply button
    const replyBtn = document.getElementById('replyBtn');
    const replyBtns = document.querySelectorAll('.reply-btn, .reply-email-link');
    const replyModal = new bootstrap.Modal(document.getElementById('replyModal'));
    
    function showReplyModal() {
        replyModal.show();
        setTimeout(() => {
            document.getElementById('reply-message').focus();
        }, 500);
    }
    
    if (replyBtn) {
        replyBtn.addEventListener('click', showReplyModal);
    }
    
    replyBtns.forEach(btn => {
        btn.addEventListener('click', showReplyModal);
    });
    
    // Handle form submission
    const replyForm = document.getElementById('replyForm');
    const sendReplyBtn = document.getElementById('sendReplyBtn');
    
    if (replyForm) {
        replyForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Disable submit button to prevent duplicate submissions
            sendReplyBtn.disabled = true;
            sendReplyBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Sending...';
            
            // Use AJAX to submit form
            const formData = new FormData(replyForm);
            
            fetch(replyForm.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                // Hide modal
                replyModal.hide();
                
                // Show result notification
                if (data.success) {
                    // Successfully sent email
                    showAlert('success', 'Reply sent successfully!', 'Your reply has been saved and an email has been sent to ' + data.recipient);
                    
                    // Add a link to view sent replies
                    setTimeout(() => {
                        window.location.href = '<?= base_url('admin/contact-replies') ?>';
                    }, 2000);
                } else {
                    // Sending failed
                    showAlert('danger', 'Failed to send reply', data.message || 'There was an error sending your reply. Please try again.');
                }
                
                // Reset button state
                sendReplyBtn.disabled = false;
                sendReplyBtn.innerHTML = '<i class="fas fa-paper-plane me-1"></i> Send Reply';
            })
            .catch(error => {
                console.error('Error:', error);
                
                // Show error notification
                showAlert('danger', 'Error', 'There was an error processing your request. Please try again.');
                
                // Reset button state
                sendReplyBtn.disabled = false;
                sendReplyBtn.innerHTML = '<i class="fas fa-paper-plane me-1"></i> Send Reply';
                
                // Hide modal
                replyModal.hide();
            });
        });
    }
    
    // Show notification message
    function showAlert(type, title, message) {
        // Create alert element
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            <strong>${title}</strong> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        // Insert at the top of the page
        const container = document.querySelector('.container-fluid');
        container.insertBefore(alertDiv, container.firstChild);
        
        // Automatically disappear after 5 seconds
        setTimeout(() => {
            alertDiv.classList.remove('show');
            setTimeout(() => {
                alertDiv.remove();
            }, 150);
        }, 5000);
    }
});
</script>

<?= $this->endSection() ?> 