<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Question Management for <?= $quiz['title'] ?></h2>
    <div>
        <a href="<?= base_url('admin/add-question/' . $quiz['id']) ?>" class="btn btn-primary">
            <i class="fas fa-plus-circle me-1"></i> Add Question
        </a>
        <a href="<?= base_url('admin/quizzes/' . $quiz['course_id']) ?>" class="btn btn-secondary ms-2">
            <i class="fas fa-arrow-left me-1"></i> Back to Quiz List
        </a>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <h5 class="card-title">Quiz Information</h5>
        <div class="row">
            <div class="col-md-6">
                <p><strong>Quiz Title:</strong> <?= $quiz['title'] ?></p>
                <p><strong>Course:</strong> <?= $course['title'] ?></p>
            </div>
            <div class="col-md-6">
                <p><strong>Status:</strong> 
                    <?php if ($quiz['status'] == 'active'): ?>
                        <span class="badge bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Disabled</span>
                    <?php endif; ?>
                </p>
                <p><strong>Created Date:</strong> 
                    <?php if (!empty($quiz['created_at']) && $quiz['created_at'] != '0000-00-00 00:00:00' && strtotime($quiz['created_at']) > 0): ?>
                        <?= date('Y-m-d', strtotime($quiz['created_at'])) ?>
                    <?php else: ?>
                        <span class="text-muted">Unknown</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <div class="mt-2">
            <p><strong>Quiz Description:</strong></p>
            <div><?= $quiz['description'] ?></div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <h5 class="card-title">Question List <span class="badge bg-primary ms-2"><?= count($questions) ?> Questions</span></h5>
        
        <?php if (empty($questions)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i> No questions available. Please click the "Add Question" button to create new questions.
            </div>
        <?php else: ?>
            <div class="accordion" id="questionAccordion">
                <?php foreach ($questions as $index => $question): ?>
                    <?php $options = json_decode($question['options'], true); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading<?= $question['id'] ?>">
                            <button class="accordion-button <?= $index > 0 ? 'collapsed' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $question['id'] ?>" aria-expanded="<?= $index === 0 ? 'true' : 'false' ?>" aria-controls="collapse<?= $question['id'] ?>">
                                <div class="d-flex justify-content-between align-items-center w-100 me-3">
                                    <div>
                                        <span class="badge bg-secondary me-2">Question <?= $index + 1 ?></span>
                                        <?= substr($question['question'], 0, 80) . (strlen($question['question']) > 80 ? '...' : '') ?>
                                    </div>
                                    <div>
                                        <span class="badge bg-success">Answer: <?= $question['correct_answer'] ?></span>
                                    </div>
                                </div>
                            </button>
                        </h2>
                        <div id="collapse<?= $question['id'] ?>" class="accordion-collapse collapse <?= $index === 0 ? 'show' : '' ?>" aria-labelledby="heading<?= $question['id'] ?>" data-bs-parent="#questionAccordion">
                            <div class="accordion-body">
                                <div class="mb-3">
                                    <h6 class="fw-bold">Question Content:</h6>
                                    <p><?= $question['question'] ?></p>
                                </div>
                                
                                <div class="mb-3">
                                    <h6 class="fw-bold">Options:</h6>
                                    <div class="row">
                                        <?php foreach ($options as $key => $value): ?>
                                            <div class="col-md-6 mb-2">
                                                <div class="card <?= $key == $question['correct_answer'] ? 'border-success' : '' ?>">
                                                    <div class="card-body py-2">
                                                        <div class="d-flex align-items-center">
                                                            <span class="badge <?= $key == $question['correct_answer'] ? 'bg-success' : 'bg-secondary' ?> me-2"><?= $key ?></span>
                                                            <?= $value ?>
                                                            <?php if ($key == $question['correct_answer']): ?>
                                                                <i class="fas fa-check-circle text-success ms-2"></i>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-end">
                                    <a href="<?= base_url('admin/edit-question/' . $question['id']) ?>" class="btn btn-warning btn-sm me-3">
                                        <i class="fas fa-edit me-1"></i> Edit
                                    </a>
                                    <a href="<?= base_url('admin/delete-question/' . $question['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this question? This action cannot be undone.');">
                                        <i class="fas fa-trash me-1"></i> Delete
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="mt-4 d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted">Total: <?= count($questions) ?> questions</span>
                </div>
                <a href="<?= base_url('admin/add-question/' . $quiz['id']) ?>" class="btn btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> Add More Questions
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?> 