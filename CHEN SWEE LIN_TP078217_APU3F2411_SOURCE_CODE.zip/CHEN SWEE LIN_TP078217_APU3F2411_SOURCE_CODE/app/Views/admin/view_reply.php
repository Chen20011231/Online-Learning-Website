<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <!-- Page header -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="fas fa-paper-plane me-2"></i>View Sent Reply
        </h1>
        <div>
            <a href="<?= base_url('admin/contact-replies') ?>" class="btn btn-sm btn-outline-secondary btn-action">
                <i class="fas fa-arrow-left me-1"></i> Back
            </a>
            <button type="button" class="btn btn-sm btn-danger btn-action ms-2" id="deleteReplyBtn">
                <i class="fas fa-trash me-1"></i> Delete
            </button>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-4">
            <!-- Recipient Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-user-circle me-2"></i>Recipient Details
                    </h6>
                    <span class="badge bg-success rounded-pill">
                        Sent
                    </span>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <div class="avatar-circle mb-3">
                            <span class="avatar-initials"><?= substr($reply['recipient_name'], 0, 1) ?></span>
                        </div>
                        <h5 class="mb-1"><?= $reply['recipient_name'] ?></h5>
                        <p class="text-muted mb-0">
                            <a href="mailto:<?= $reply['recipient_email'] ?>" class="text-decoration-none">
                                <i class="fas fa-envelope me-1"></i><?= $reply['recipient_email'] ?>
                            </a>
                        </p>
                    </div>
                    
                    <hr>
                    
                    <div class="mb-0">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted"><i class="far fa-calendar-alt me-1"></i>Sent Date:</span>
                            <span class="fw-medium"><?= date('M d, Y', strtotime($reply['created_at'])) ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted"><i class="far fa-clock me-1"></i>Time:</span>
                            <span class="fw-medium"><?= date('h:i A', strtotime($reply['created_at'])) ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span class="text-muted"><i class="fas fa-tag me-1"></i>Subject:</span>
                            <span class="fw-medium"><?= $reply['subject'] ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Original Message Link -->
            <?php if (isset($contact) && $contact): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-reply-all me-2"></i>Original Message
                    </h6>
                </div>
                <div class="card-body">
                    <a href="<?= base_url('admin/view-contact/' . $contact['id']) ?>" class="btn btn-primary btn-block">
                        <i class="fas fa-eye me-1"></i> View Original Message
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-lg-8">
            <!-- Message Content -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-envelope-open-text me-2"></i>Reply Content
                    </h6>
                </div>
                <div class="card-body">
                    <div class="message-header mb-4">
                        <h5 class="message-subject"><?= $reply['subject'] ?></h5>
                        <div class="message-meta text-muted">
                            <small>
                                To: <strong><?= $reply['recipient_name'] ?></strong> &lt;<?= $reply['recipient_email'] ?>&gt;
                                <span class="mx-2">|</span>
                                <?= date('F d, Y \a\t h:i A', strtotime($reply['created_at'])) ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="message-content p-4 bg-light rounded">
                        <p class="mb-0"><?= nl2br(esc($reply['message'])) ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Email Status -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-info-circle me-2"></i>Email Status
                    </h6>
                </div>
                <div class="card-body">
                    <div class="alert alert-success mb-0">
                        <i class="fas fa-check-circle me-2"></i> This reply has been sent successfully to <?= $reply['recipient_email'] ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">
                    <i class="fas fa-exclamation-triangle text-danger me-2"></i>
                    Confirm Deletion
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the reply sent to <strong><?= $reply['recipient_name'] ?></strong>?</p>
                <p class="text-danger"><small>This action cannot be undone.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-action" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i> Cancel
                </button>
                <form action="<?= base_url('admin/delete-reply') ?>" method="post" style="display: inline;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="reply_id" value="<?= $reply['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-action">
                        <i class="fas fa-trash me-1"></i> Confirm
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    /* Avatar styling */
    .avatar-circle {
        width: 80px;
        height: 80px;
        background-color: #4e73df;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 0 auto;
    }
    
    .avatar-initials {
        color: white;
        font-size: 2rem;
        font-weight: bold;
        text-transform: uppercase;
    }
    
    /* Message styling */
    .message-subject {
        font-weight: 600;
        margin-bottom: 0.5rem;
    }
    
    .message-content {
        font-size: 1rem;
        line-height: 1.6;
        white-space: pre-line;
    }
    
    .fw-medium {
        font-weight: 500 !important;
    }
    
    .rounded-pill {
        border-radius: 50rem !important;
    }
    
    /* Card styling */
    .card {
        border: none;
    }
    
    .card-header {
        background-color: #f8f9fc;
        border-bottom: 1px solid #e3e6f0;
    }
    
    /* Action button styling */
    .btn-action {
        min-width: 90px;
        border-radius: 50rem;
        padding: 0.375rem 1rem;
        font-weight: 500;
        transition: all 0.2s ease;
    }
    .btn-action:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .btn-action.btn-success {
        background-color: #2ecc71;
        border-color: #2ecc71;
    }
    .btn-action.btn-danger {
        background-color: #e74c3c;
        border-color: #e74c3c;
    }
    .btn-action.btn-outline-secondary {
        border-color: #95a5a6;
        color: #7f8c8d;
    }
    .btn-action.btn-outline-secondary:hover {
        background-color: #f8f9fa;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle delete button
    const deleteBtn = document.getElementById('deleteReplyBtn');
    if (deleteBtn) {
        deleteBtn.addEventListener('click', function() {
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        });
    }
});
</script>

<?= $this->endSection() ?> 