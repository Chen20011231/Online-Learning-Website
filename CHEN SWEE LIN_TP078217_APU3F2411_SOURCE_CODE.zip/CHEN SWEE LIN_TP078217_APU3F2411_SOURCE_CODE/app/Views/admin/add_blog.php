<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Add Blog</h2>
    <a href="<?= base_url('admin/blogs') ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-1"></i> Back to Blog List
    </a>
</div>

<div class="card">
    <div class="card-body">
        <?php if (session()->getFlashdata('errors')): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?= session()->getFlashdata('error') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <form action="<?= base_url('admin/create-blog') ?>" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            
            <div class="mb-3">
                <label for="title" class="form-label">Blog Title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?= old('title') ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="editor" class="form-label">Blog Content</label>
                <textarea class="form-control" id="editor" rows="15"><?= old('content') ?></textarea>
                <input type="hidden" name="content" id="content">
            </div>
            
            <div class="mb-3">
                <label for="image" class="form-label">Blog Cover Image</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*">
                <div class="form-text">Recommended image size: 1200x630</div>
            </div>
            
            <div class="mb-3">
                <label for="status" class="form-label">Blog Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="active" <?= old('status') == 'active' || old('status') == '' ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= old('status') == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Publish Blog
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    // Use CKEditor to enhance the text editor
    let editor;
    ClassicEditor
        .create(document.querySelector('#editor'))
        .then(newEditor => {
            editor = newEditor;
        })
        .catch(error => {
            console.error(error);
        });
    
    // Write editor content to hidden field before form submission
    document.querySelector('form').addEventListener('submit', function(e) {
        document.querySelector('#content').value = editor.getData();
    });
</script>
<?= $this->endSection() ?> 