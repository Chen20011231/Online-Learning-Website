<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <!-- Page header -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">
                <i class="fas fa-paper-plane me-2 text-primary"></i>Sent Replies
            </h1>
            <p class="text-muted mb-0">History of replies sent to contact messages</p>
        </div>
        <div>
            <a href="<?= base_url('admin/contacts') ?>" class="btn btn-sm btn-outline-primary rounded-pill">
                <i class="fas fa-envelope-open-text me-1"></i> Back to Messages
            </a>
        </div>
    </div>

    
    
    <!-- Replies list container -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-history me-2"></i>Reply History
            </h6>
            
        </div>
        <div class="card-body">
            <?php if (empty($replies)): ?>
                <div class="text-center py-5">
                   
                    <h4 class="text-gray-800">No Replies Sent</h4>
                    <p class="text-muted">You haven't sent any replies to contact messages yet</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped" id="repliesTable">
                        <thead class="table-light">
                            <tr>
                                <th width="5%" class="text-center">#</th>
                                <th width="15%">Recipient</th>
                                <th width="20%">Email</th>
                                <th width="25%">Subject</th>
                                <th width="15%">Sent Date</th>
                                <th width="20%" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($replies as $index => $reply): ?>
                                <tr>
                                    <td class="text-center align-middle"><?= $index + 1 ?></td>
                                    <td class="align-middle">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-xs me-2">
                                                <span class="avatar-title rounded-circle bg-secondary">
                                                    <?= substr($reply['recipient_name'], 0, 1) ?>
                                                </span>
                                            </div>
                                            <div>
                                                <span class="fw-medium"><?= $reply['recipient_name'] ?></span>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="align-middle">
                                        <a href="mailto:<?= $reply['recipient_email'] ?>" class="text-decoration-none">
                                            <?= $reply['recipient_email'] ?>
                                        </a>
                                    </td>
                                    <td class="align-middle">
                                        <?= $reply['subject'] ?>
                                    </td>
                                    <td class="align-middle">
                                        <div class="d-flex align-items-center">
                                            <i class="far fa-calendar-alt me-2 text-muted"></i>
                                            <div>
                                                <div><?= date('M d, Y', strtotime($reply['created_at'])) ?></div>
                                                <small class="text-muted"><?= date('h:i A', strtotime($reply['created_at'])) ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="align-middle text-end">
                                        <a href="<?= base_url('admin/view-reply/' . $reply['id']) ?>" class="btn btn-sm btn-success btn-action-icon me-1" data-bs-toggle="tooltip" title="View Reply">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger btn-action-icon delete-btn" data-id="<?= $reply['id'] ?>" data-name="<?= $reply['recipient_name'] ?>" data-bs-toggle="tooltip" title="Delete Reply">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteConfirmModal" tabindex="-1" aria-labelledby="deleteConfirmModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteConfirmModalLabel">
                    <i class="fas fa-exclamation-triangle text-danger me-2"></i>
                    Confirm Deletion
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the reply sent to <strong id="deleteReplyName"></strong>?</p>
                <p class="text-danger"><small>This action cannot be undone.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-action" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i> Cancel
                </button>
                <form id="deleteReplyForm" action="<?= base_url('admin/delete-reply') ?>" method="post" style="display: inline;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="reply_id" id="deleteReplyId">
                    <button type="submit" class="btn btn-danger btn-action">
                        <i class="fas fa-trash me-1"></i> Confirm
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    /* Custom styling for the replies page */
    .border-left-primary {
        border-left: 0.25rem solid #4e73df !important;
    }
    .table-striped > tbody > tr:nth-of-type(odd) > * {
        --bs-table-accent-bg: rgba(0, 0, 0, 0.02);
    }
    #repliesTable th {
        border-top: none;
    }
    .rounded-pill {
        border-radius: 50rem !important;
    }
    .fw-medium {
        font-weight: 500 !important;
    }
    
    /* Action button styling */
    .btn-action {
        min-width: 90px;
        border-radius: 50rem;
        padding: 0.375rem 1rem;
        font-weight: 500;
        transition: all 0.2s ease;
    }
    .btn-action:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    
    /* Icon button styling */
    .btn-action-icon {
        width: 36px;
        height: 36px;
        padding: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: all 0.2s ease;
    }
    .btn-action-icon:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .btn-action-icon.btn-success {
        background-color: #2ecc71;
        border-color: #2ecc71;
    }
    .btn-action-icon.btn-danger {
        background-color: #e74c3c;
        border-color: #e74c3c;
    }
    
    /* Avatar styling */
    .avatar-xs {
        width: 30px;
        height: 30px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
    .avatar-title {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 500;
    }
    
    /* Stats card styling */
    .stats-card {
        border-radius: 8px;
        border: none;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        transition: transform 0.2s;
        overflow: hidden;
        background-color: #fff;
        height: 100%;
    }
    .stats-card:hover {
        transform: translateY(-5px);
    }
    .stats-card .card-body {
        padding: 1.5rem;
    }
    .stats-card .text-xs {
        font-size: 0.9rem;
        letter-spacing: 0.5px;
    }
    .stats-card .h5 {
        font-size: 2.5rem;
        margin-top: 0.5rem;
        font-weight: 700;
    }
    
    /* Icon circle styling */
    .icon-circle {
        width: 64px;
        height: 64px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .icon-circle i {
        font-size: 1.75rem;
        color: #fff;
    }
    .bg-primary {
        background-color: #2196f3 !important;
    }
    
    .stats-card.primary-card {
        border-left: 4px solid #2196f3;
    }
    .stats-card.primary-card .text-xs {
        color: #2196f3;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const repliesTable = document.getElementById('repliesTable');
    const tableRows = repliesTable ? repliesTable.querySelectorAll('tbody tr') : [];
    
    function performSearch() {
        const searchTerm = searchInput.value.toLowerCase();
        
        tableRows.forEach(row => {
            const text = row.textContent.toLowerCase();
            if (text.includes(searchTerm)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    
    if (searchButton) {
        searchButton.addEventListener('click', performSearch);
    }
    
    if (searchInput) {
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }
    
    // Delete functionality
    const deleteButtons = document.querySelectorAll('.delete-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const replyId = this.getAttribute('data-id');
            const recipientName = this.getAttribute('data-name');
            
            document.getElementById('deleteReplyId').value = replyId;
            document.getElementById('deleteReplyName').textContent = recipientName;
            
            const deleteConfirmModal = new bootstrap.Modal(document.getElementById('deleteConfirmModal'));
            deleteConfirmModal.show();
        });
    });
    
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
});
</script>

<?= $this->endSection() ?> 