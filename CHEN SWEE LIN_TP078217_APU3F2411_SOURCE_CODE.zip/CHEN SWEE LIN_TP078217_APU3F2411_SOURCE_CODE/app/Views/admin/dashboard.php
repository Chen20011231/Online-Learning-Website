<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="row mb-4">
    <div class="col-12">
        <h2>Dashboard Overview</h2>
        <p class="text-muted">Welcome to the Smart Waste Sorting Assistant admin system. Manage all platform content here.</p>
    </div>
</div>

<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body position-relative p-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase text-muted mb-2">Total Users</h6>
                        <h2 class="mb-0 fw-bold"><?= $userCount ?></h2>
                    </div>
                    <div class="icon-box bg-primary bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-users text-primary"></i>
                    </div>
                </div>
                <div class="progress mt-4" style="height: 5px;">
                    <div class="progress-bar bg-primary" role="progressbar" style="width: 100%"></div>
                </div>
            </div>
            <div class="card-footer bg-transparent border-0 pt-0 pb-3 px-4">
                <a href="<?= base_url('admin/users') ?>" class="text-decoration-none d-flex align-items-center justify-content-between">
                    <span class="small">View Details</span>
                    <i class="fas fa-arrow-right small"></i>
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body position-relative p-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase text-muted mb-2">Total Courses</h6>
                        <h2 class="mb-0 fw-bold"><?= $courseCount ?></h2>
                    </div>
                    <div class="icon-box bg-success bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-book text-success"></i>
                    </div>
                </div>
                <div class="progress mt-4" style="height: 5px;">
                    <div class="progress-bar bg-success" role="progressbar" style="width: 100%"></div>
                </div>
            </div>
            <div class="card-footer bg-transparent border-0 pt-0 pb-3 px-4">
                <a href="<?= base_url('admin/courses') ?>" class="text-decoration-none d-flex align-items-center justify-content-between">
                    <span class="small">View Details</span>
                    <i class="fas fa-arrow-right small"></i>
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body position-relative p-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase text-muted mb-2">Total Quizzes</h6>
                        <h2 class="mb-0 fw-bold"><?= $quizCount ?></h2>
                    </div>
                    <div class="icon-box bg-warning bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-question-circle text-warning"></i>
                    </div>
                </div>
                <div class="progress mt-4" style="height: 5px;">
                    <div class="progress-bar bg-warning" role="progressbar" style="width: 100%"></div>
                </div>
            </div>
            <div class="card-footer bg-transparent border-0 pt-0 pb-3 px-4">
                <a href="<?= base_url('admin/quizzes') ?>" class="text-decoration-none d-flex align-items-center justify-content-between">
                    <span class="small">View Details</span>
                    <i class="fas fa-arrow-right small"></i>
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body position-relative p-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase text-muted mb-2">Total Blogs</h6>
                        <h2 class="mb-0 fw-bold"><?= $blogCount ?></h2>
                    </div>
                    <div class="icon-box bg-danger bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-blog text-danger"></i>
                    </div>
                </div>
                <div class="progress mt-4" style="height: 5px;">
                    <div class="progress-bar bg-danger" role="progressbar" style="width: 100%"></div>
                </div>
            </div>
            <div class="card-footer bg-transparent border-0 pt-0 pb-3 px-4">
                <a href="<?= base_url('admin/blogs') ?>" class="text-decoration-none d-flex align-items-center justify-content-between">
                    <span class="small">View Details</span>
                    <i class="fas fa-arrow-right small"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <div class="d-flex align-items-center">
                    <i class="fas fa-chart-line text-primary me-2"></i>
                    <h5 class="card-title mb-0 fw-bold">Platform Overview</h5>
                </div>
            </div>
            <div class="card-body p-4">
                <p>The Smart Waste Sorting Assistant platform is dedicated to providing quality environmental knowledge and recycling education resources to help more people understand and practice proper waste sorting.</p>
                <div class="mt-4">
                    <h6 class="fw-bold mb-3">Platform Features:</h6>
                    <div class="d-flex align-items-center mb-3">
                        <div class="feature-icon bg-success bg-opacity-10 p-2 rounded me-3">
                            <i class="fas fa-book text-success"></i>
                        </div>
                        <span>Create and manage environment-related courses</span>
                    </div>
                    <div class="d-flex align-items-center mb-3">
                        <div class="feature-icon bg-warning bg-opacity-10 p-2 rounded me-3">
                            <i class="fas fa-question-circle text-warning"></i>
                        </div>
                        <span>Add quizzes to evaluate learning outcomes</span>
                    </div>
                    <div class="d-flex align-items-center mb-3">
                        <div class="feature-icon bg-danger bg-opacity-10 p-2 rounded me-3">
                            <i class="fas fa-blog text-danger"></i>
                        </div>
                        <span>Publish environmental knowledge blogs</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <div class="feature-icon bg-primary bg-opacity-10 p-2 rounded me-3">
                            <i class="fas fa-users text-primary"></i>
                        </div>
                        <span>Manage user accounts and access</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 mb-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <div class="d-flex align-items-center">
                    <i class="fas fa-bolt text-warning me-2"></i>
                    <h5 class="card-title mb-0 fw-bold">Quick Actions</h5>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <a href="<?= base_url('admin/add-course') ?>" class="list-group-item list-group-item-action border-0 p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <div class="action-icon bg-success bg-opacity-10 p-2 rounded me-3">
                                    <i class="fas fa-plus-circle text-success"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0 fw-bold">Add New Course</h6>
                                    <p class="text-muted small mb-0">Create a new educational course</p>
                                </div>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </div>
                    </a>
                    <a href="<?= base_url('admin/add-quiz') ?>" class="list-group-item list-group-item-action border-0 p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <div class="action-icon bg-warning bg-opacity-10 p-2 rounded me-3">
                                    <i class="fas fa-plus-circle text-warning"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0 fw-bold">Create New Quiz</h6>
                                    <p class="text-muted small mb-0">Add assessment questions</p>
                                </div>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </div>
                    </a>
                    <a href="<?= base_url('admin/add-blog') ?>" class="list-group-item list-group-item-action border-0 p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <div class="action-icon bg-danger bg-opacity-10 p-2 rounded me-3">
                                    <i class="fas fa-plus-circle text-danger"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0 fw-bold">Publish New Blog</h6>
                                    <p class="text-muted small mb-0">Share environmental knowledge</p>
                                </div>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </div>
                    </a>
                    <a href="<?= base_url('admin/add-admin') ?>" class="list-group-item list-group-item-action border-0 p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <div class="action-icon bg-primary bg-opacity-10 p-2 rounded me-3">
                                    <i class="fas fa-user-plus text-primary"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0 fw-bold">Add Administrator</h6>
                                    <p class="text-muted small mb-0">Create new admin account</p>
                                </div>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?> 