<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>All Blogs</h2>
    <a href="<?= base_url('admin/add-blog') ?>" class="btn btn-primary">
        <i class="fas fa-plus-circle me-1"></i> Add Blog
    </a>
</div>

<div class="card">
    <div class="card-body">
        <?php if (empty($blogs)): ?>
            <div class="alert alert-info alert-dismissible fade show">
                No blog posts yet. Click the "Add Blog" button to create a new blog.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($blogs as $index => $blog): ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td>
                                    <?php if (!empty($blog['image'])): ?>
                                        <img src="<?= base_url('uploads/blogs/' . $blog['image']) ?>" alt="<?= $blog['title'] ?>" class="img-thumbnail" style="width: 80px; height: 60px; object-fit: cover;">
                                    <?php else: ?>
                                        <span class="badge bg-secondary">No Image</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= $blog['title'] ?></td>
                                <td>
                                    <?php if ($blog['status'] == 'active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($blog['created_at']) && $blog['created_at'] != '0000-00-00 00:00:00' && strtotime($blog['created_at']) > 0): ?>
                                        <?= date('Y-m-d', strtotime($blog['created_at'])) ?>
                                    <?php else: ?>
                                        <span class="text-muted">Unknown</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?= base_url('admin/edit-blog/' . $blog['id']) ?>" class="btn btn-sm btn-warning me-2" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?= base_url('admin/delete-blog/' . $blog['id']) ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this blog?');">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?> 