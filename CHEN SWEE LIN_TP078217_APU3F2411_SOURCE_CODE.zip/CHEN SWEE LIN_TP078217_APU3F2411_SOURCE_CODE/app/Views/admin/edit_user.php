<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Edit User</h2>
    <a href="<?= base_url('admin/users') ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-1"></i> Back to User List
    </a>
</div>

<div class="card">
    <div class="card-body">
        <div id="roleAlert" class="alert alert-info alert-dismissible fade show">
            <?php if ($user['role'] === 'admin'): ?>
                <i class="fas fa-info-circle me-2"></i> When editing an administrator account, you must enter a password. If you want to keep the original password, enter the original password; if you want to change the password, enter a new password.
            <?php else: ?>
                <i class="fas fa-info-circle me-2"></i> When editing a regular user account, no password is required and you cannot modify the user's password.
            <?php endif; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        
        <?php if (session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?= session()->get('error') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <form action="<?= base_url('admin/update-user/' . $user['id']) ?>" method="post">
            <?= csrf_field() ?>
            
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?= $user['name'] ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= $user['email'] ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="age" class="form-label">Age</label>
                <input type="number" class="form-control" id="age" name="age" value="<?= $user['age'] ?>">
            </div>
            
            <div class="mb-3">
                <label class="form-label">Gender</label>
                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="genderMale" value="male" <?= $user['gender'] == 'male' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="genderMale">Male</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="genderFemale" value="female" <?= $user['gender'] == 'female' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="genderFemale">Female</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="genderOther" value="other" <?= $user['gender'] == 'other' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="genderOther">Other</label>
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Role</label>
                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input role-radio" type="radio" name="role" id="roleUser" value="user" <?= $user['role'] == 'user' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="roleUser">User</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input role-radio" type="radio" name="role" id="roleAdmin" value="admin" <?= $user['role'] == 'admin' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="roleAdmin">Administrator</label>
                    </div>
                </div>
            </div>
            
            <div id="passwordFields" class="<?= $user['role'] == 'user' ? 'd-none' : '' ?>">
                <div class="mb-3">
                    <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="password" name="password" <?= $user['role'] == 'admin' ? 'required' : '' ?>>
                    <div class="form-text text-danger">Only administrator accounts need to fill in the password</div>
                </div>
                
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password <span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" <?= $user['role'] == 'admin' ? 'required' : '' ?>>
                </div>
            </div>
            
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const roleRadios = document.querySelectorAll('.role-radio');
        const passwordFields = document.getElementById('passwordFields');
        const passwordInput = document.getElementById('password');
        const confirmPasswordInput = document.getElementById('confirm_password');
        const roleAlert = document.getElementById('roleAlert');
        
        // Listen for role selection changes
        roleRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                if (this.value === 'admin') {
                    // Show password fields and set as required
                    passwordFields.classList.remove('d-none');
                    passwordInput.required = true;
                    confirmPasswordInput.required = true;
                    roleAlert.innerHTML = '<i class="fas fa-info-circle me-2"></i> When editing an administrator account, you must enter a password. If you want to keep the original password, enter the original password; if you want to change the password, enter a new password. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                } else {
                    // Hide password fields and remove required
                    passwordFields.classList.add('d-none');
                    passwordInput.required = false;
                    confirmPasswordInput.required = false;
                    roleAlert.innerHTML = '<i class="fas fa-info-circle me-2"></i> When editing a regular user account, no password is required and you cannot modify the user\'s password. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                }
            });
        });
    });
</script>
<?= $this->endSection() ?>

<?= $this->endSection() ?> 