<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Edit Quiz</h2>
    <a href="<?= base_url('admin/quizzes/' . $quiz['course_id']) ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-1"></i> Back to Quiz List
    </a>
</div>

<div class="card">
    <div class="card-body">
        <?php if (session()->getFlashdata('errors')): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <form action="<?= base_url('admin/update-quiz/' . $quiz['id']) ?>" method="post">
            <?= csrf_field() ?>
            
            <h5 class="mb-3">Quiz Basic Information</h5>
            
            <div class="mb-3">
                <label for="course_id" class="form-label">Course</label>
                <select class="form-select" id="course_id" name="course_id" required>
                    <option value="" selected disabled>Select Course</option>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?= $course['id'] ?>" <?= old('course_id', $quiz['course_id']) == $course['id'] ? 'selected' : '' ?>>
                            <?= $course['title'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="mb-3">
                <label for="title" class="form-label">Quiz Title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?= old('title', $quiz['title']) ?>" required>
                <div class="form-text">Enter the quiz title, for example "Environmental Knowledge Quiz"</div>
            </div>
            
            <div class="mb-3">
                <label for="description" class="form-label">Quiz Description</label>
                <textarea class="form-control" id="description" name="description" rows="4" required><?= old('description', $quiz['description']) ?></textarea>
                <div class="form-text">Enter a brief description of the quiz, explaining its purpose and content</div>
            </div>
            
            <div class="mb-3">
                <label for="status" class="form-label">Quiz Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="active" <?= old('status', $quiz['status']) == 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= old('status', $quiz['status']) == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            
            <hr class="my-4">
            
            <h5 class="mb-3">Multiple Choice Question Information</h5>
            
            <div class="mb-3">
                <label for="question" class="form-label">Question Content</label>
                <textarea class="form-control" id="question" name="question" rows="3"><?= old('question') ?></textarea>
                <div class="form-text">Enter the specific content of the question</div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="option_a" class="form-label">Option A</label>
                    <input type="text" class="form-control" id="option_a" name="option_a" value="<?= old('option_a') ?>">
                </div>
                <div class="col-md-6">
                    <label for="option_b" class="form-label">Option B</label>
                    <input type="text" class="form-control" id="option_b" name="option_b" value="<?= old('option_b') ?>">
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="option_c" class="form-label">Option C (Optional)</label>
                    <input type="text" class="form-control" id="option_c" name="option_c" value="<?= old('option_c') ?>">
                </div>
                <div class="col-md-6">
                    <label for="option_d" class="form-label">Option D (Optional)</label>
                    <input type="text" class="form-control" id="option_d" name="option_d" value="<?= old('option_d') ?>">
                </div>
            </div>
            
            <div class="mb-4">
                <label for="correct_answer" class="form-label">Correct Answer</label>
                <select class="form-select" id="correct_answer" name="correct_answer">
                    <option value="" selected disabled>Select Correct Answer</option>
                    <option value="A" <?= old('correct_answer') == 'A' ? 'selected' : '' ?>>A</option>
                    <option value="B" <?= old('correct_answer') == 'B' ? 'selected' : '' ?>>B</option>
                    <option value="C" <?= old('correct_answer') == 'C' ? 'selected' : '' ?>>C</option>
                    <option value="D" <?= old('correct_answer') == 'D' ? 'selected' : '' ?>>D</option>
                </select>
                <div class="form-text">Select the correct answer option</div>
            </div>
            
            <div class="alert alert-info alert-dismissible fade show">
                <i class="fas fa-info-circle me-2"></i> If you fill in the question content and options, the system will add a new multiple choice question when updating the quiz.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Update Quiz
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add editor for description field
        ClassicEditor
            .create(document.querySelector('#description'))
            .catch(error => {
                console.error(error);
            });
            
        // Dynamically update correct answer option availability
        const optionC = document.getElementById('option_c');
        const optionD = document.getElementById('option_d');
        const correctAnswer = document.getElementById('correct_answer');
        
        function updateCorrectAnswerOptions() {
            const optionCValue = optionC.value.trim();
            const optionDValue = optionD.value.trim();
            
            // Get currently selected value
            const selectedValue = correctAnswer.value;
            
            // Disable/enable option C
            const optionCElement = correctAnswer.querySelector('option[value="C"]');
            if (optionCValue === '') {
                optionCElement.disabled = true;
                if (selectedValue === 'C') {
                    correctAnswer.value = '';
                }
            } else {
                optionCElement.disabled = false;
            }
            
            // Disable/enable option D
            const optionDElement = correctAnswer.querySelector('option[value="D"]');
            if (optionDValue === '') {
                optionDElement.disabled = true;
                if (selectedValue === 'D') {
                    correctAnswer.value = '';
                }
            } else {
                optionDElement.disabled = false;
            }
        }
        
        // Initialize and add event listeners
        updateCorrectAnswerOptions();
        optionC.addEventListener('input', updateCorrectAnswerOptions);
        optionD.addEventListener('input', updateCorrectAnswerOptions);
    });
</script>
<?= $this->endSection() ?> 