<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Edit Blog</h2>
    <a href="<?= base_url('admin/blogs') ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-1"></i> Back to Blog List
    </a>
</div>

<div class="card">
    <div class="card-body">
        <?php if (session()->getFlashdata('errors')): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <form action="<?= base_url('admin/update-blog/' . $blog['id']) ?>" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            
            <div class="mb-3">
                <label for="title" class="form-label">Blog Title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?= old('title', $blog['title']) ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="content" class="form-label">Blog Content</label>
                <textarea class="form-control" id="content" name="content" rows="15" required><?= old('content', $blog['content']) ?></textarea>
            </div>
            
            <div class="mb-3">
                <label for="image" class="form-label">Blog Cover Image</label>
                <?php if (!empty($blog['image'])): ?>
                    <div class="mb-2">
                        <img src="<?= base_url('uploads/blogs/' . $blog['image']) ?>" alt="<?= $blog['title'] ?>" class="img-thumbnail" style="max-height: 200px;">
                    </div>
                <?php endif; ?>
                <input type="file" class="form-control" id="image" name="image" accept="image/*">
                <div class="form-text">If you don't upload a new image, the existing image will be kept</div>
            </div>
            
            <div class="mb-3">
                <label for="status" class="form-label">Blog Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="active" <?= old('status', $blog['status']) == 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= old('status', $blog['status']) == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Update Blog
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    // Use CKEditor to enhance the text editor
    ClassicEditor
        .create(document.querySelector('#content'))
        .catch(error => {
            console.error(error);
        });
</script>
<?= $this->endSection() ?> 