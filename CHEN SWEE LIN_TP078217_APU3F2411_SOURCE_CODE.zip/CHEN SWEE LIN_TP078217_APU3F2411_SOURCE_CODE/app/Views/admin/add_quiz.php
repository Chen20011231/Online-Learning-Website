<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Add Quiz</h2>
    <?php if (isset($course_id)): ?>
        <a href="<?= base_url('admin/quizzes/' . $course_id) ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Back to Quiz List
        </a>
    <?php else: ?>
        <a href="<?= base_url('admin/quizzes') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Back to Quiz List
        </a>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-body">
        <?php if (session()->getFlashdata('errors')): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <form action="<?= base_url('admin/create-quiz') ?>" method="post" id="quizForm">
            <?= csrf_field() ?>
            
            <!-- Step Indicator -->
            <div class="mb-4">
                <div class="progress" style="height: 3px;">
                    <div class="progress-bar" role="progressbar" id="stepProgressBar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <div class="d-flex justify-content-between mt-2">
                    <span class="step-indicator active" id="step1Indicator">Step 1: Quiz Basic Information</span>
                    <span class="step-indicator" id="step2Indicator">Step 2: Multiple Choice Questions</span>
                </div>
            </div>
            
            <!-- Step 1: Quiz Basic Information -->
            <div id="step1" class="step-content">
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Quiz Basic Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="course_id" class="form-label">Course <span class="text-danger">*</span></label>
                            <select class="form-select" id="course_id" name="course_id" required>
                                <option value="" selected disabled>Select Course</option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?= $course['id'] ?>" <?= (isset($course_id) && $course_id == $course['id']) || old('course_id') == $course['id'] ? 'selected' : '' ?>>
                                        <?= $course['title'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Select the course this quiz belongs to</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="title" class="form-label">Quiz Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="title" name="title" value="<?= old('title') ?>" required>
                            <div class="form-text">Enter the quiz title, for example "Environmental Knowledge Quiz"</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Quiz Description <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="description" name="description" rows="4"><?= old('description') ?></textarea>
                            <input type="hidden" id="description_hidden" name="description_hidden">
                            <div class="form-text">Enter a brief description of the quiz, explaining its purpose and content</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="status" class="form-label">Quiz Status</label>
                            <select class="form-select" id="status" name="status">
                                <option value="active" <?= old('status') == 'active' || old('status') == '' ? 'selected' : '' ?>>Active</option>
                                <option value="inactive" <?= old('status') == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                            </select>
                            <div class="form-text">Set the quiz status. Inactive quizzes will not be shown to students</div>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <?php if (isset($course_id)): ?>
                        <a href="<?= base_url('admin/quizzes/' . $course_id) ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    <?php else: ?>
                        <a href="<?= base_url('admin/quizzes') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    <?php endif; ?>
                    <button type="button" id="nextBtn" class="btn btn-primary">
                        <i class="fas fa-arrow-right me-1"></i> Next
                    </button>
                </div>
            </div>
            
            <!-- Step 2: Multiple Choice Questions -->
            <div id="step2" class="step-content" style="display: none;">
                <div id="questionsContainer">
                    <div class="question-item card mb-4" data-question-index="0">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Question #1</h5>
                            <button type="button" class="btn btn-sm btn-outline-danger remove-question" style="display: none;">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="question_0" class="form-label">Question Content <span class="text-danger">*</span></label>
                                <textarea class="form-control question-input" id="question_0" name="questions[0][question]" rows="3" required><?= old('question') ?></textarea>
                                <div class="form-text">Enter the specific content of the question, e.g.: "Which of the following materials cannot be recycled?"</div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="option_a_0" class="form-label">Option A <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">A</span>
                                        <input type="text" class="form-control" id="option_a_0" name="questions[0][option_a]" value="<?= old('option_a') ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="option_b_0" class="form-label">Option B <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">B</span>
                                        <input type="text" class="form-control" id="option_b_0" name="questions[0][option_b]" value="<?= old('option_b') ?>" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="option_c_0" class="form-label">Option C (Optional)</label>
                                    <div class="input-group">
                                        <span class="input-group-text">C</span>
                                        <input type="text" class="form-control" id="option_c_0" name="questions[0][option_c]" value="<?= old('option_c') ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="option_d_0" class="form-label">Option D (Optional)</label>
                                    <div class="input-group">
                                        <span class="input-group-text">D</span>
                                        <input type="text" class="form-control" id="option_d_0" name="questions[0][option_d]" value="<?= old('option_d') ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Correct Answer <span class="text-danger">*</span></label>
                                <div class="d-flex">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="questions[0][correct_answer]" id="correct_a_0" value="A" <?= old('correct_answer') == 'A' ? 'checked' : '' ?> required>
                                        <label class="form-check-label" for="correct_a_0">A</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="questions[0][correct_answer]" id="correct_b_0" value="B" <?= old('correct_answer') == 'B' ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="correct_b_0">B</label>
                                    </div>
                                    <div class="form-check form-check-inline option-c-radio">
                                        <input class="form-check-input" type="radio" name="questions[0][correct_answer]" id="correct_c_0" value="C" <?= old('correct_answer') == 'C' ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="correct_c_0">C</label>
                                    </div>
                                    <div class="form-check form-check-inline option-d-radio">
                                        <input class="form-check-input" type="radio" name="questions[0][correct_answer]" id="correct_d_0" value="D" <?= old('correct_answer') == 'D' ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="correct_d_0">D</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mb-4">
                    <button type="button" id="addQuestionBtn" class="btn btn-success w-100">
                        <i class="fas fa-plus-circle me-1"></i> Add Another Question
                    </button>
                </div>
                
                <div class="alert alert-info alert-dismissible fade show">
                    <i class="fas fa-info-circle me-2"></i> After saving, you can continue to add or edit questions on the quiz details page.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                
                <div class="d-flex justify-content-between">
                    <button type="button" id="prevBtn" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Back
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Save Quiz
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<style>
    .step-indicator {
        font-weight: 500;
        color: #6c757d;
    }
    .step-indicator.active {
        color: #0d6efd;
        font-weight: 600;
    }
    .question-item {
        position: relative;
    }
    .question-item .card-header {
        border-left: 4px solid #0d6efd;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Step switching
        const step1 = document.getElementById('step1');
        const step2 = document.getElementById('step2');
        const step1Indicator = document.getElementById('step1Indicator');
        const step2Indicator = document.getElementById('step2Indicator');
        const stepProgressBar = document.getElementById('stepProgressBar');
        const nextBtn = document.getElementById('nextBtn');
        const prevBtn = document.getElementById('prevBtn');
        
        // Global variable to store CKEditor instance
        let descriptionEditor;
        
        // Initialize CKEditor
        ClassicEditor
            .create(document.querySelector('#description'))
            .then(editor => {
                descriptionEditor = editor;
                
                // Listen for CKEditor content changes to sync to hidden field
                editor.model.document.on('change:data', () => {
                    const content = editor.getData();
                    document.getElementById('description_hidden').value = content;
                });
            })
            .catch(error => {
                console.error(error);
            });
        
        nextBtn.addEventListener('click', function() {
            // Validate required fields in step 1
            const courseId = document.getElementById('course_id');
            const title = document.getElementById('title');
            
            if (!courseId.value) {
                alert('Please select a course');
                courseId.focus();
                return;
            }
            
            if (!title.value.trim()) {
                alert('Please enter a quiz title');
                title.focus();
                return;
            }
            
            // Get description content from CKEditor and sync to hidden field
            const content = descriptionEditor ? descriptionEditor.getData() : '';
            document.getElementById('description_hidden').value = content;
            
            if (!content.trim()) {
                alert('Please enter a quiz description');
                if (descriptionEditor) {
                    descriptionEditor.focus();
                }
                return;
            }
            
            // Switch to step 2
            step1.style.display = 'none';
            step2.style.display = 'block';
            step1Indicator.classList.remove('active');
            step2Indicator.classList.add('active');
            stepProgressBar.style.width = '100%';
        });
        
        prevBtn.addEventListener('click', function() {
            // Switch back to step 1
            step2.style.display = 'none';
            step1.style.display = 'block';
            step2Indicator.classList.remove('active');
            step1Indicator.classList.add('active');
            stepProgressBar.style.width = '50%';
        });
        
        // Add question button
        const addQuestionBtn = document.getElementById('addQuestionBtn');
        const questionsContainer = document.getElementById('questionsContainer');
        let questionCount = 1;
        
        addQuestionBtn.addEventListener('click', function() {
            const newIndex = questionCount;
            questionCount++;
            
            const questionTemplate = `
                <div class="question-item card mb-4" data-question-index="${newIndex}">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Question #${questionCount}</h5>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-question">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="question_${newIndex}" class="form-label">Question Content <span class="text-danger">*</span></label>
                            <textarea class="form-control question-input" id="question_${newIndex}" name="questions[${newIndex}][question]" rows="3" required></textarea>
                            <div class="form-text">Enter the specific content of the question, e.g.: "Which of the following materials cannot be recycled?"</div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="option_a_${newIndex}" class="form-label">Option A <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text">A</span>
                                    <input type="text" class="form-control" id="option_a_${newIndex}" name="questions[${newIndex}][option_a]" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="option_b_${newIndex}" class="form-label">Option B <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text">B</span>
                                    <input type="text" class="form-control" id="option_b_${newIndex}" name="questions[${newIndex}][option_b]" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="option_c_${newIndex}" class="form-label">Option C (Optional)</label>
                                <div class="input-group">
                                    <span class="input-group-text">C</span>
                                    <input type="text" class="form-control" id="option_c_${newIndex}" name="questions[${newIndex}][option_c]">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="option_d_${newIndex}" class="form-label">Option D (Optional)</label>
                                <div class="input-group">
                                    <span class="input-group-text">D</span>
                                    <input type="text" class="form-control" id="option_d_${newIndex}" name="questions[${newIndex}][option_d]">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Correct Answer <span class="text-danger">*</span></label>
                            <div class="d-flex">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="questions[${newIndex}][correct_answer]" id="correct_a_${newIndex}" value="A" required>
                                    <label class="form-check-label" for="correct_a_${newIndex}">A</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="questions[${newIndex}][correct_answer]" id="correct_b_${newIndex}" value="B">
                                    <label class="form-check-label" for="correct_b_${newIndex}">B</label>
                                </div>
                                <div class="form-check form-check-inline option-c-radio-${newIndex}">
                                    <input class="form-check-input" type="radio" name="questions[${newIndex}][correct_answer]" id="correct_c_${newIndex}" value="C">
                                    <label class="form-check-label" for="correct_c_${newIndex}">C</label>
                                </div>
                                <div class="form-check form-check-inline option-d-radio-${newIndex}">
                                    <input class="form-check-input" type="radio" name="questions[${newIndex}][correct_answer]" id="correct_d_${newIndex}" value="D">
                                    <label class="form-check-label" for="correct_d_${newIndex}">D</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            // Add new question to container
            questionsContainer.insertAdjacentHTML('beforeend', questionTemplate);
            
            // Add delete question event
            const removeButtons = document.querySelectorAll('.remove-question');
            removeButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const questionItem = this.closest('.question-item');
                    questionItem.remove();
                    
                    // Renumber questions
                    const questionItems = document.querySelectorAll('.question-item');
                    questionItems.forEach((item, index) => {
                        item.querySelector('h5').textContent = `Question #${index + 1}`;
                    });
                });
            });
            
            // Show delete button for the first question (if multiple questions)
            if (questionCount > 1) {
                document.querySelector('.question-item[data-question-index="0"] .remove-question').style.display = 'block';
            }
            
            // Add linking between options C/D and correct answer
            setupOptionValidation(newIndex);
        });
        
        // Set up linking between options C/D and correct answer
        function setupOptionValidation(index) {
            const optionC = document.getElementById(`option_c_${index}`);
            const optionD = document.getElementById(`option_d_${index}`);
            const correctC = document.getElementById(`correct_c_${index}`);
            const correctD = document.getElementById(`correct_d_${index}`);
            const optionCRadio = document.querySelector(`.option-c-radio${index > 0 ? '-' + index : ''}`);
            const optionDRadio = document.querySelector(`.option-d-radio${index > 0 ? '-' + index : ''}`);
            
            function updateCorrectAnswerOptions() {
                if (optionC) {
                    const optionCValue = optionC.value.trim();
                    if (optionCValue === '') {
                        correctC.disabled = true;
                        if (correctC.checked) {
                            correctC.checked = false;
                        }
                        optionCRadio.classList.add('opacity-50');
                    } else {
                        correctC.disabled = false;
                        optionCRadio.classList.remove('opacity-50');
                    }
                }
                
                if (optionD) {
                    const optionDValue = optionD.value.trim();
                    if (optionDValue === '') {
                        correctD.disabled = true;
                        if (correctD.checked) {
                            correctD.checked = false;
                        }
                        optionDRadio.classList.add('opacity-50');
                    } else {
                        correctD.disabled = false;
                        optionDRadio.classList.remove('opacity-50');
                    }
                }
            }
            
            if (optionC) optionC.addEventListener('input', updateCorrectAnswerOptions);
            if (optionD) optionD.addEventListener('input', updateCorrectAnswerOptions);
            
            updateCorrectAnswerOptions();
        }
        
        // Set up option validation for the first question
        setupOptionValidation(0);
        
        // Form submission validation
        const quizForm = document.getElementById('quizForm');
        quizForm.addEventListener('submit', function(event) {
            // Ensure CKEditor content is synced to form fields
            if (descriptionEditor) {
                const content = descriptionEditor.getData();
                const descriptionHidden = document.getElementById('description_hidden');
                descriptionHidden.value = content;
                
                // Check if content is empty
                if (!content.trim()) {
                    event.preventDefault();
                    alert('Please enter quiz description');
                    return;
                }
            }
            
            // Validate the first question
            const firstQuestion = document.getElementById('question_0').value.trim();
            const firstOptionA = document.getElementById('option_a_0').value.trim();
            const firstOptionB = document.getElementById('option_b_0').value.trim();
            const firstCorrectAnswer = document.querySelector('input[name="questions[0][correct_answer]"]:checked');
            
            let valid = true;
            let errorMessage = '';
            
            if (firstQuestion === '') {
                errorMessage += 'Please enter content for the first question\n';
                valid = false;
            }
            
            if (firstOptionA === '') {
                errorMessage += 'Please enter option A for the first question\n';
                valid = false;
            }
            
            if (firstOptionB === '') {
                errorMessage += 'Please enter option B for the first question\n';
                valid = false;
            }
            
            if (!firstCorrectAnswer) {
                errorMessage += 'Please select the correct answer for the first question\n';
                valid = false;
            }
            
            // Validate other questions (if any)
            const questionItems = document.querySelectorAll('.question-item');
            for (let i = 1; i < questionItems.length; i++) {
                const index = questionItems[i].getAttribute('data-question-index');
                const question = document.getElementById(`question_${index}`).value.trim();
                const optionA = document.getElementById(`option_a_${index}`).value.trim();
                const optionB = document.getElementById(`option_b_${index}`).value.trim();
                const correctAnswer = document.querySelector(`input[name="questions[${index}][correct_answer]"]:checked`);
                
                if (question === '') {
                    errorMessage += `Please enter content for question #${i+1}\n`;
                    valid = false;
                }
                
                if (optionA === '') {
                    errorMessage += `Please enter option A for question #${i+1}\n`;
                    valid = false;
                }
                
                if (optionB === '') {
                    errorMessage += `Please enter option B for question #${i+1}\n`;
                    valid = false;
                }
                
                if (!correctAnswer) {
                    errorMessage += `Please select the correct answer for question #${i+1}\n`;
                    valid = false;
                }
            }
            
            if (!valid) {
                event.preventDefault();
                alert('Form validation failed:\n' + errorMessage);
            }
        });

        // Ensure CKEditor content is synced before form submission
        document.getElementById('quizForm').addEventListener('submit', function(e) {
            if (descriptionEditor) {
                document.getElementById('description_hidden').value = descriptionEditor.getData();
            }
        });
    });
</script>
<?= $this->endSection() ?> 