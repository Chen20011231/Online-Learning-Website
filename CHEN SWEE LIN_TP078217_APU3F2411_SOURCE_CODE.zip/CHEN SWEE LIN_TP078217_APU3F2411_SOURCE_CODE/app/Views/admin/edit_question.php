<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Edit Question</h2>
    <a href="<?= base_url('admin/questions/' . $question['quiz_id']) ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-1"></i> Back to Question List
    </a>
</div>

<div class="card">
    <div class="card-body">
        <div class="alert alert-info alert-dismissible fade show">
            <i class="fas fa-info-circle me-2"></i> You are editing a question for quiz <strong><?= $quiz['title'] ?></strong>.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        
        <?php if (session()->getFlashdata('errors')): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <form action="<?= base_url('admin/update-question/' . $question['id']) ?>" method="post">
            <?= csrf_field() ?>
            
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Question Content</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="question" class="form-label">Question Content</label>
                        <textarea class="form-control" id="question" name="question" rows="3" required><?= old('question', $question['question']) ?></textarea>
                        <div class="form-text">Enter the specific content of the question, e.g.: "Which of the following materials cannot be recycled?"</div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Answer Options</h5>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="option_a" class="form-label">Option A <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">A</span>
                                <input type="text" class="form-control" id="option_a" name="option_a" value="<?= old('option_a', $options['A'] ?? '') ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="option_b" class="form-label">Option B <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">B</span>
                                <input type="text" class="form-control" id="option_b" name="option_b" value="<?= old('option_b', $options['B'] ?? '') ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="option_c" class="form-label">Option C (Optional)</label>
                            <div class="input-group">
                                <span class="input-group-text">C</span>
                                <input type="text" class="form-control" id="option_c" name="option_c" value="<?= old('option_c', $options['C'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="option_d" class="form-label">Option D (Optional)</label>
                            <div class="input-group">
                                <span class="input-group-text">D</span>
                                <input type="text" class="form-control" id="option_d" name="option_d" value="<?= old('option_d', $options['D'] ?? '') ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Correct Answer</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="correct_answer" class="form-label">Select Correct Answer <span class="text-danger">*</span></label>
                        <div class="d-flex">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="correct_answer" id="correct_a" value="A" <?= old('correct_answer', $question['correct_answer']) == 'A' ? 'checked' : '' ?> required>
                                <label class="form-check-label" for="correct_a">A</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="correct_answer" id="correct_b" value="B" <?= old('correct_answer', $question['correct_answer']) == 'B' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="correct_b">B</label>
                            </div>
                            <div class="form-check form-check-inline option-c-radio">
                                <input class="form-check-input" type="radio" name="correct_answer" id="correct_c" value="C" <?= old('correct_answer', $question['correct_answer']) == 'C' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="correct_c">C</label>
                            </div>
                            <div class="form-check form-check-inline option-d-radio">
                                <input class="form-check-input" type="radio" name="correct_answer" id="correct_d" value="D" <?= old('correct_answer', $question['correct_answer']) == 'D' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="correct_d">D</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between">
                <a href="<?= base_url('admin/questions/' . $question['quiz_id']) ?>" class="btn btn-secondary">
                    <i class="fas fa-times me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Save Changes
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Dynamically update correct answer option availability
        const optionC = document.getElementById('option_c');
        const optionD = document.getElementById('option_d');
        const correctC = document.getElementById('correct_c');
        const correctD = document.getElementById('correct_d');
        const optionCRadio = document.querySelector('.option-c-radio');
        const optionDRadio = document.querySelector('.option-d-radio');
        
        function updateCorrectAnswerOptions() {
            const optionCValue = optionC.value.trim();
            const optionDValue = optionD.value.trim();
            
            // Disable/enable option C
            if (optionCValue === '') {
                correctC.disabled = true;
                if (correctC.checked) {
                    correctC.checked = false;
                }
                optionCRadio.classList.add('opacity-50');
            } else {
                correctC.disabled = false;
                optionCRadio.classList.remove('opacity-50');
            }
            
            // Disable/enable option D
            if (optionDValue === '') {
                correctD.disabled = true;
                if (correctD.checked) {
                    correctD.checked = false;
                }
                optionDRadio.classList.add('opacity-50');
            } else {
                correctD.disabled = false;
                optionDRadio.classList.remove('opacity-50');
            }
        }
        
        // Initialize and add event listeners
        updateCorrectAnswerOptions();
        optionC.addEventListener('input', updateCorrectAnswerOptions);
        optionD.addEventListener('input', updateCorrectAnswerOptions);
        
        // Add form validation
        const form = document.querySelector('form');
        form.addEventListener('submit', function(event) {
            const question = document.getElementById('question').value.trim();
            const optionA = document.getElementById('option_a').value.trim();
            const optionB = document.getElementById('option_b').value.trim();
            const correctAnswer = document.querySelector('input[name="correct_answer"]:checked');
            
            let valid = true;
            let errorMessage = '';
            
            if (question === '') {
                errorMessage += 'Please enter question content\n';
                valid = false;
            }
            
            if (optionA === '') {
                errorMessage += 'Please enter option A\n';
                valid = false;
            }
            
            if (optionB === '') {
                errorMessage += 'Please enter option B\n';
                valid = false;
            }
            
            if (!correctAnswer) {
                errorMessage += 'Please select a correct answer\n';
                valid = false;
            }
            
            if (!valid) {
                event.preventDefault();
                alert('Form validation failed:\n' + errorMessage);
            }
        });
    });
</script>
<?= $this->endSection() ?> 