<?php

namespace App\Models;

use CodeIgniter\Model;

class QuestionModel extends Model
{
    protected $table = 'questions';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['quiz_id', 'question', 'options', 'correct_answer', 'created_at', 'updated_at'];

    // Date format
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation rules
    protected $validationRules = [
        'quiz_id' => 'required|numeric',
        'question' => 'required|min_length[5]',
        'options' => 'required',
        'correct_answer' => 'required',
    ];
    
    protected $validationMessages = [
        'quiz_id' => [
            'required' => 'Please select quiz',
            'numeric' => 'Quiz ID must be a number',
        ],
        'question' => [
            'required' => 'Please enter question content',
            'min_length' => 'Question content must be at least 5 characters long',
        ],
        'options' => [
            'required' => 'Please provide options',
        ],
        'correct_answer' => [
            'required' => 'Please provide the correct answer',
        ],
    ];
    
    // Get all questions for a specific quiz
    public function getQuestionsByQuiz($quizId)
    {
        return $this->where('quiz_id', $quizId)->findAll();
    }
} 