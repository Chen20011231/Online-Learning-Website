<?php

namespace App\Models;

use CodeIgniter\Model;

class QuizResultModel extends Model
{
    protected $table = 'quiz_results';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['user_id', 'quiz_id', 'course_id', 'score', 'created_at'];

    // Date format
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Get user's all quiz results
    public function getUserResults($userId)
    {
        return $this->where('user_id', $userId)->findAll();
    }
    
    // Get user's specific course quiz result
    public function getUserCourseResult($userId, $courseId)
    {
        return $this->where('user_id', $userId)
                    ->where('course_id', $courseId)
                    ->orderBy('created_at', 'DESC')
                    ->first();
    }
    
    // Get user's all completed courses count
    public function getCompletedCoursesCount($userId)
    {
        $db = \Config\Database::connect();
        $result = $db->query("SELECT COUNT(DISTINCT course_id) as count FROM quiz_results WHERE user_id = $userId")->getRow();
        return $result ? $result->count : 0;
    }
} 