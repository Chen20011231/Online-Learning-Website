<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['name', 'email', 'password', 'age', 'gender', 'role', 'created_at', 'updated_at'];

    // Date format
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation rules - Modify email uniqueness check, exclude current ID
    protected $validationRules = [
        'name' => 'required|min_length[3]',
        'email' => 'required|valid_email',
        'password' => 'required|min_length[6]',
    ];
    
    protected $validationMessages = [
        'name' => [
            'required' => 'Please enter username',
            'min_length' => 'Username must be at least 3 characters long',
        ],
        'email' => [
            'required' => 'Please enter email',
            'valid_email' => 'Please enter a valid email',
            'is_unique' => 'This email has already been registered',
        ],
        'password' => [
            'required' => 'Please enter password',
            'min_length' => 'Password must be at least 6 characters long',
        ],
    ];
    
    // Hash password before saving
    protected $beforeInsert = ['hashPassword'];
    protected $beforeUpdate = ['hashPassword'];
    
    protected function hashPassword(array $data)
    {
        if (isset($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }
        
        return $data;
    }
    
    // Validate user login
    public function validateUser($email, $password)
    {
        $user = $this->where('email', $email)->first();
        
        if (is_null($user)) {
            return false;
        }
        
        return password_verify($password, $user['password']) ? $user : false;
    }
} 