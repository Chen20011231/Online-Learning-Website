<?php

namespace App\Models;

use CodeIgniter\Model;

class BlogBookmarkModel extends Model
{
    protected $table = 'blog_bookmarks';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['user_id', 'blog_id', 'created_at'];

    // Date format
    protected $useTimestamps = false;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';

    // Validation rules
    protected $validationRules = [
        'user_id' => 'required|numeric',
        'blog_id' => 'required|numeric',
    ];

    /**
     * Check if the user has bookmarked the blog
     */
    public function isBookmarked($userId, $blogId)
    {
        return $this->where('user_id', $userId)
            ->where('blog_id', $blogId)
            ->countAllResults() > 0;
    }

    /**
     * Add bookmark
     */
    public function addBookmark($userId, $blogId)
    {
        // Check if already bookmarked
        if ($this->isBookmarked($userId, $blogId)) {
            return false;
        }

        return $this->insert([
            'user_id' => $userId,
            'blog_id' => $blogId,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Remove bookmark
     */
    public function removeBookmark($userId, $blogId)
    {
        return $this->where('user_id', $userId)
            ->where('blog_id', $blogId)
            ->delete();
    }

    /**
        * Get user's bookmarked blogs
     */
    public function getUserBookmarks($userId)
    {
        $db = \Config\Database::connect();
        
        return $db->table('blog_bookmarks b')
            ->select('bl.*, b.created_at as bookmarked_at')
            ->join('blogs bl', 'b.blog_id = bl.id')
            ->where('b.user_id', $userId)
            ->orderBy('b.created_at', 'DESC')
            ->get()
            ->getResultArray();
    }
} 