<?php

namespace App\Models;

use CodeIgniter\Model;

class CertificateModel extends Model
{
    protected $table = 'certificates';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['user_id', 'course_id', 'quiz_id', 'certificate_number', 'issue_date', 'score', 'status'];

    
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation rules
    protected $validationRules = [
        'user_id' => 'required|numeric',
        'course_id' => 'required|numeric',
        'quiz_id' => 'required|numeric',
        'certificate_number' => 'required',
    ];
    
    /**
     * Get user's all certificates
     */
    public function getUserCertificates($userId)
    {
        return $this->select('certificates.*, courses.title as course_title, courses.image as course_image')
                    ->join('courses', 'courses.id = certificates.course_id')
                    ->where('certificates.user_id', $userId)
                    ->orderBy('certificates.issue_date', 'DESC')
                    ->findAll();
    }
    
    /**
     * Get specific certificate details
     */
    public function getCertificateDetails($certificateId)
    {
        return $this->select('certificates.*, courses.title as course_title, users.name as user_name, users.email as user_email')
                    ->join('courses', 'courses.id = certificates.course_id')
                    ->join('users', 'users.id = certificates.user_id')
                    ->where('certificates.id', $certificateId)
                    ->first();
    }
    
    /**
     * Check if the user has already obtained a certificate for a specific course
     * 
     * @param int $userId User ID
     * @param int $courseId Course ID
     * @return bool|int If exists, return certificate ID, otherwise return false
     */
    public function hasCertificate($userId, $courseId)
    {
        $certificate = $this->where('user_id', $userId)
                    ->where('course_id', $courseId)
                    ->first();
                    
        if ($certificate) {
            return $certificate['id'];
        }
                    
        return false;
    }
    
    /**
     * Generate a unique certificate number
     */
    public function generateCertificateNumber($userId, $courseId)
    {
        $prefix = 'CERT';
        $timestamp = time();
        $random = rand(1000, 9999);
        return $prefix . '-' . $userId . '-' . $courseId . '-' . $timestamp . '-' . $random;
    }
    
    /**
     * Create new certificate
     */
    public function createCertificate($userId, $courseId, $quizId, $score)
    {
        // Check if there is already a certificate
        if ($this->hasCertificate($userId, $courseId)) {
            return false;
        }
        
        $data = [
            'user_id' => $userId,
            'course_id' => $courseId,
            'quiz_id' => $quizId,
            'certificate_number' => $this->generateCertificateNumber($userId, $courseId),
            'issue_date' => date('Y-m-d H:i:s'),
            'score' => $score,
            'status' => 'active'
        ];
        
        $this->insert($data);
        return $this->getInsertID();
    }
} 