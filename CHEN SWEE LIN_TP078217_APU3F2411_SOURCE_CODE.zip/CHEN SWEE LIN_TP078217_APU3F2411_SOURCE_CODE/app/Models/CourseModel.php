<?php

namespace App\Models;

use CodeIgniter\Model;

class CourseModel extends Model
{
    protected $table = 'courses';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['title', 'description', 'content', 'image', 'created_by', 'status', 'created_at'];

    // Date format
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation rules
    protected $validationRules = [
        'title' => 'required|min_length[3]',
        'description' => 'required|min_length[10]',
        'content' => 'required',
    ];
    
    protected $validationMessages = [
        'title' => [
            'required' => 'Please enter course title',
            'min_length' => 'Course title must be at least 3 characters long',
        ],
        'description' => [
            'required' => 'Please enter course description',
            'min_length' => 'Course description must be at least 10 characters long',
        ],
        'content' => [
            'required' => 'Please enter course content',
        ],
    ];
    
    // Get all courses
    public function getAllCourses()
    {
        return $this->findAll();
    }
    
    // Get specific course
    public function getCourse($id)
    {
        return $this->find($id);
    }
} 