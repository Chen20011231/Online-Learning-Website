<?php

namespace App\Models;

use CodeIgniter\Model;

class BlogModel extends Model
{
    protected $table = 'blogs';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['title', 'content', 'image', 'created_by', 'status', 'created_at', 'updated_at'];

    // Date format
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation rules
    protected $validationRules = [
        'title' => 'required|min_length[3]',
        'content' => 'required|min_length[10]',
    ];
    
    protected $validationMessages = [
        'title' => [
            'required' => 'Please enter blog title',
            'min_length' => 'Blog title must be at least 3 characters long',
        ],
        'content' => [
            'required' => 'Please enter blog content',
            'min_length' => 'Blog content must be at least 10 characters long',
        ],
    ];
    
    // Get all blogs
    public function getAllBlogs()
    {
        return $this->orderBy('created_at', 'DESC')->findAll();
    }
    
    // Get specific blog
    public function getBlog($id)
    {
        return $this->find($id);
    }
} 