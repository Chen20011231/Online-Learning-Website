<?php

namespace App\Models;

use CodeIgniter\Model;

class QuizModel extends Model
{
    protected $table = 'quizzes';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['title', 'description', 'course_id', 'created_by', 'status', 'created_at', 'updated_at'];

    // Date format
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation rules
    protected $validationRules = [
        'title' => 'required|min_length[3]',
        'description' => 'required|min_length[10]',
        'course_id' => 'required|numeric',
    ];
    
    protected $validationMessages = [
        'title' => [
            'required' => 'Please enter quiz title',
            'min_length' => 'Quiz title must be at least 3 characters long',
        ],
        'description' => [
            'required' => 'Please enter quiz description',
            'min_length' => 'Quiz description must be at least 10 characters long',
        ],
        'course_id' => [
            'required' => 'Please select related course',
            'numeric' => 'Course ID must be a number',
        ],
    ];
    
    // Get all quizzes for a specific course
    public function getQuizzesByCourse($courseId)
    {
        return $this->where('course_id', $courseId)->findAll();
    }
    
    // Get specific quiz
    public function getQuiz($id)
    {
        return $this->find($id);
    }
} 