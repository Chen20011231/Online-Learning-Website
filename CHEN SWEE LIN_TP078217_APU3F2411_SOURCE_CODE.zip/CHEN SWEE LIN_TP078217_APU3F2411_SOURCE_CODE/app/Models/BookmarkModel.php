<?php

namespace App\Models;

use CodeIgniter\Model;

class BookmarkModel extends Model
{
    protected $table = 'bookmarks';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['user_id', 'course_id', 'created_at'];

    // Date format
    protected $useTimestamps = false;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';

    // Validation rules
    protected $validationRules = [
        'user_id' => 'required|numeric',
        'course_id' => 'required|numeric',
    ];

    /**
     * Check if the user has bookmarked the course
     */
    public function isBookmarked($userId, $courseId)
    {
        return $this->where('user_id', $userId)
            ->where('course_id', $courseId)
            ->countAllResults() > 0;
    }

    /**
     * Add bookmark
     */
    public function addBookmark($userId, $courseId)
    {
        // Check if already bookmarked
        if ($this->isBookmarked($userId, $courseId)) {
            return false;
        }

        return $this->insert([
            'user_id' => $userId,
            'course_id' => $courseId,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Remove bookmark
     */
    public function removeBookmark($userId, $courseId)
    {
        return $this->where('user_id', $userId)
            ->where('course_id', $courseId)
            ->delete();
    }

    /**
     * Get user's bookmarked courses
     */
    public function getUserBookmarks($userId)
    {
        $db = \Config\Database::connect();
        
        return $db->table('bookmarks b')
            ->select('c.*, b.created_at as bookmarked_at')
            ->join('courses c', 'b.course_id = c.id')
            ->where('b.user_id', $userId)
            ->orderBy('b.created_at', 'DESC')
            ->get()
            ->getResultArray();
    }
} 