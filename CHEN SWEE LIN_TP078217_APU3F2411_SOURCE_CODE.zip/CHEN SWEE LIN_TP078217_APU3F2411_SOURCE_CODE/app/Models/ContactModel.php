<?php

namespace App\Models;

use CodeIgniter\Model;

class ContactModel extends Model
{
    protected $table = 'contacts';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['name', 'email', 'phone', 'subject', 'message', 'created_at', 'status'];

    // Date format
    protected $useTimestamps = false;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';

    // Validation rules
    protected $validationRules = [
        'name' => 'required|min_length[3]',
        'email' => 'required|valid_email',
        'subject' => 'required',
        'message' => 'required|min_length[3]',
    ];
    
    protected $validationMessages = [
        'name' => [
            'required' => 'Please enter your name',
            'min_length' => 'Name must be at least 3 characters long',
        ],
        'email' => [
            'required' => 'Please enter your email',
            'valid_email' => 'Please enter a valid email',
        ],
        'subject' => [
            'required' => 'Please select a consultation topic',
        ],
        'message' => [
            'required' => 'Please enter your message',
            'min_length' => 'Message must be at least 3 characters long',
        ],
    ];

    /**
     * Get all contact information
     */
    public function getAllContacts()
    {
        return $this->orderBy('created_at', 'DESC')->findAll();
    }

    /**
     * Get unread contact information
     */
    public function getUnreadContacts()
    {
        return $this->where('status', 'unread')->orderBy('created_at', 'DESC')->findAll();
    }

    /**
     * Mark contact information as read
     */
    public function markAsRead($id)
    {
        return $this->update($id, ['status' => 'read']);
    }

    /**
     * Add new contact information
     */
    public function addContact($data)
    {
        try {
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['status'] = 'unread';
            
            // Record debugging information
            log_message('debug', 'Attempting to insert contact data: ' . json_encode($data));
            
            // Enable debugging mode to view SQL queries
            $this->db->query("SET sql_mode = ''");
            
            // Directly use query builder to insert data
            $builder = $this->db->table($this->table);
            $result = $builder->insert($data);
            $affectedRows = $this->db->affectedRows();
            
            log_message('debug', 'Insert result: ' . ($result ? 'true' : 'false') . ', Affected rows: ' . $affectedRows);
            
            if ($affectedRows > 0) {
                $insertId = $this->db->insertID();
                log_message('debug', 'Successfully inserted contact with ID: ' . $insertId);
                return $insertId;
            }
            
            // Record error information
            $error = $this->db->error();
            log_message('error', 'Contact insertion failed: No rows affected. DB Error: ' . json_encode($error));
            return false;
        } catch (\Exception $e) {
            log_message('error', 'Contact insertion error: ' . $e->getMessage() . ' at ' . $e->getFile() . ':' . $e->getLine());
            throw $e;
        }
    }
} 