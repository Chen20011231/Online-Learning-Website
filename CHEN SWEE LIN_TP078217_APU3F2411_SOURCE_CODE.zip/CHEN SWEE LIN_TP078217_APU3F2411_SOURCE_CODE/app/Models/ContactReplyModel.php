<?php

namespace App\Models;

use CodeIgniter\Model;

class ContactReplyModel extends Model
{
    protected $table = 'contact_replies';
    protected $primaryKey = 'id';
    
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    
    protected $allowedFields = [
        'contact_id', 
        'admin_id', 
        'subject', 
        'message', 
        'recipient_email', 
        'recipient_name'
    ];
    
    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    // Validation
    protected $validationRules = [
        'contact_id' => 'required|numeric',
        'subject' => 'required',
        'message' => 'required',
        'recipient_email' => 'required|valid_email',
        'recipient_name' => 'required'
    ];
    
    protected $validationMessages = [];
    protected $skipValidation = false;
} 