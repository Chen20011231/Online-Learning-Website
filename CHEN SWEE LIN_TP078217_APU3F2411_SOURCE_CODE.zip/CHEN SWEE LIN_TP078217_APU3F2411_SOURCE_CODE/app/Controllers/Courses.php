<?php

namespace App\Controllers;

use App\Models\CourseModel;
use App\Models\QuestionModel;
use App\Models\CertificateModel;
use App\Models\UserModel;
use CodeIgniter\API\ResponseTrait;

class Courses extends BaseController
{
    use ResponseTrait;
    
    protected $courseModel;
    protected $certificateModel;
    
    public function __construct()
    {
        $this->courseModel = new CourseModel();
        $this->certificateModel = new CertificateModel();
    }
    
    /**
     * Check if user is logged in, redirect to login page if not
     */
    private function checkLogin()
    {
        if (!session()->get('isLoggedIn')) {
            // Set message to notify user they need to login
            session()->setFlashdata('error', 'You need to login first to access course and quiz content');
            // Store current URL to return after login
            session()->setTempdata('redirect_url', current_url(), 300); // Save for 5 minutes
            return false;
        }
        return true;
    }
    
    public function index()
    {
        // Set number of courses to display per page
        $perPage = 6;
        
        // Get current page number
        $page = $this->request->getGet('page') ?? 1;
        
        // Get total number of courses
        $total = $this->courseModel->where('status', 'active')->countAllResults();
        
        // Get courses for current page
        $courses = $this->courseModel->where('status', 'active')
            ->orderBy('created_at', 'DESC')
            ->limit($perPage, ($page - 1) * $perPage)
            ->findAll();
        
        // Configure pager correctly
        $pager = service('pager');
        $pager->setPath('courses');
        
        // Allow non-logged in users to view course list
        $data = [
            'title' => 'Course List',
            'courses' => $courses,
            'pager' => $pager,
            'pager_links' => $pager->makeLinks($page, $perPage, $total, 'course_pager')
        ];
        
        return view('courses/index', $data);
    }
    
    /**
     * Learn course content
     */
    public function learn($id = null)
    {
        // Check if user is logged in
        if (!$this->checkLogin()) {
            $data = [
                'title' => 'View Course',
                'loginRequired' => true
            ];
            return view('courses/login_required', $data);
        }
        
        if ($id === null) {
            return redirect()->to('/courses');
        }
        
        $course = $this->courseModel->find($id);
        
        if ($course === null) {
            return redirect()->to('/courses')->with('error', 'Course not found');
        }
        
        // Check if user has already earned a certificate for this course
        $userId = session()->get('id');
        $hasCertificate = $this->certificateModel->hasCertificate($userId, $id);
        
        // Check if course is completed by the user
        $isCourseCompleted = $this->checkCourseCompletion($userId, $id);
        
        $data = [
            'title' => 'Learning - ' . $course['title'],
            'course' => $course,
            'hasCertificate' => $hasCertificate,
            'isCourseCompleted' => $isCourseCompleted
        ];
        
        return view('courses/learn', $data);
    }
    
    public function view($id = null)
    {
        // Check if user is logged in
        if (!$this->checkLogin()) {
            $data = [
                'title' => 'View Course',
                'loginRequired' => true
            ];
            return view('courses/login_required', $data);
        }
        
        if ($id === null) {
            return redirect()->to('/courses');
        }
        
        $course = $this->courseModel->find($id);
        
        if ($course === null) {
            return redirect()->to('/courses')->with('error', 'Course not found');
        }
        
        // Check if user has already earned a certificate for this course
        $userId = session()->get('id');
        $hasCertificate = $this->certificateModel->hasCertificate($userId, $id);
        
        // Get the number of questions for this course's quiz
        $questionCount = 0;
        $db = \Config\Database::connect();
        $quiz = $db->table('quizzes')
            ->where('course_id', $id)
            ->where('status', 'active')
            ->get()
            ->getRowArray();
            
        if ($quiz) {
            $questionModel = new QuestionModel();
            $questions = $questionModel->getQuestionsByQuiz($quiz['id']);
            $questionCount = count($questions);
        }
        
        // Check if user has bookmarked this course
        $bookmarkModel = new \App\Models\BookmarkModel();
        $isBookmarked = $bookmarkModel->isBookmarked($userId, $id);
        
        // Get related courses (up to 3 other courses, excluding current one)
        $relatedCourses = $this->courseModel
            ->where('id !=', $id)
            ->where('status', 'active')
            ->orderBy('RAND()')
            ->limit(3)
            ->find();
        
        $data = [
            'title' => $course['title'],
            'course' => $course,
            'hasCertificate' => $hasCertificate,
            'activeTab' => 'course-intro', // Default to course intro tab
            'questionCount' => $questionCount,
            'isBookmarked' => $isBookmarked,
            'relatedCourses' => $relatedCourses
        ];
        
        return view('courses/view', $data);
    }
    
    public function startQuiz($courseId = null)
    {
        // Check if user is logged in
        if (!$this->checkLogin()) {
            $data = [
                'title' => 'Course Quiz',
                'loginRequired' => true
            ];
            return view('courses/login_required', $data);
        }
        
        if ($courseId === null) {
            return redirect()->to('/courses');
        }
        
        $course = $this->courseModel->find($courseId);
        
        if ($course === null) {
            return redirect()->to('/courses')->with('error', 'Course not found');
        }
        
        // Get quizzes related to this course
        $db = \Config\Database::connect();
        $quizzes = $db->table('quizzes')
            ->where('course_id', $courseId)
            ->where('status', 'active')
            ->get()
            ->getResultArray();
        
        if (empty($quizzes)) {
            return redirect()->to('/courses/view/' . $courseId)->with('error', 'This course has no quiz yet');
        }
        
        // Get questions for the first quiz
        $quizId = $quizzes[0]['id'];
        $questionModel = new QuestionModel();
        $questions = $questionModel->getQuestionsByQuiz($quizId);
        
        // Ensure each question has a 'type' field
        foreach ($questions as &$question) {
            if (!isset($question['type']) || empty($question['type'])) {
                $question['type'] = 'multiple_choice';
            }
        }
        
        $data = [
            'title' => 'Course Quiz - ' . $course['title'],
            'course' => $course,
            'quiz' => $quizzes[0],
            'questions' => $questions,
            'courseId' => $courseId,
            'courseTitle' => $course['title']
        ];
        
        return view('courses/quiz', $data);
    }
    
    /**
     * Submit quiz answers API method
     */
    public function submitQuiz()
    {
        // Verify request is AJAX
        if (!$this->request->isAJAX()) {
            return $this->fail('Only AJAX requests are allowed', 400);
        }
        
        // Verify user is logged in
        if (!session()->get('isLoggedIn')) {
            return $this->fail('You need to login first to submit the quiz', 401);
        }
        
        // Get JSON data instead of form data
        $jsonData = $this->request->getJSON(true);
        
        $quizId = $jsonData['quiz_id'] ?? null;
        $answers = $jsonData['answers'] ?? null;
        $courseId = $jsonData['course_id'] ?? null;
        
        if (!$quizId || !$answers || !$courseId) {
            return $this->fail('Incomplete submission data', 400);
        }
        
        // Get correct answers
        $questionModel = new QuestionModel();
        $questions = $questionModel->getQuestionsByQuiz($quizId);
        
        if (empty($questions)) {
            return $this->fail('No quiz questions found', 404);
        }
        
        $score = 0;
        $totalQuestions = count($questions);
        
        // 添加日誌，用於調試
        log_message('debug', 'Questions: ' . json_encode($questions));
        log_message('debug', 'Answers: ' . json_encode($answers));
        
        foreach ($questions as $question) {
            $questionId = $question['id'];
            if (isset($answers[$questionId])) {
                $userAnswer = $answers[$questionId];
                $correctAnswer = $question['correct_answer'];
                
                // 添加日誌，用於調試
                log_message('debug', "Question ID: {$questionId}, User Answer: {$userAnswer}, Correct Answer: {$correctAnswer}");
                
                // 檢查答案是否匹配
                if ($userAnswer == $correctAnswer) {
                    $score++;
                    log_message('debug', "Correct answer for question {$questionId}");
                } else {
                    log_message('debug', "Wrong answer for question {$questionId}");
                }
            } else {
                log_message('debug', "No answer for question {$questionId}");
            }
        }
        
        // Calculate percentage score
        $percentageScore = ($totalQuestions > 0) ? ($score / $totalQuestions) * 100 : 0;
        
        // If user is logged in, save score
        if (session()->get('isLoggedIn')) {
            $userId = session()->get('id');
            
            // Save user quiz score
            $db = \Config\Database::connect();
            $db->table('quiz_results')->insert([
                'user_id' => $userId,
                'quiz_id' => $quizId,
                'course_id' => $courseId,
                'score' => $percentageScore,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            // If score is over 60%, issue certificate
            $certificateId = null;
            if ($percentageScore >= 60) {
                // Check if certificate already exists
                $existingCertId = $this->certificateModel->hasCertificate($userId, $courseId);
                if ($existingCertId) {
                    $certificateId = $existingCertId;
                    log_message('debug', "User already has certificate ID: {$certificateId}");
                } else {
                    $certificateId = $this->certificateModel->createCertificate($userId, $courseId, $quizId, $percentageScore);
                    log_message('debug', "Created new certificate ID: {$certificateId}");
                }
            } else {
                log_message('debug', "Score {$percentageScore}% is below 60%, no certificate issued");
            }
        }
        
        return $this->respond([
            'success' => true,
            'score' => $score,
            'total' => $totalQuestions,
            'percentage' => $percentageScore,
            'certificateIssued' => isset($certificateId) && $certificateId ? true : false,
            'certificateId' => $certificateId ?? null
        ]);
    }
    
    /**
     * Bookmark course
     */
    public function bookmark($courseId = null)
    {
        // Check if user is logged in
        if (!session()->get('isLoggedIn')) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Please log in first'
            ]);
        }
        
        if ($courseId === null) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Course ID cannot be empty'
            ]);
        }
        
        // Check if course exists
        $course = $this->courseModel->find($courseId);
        if ($course === null) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Course not found'
            ]);
        }
        
        $userId = session()->get('id');
        $bookmarkModel = new \App\Models\BookmarkModel();
        
        // Check if already bookmarked
        $isBookmarked = $bookmarkModel->isBookmarked($userId, $courseId);
        
        if ($isBookmarked) {
            // Unbookmark
            $bookmarkModel->removeBookmark($userId, $courseId);
            return $this->response->setJSON([
                'success' => true,
                'action' => 'unbookmarked',
                'message' => 'Unbookmarked'
            ]);
        } else {
            // Add bookmark
            $bookmarkModel->addBookmark($userId, $courseId);
            return $this->response->setJSON([
                'success' => true,
                'action' => 'bookmarked',
                'message' => 'Course bookmarked'
            ]);
        }
    }
    
    /**
     * Get user's bookmarked courses
     */
    public function bookmarks()
    {
        // Check if user is logged in
        if (!$this->checkLogin()) {
            return redirect()->to('/auth/login')->with('error', 'Please log in first');
        }
        
        // Load text helper
        helper('text');
        
        $userId = session()->get('id');
        $bookmarkModel = new \App\Models\BookmarkModel();
        $bookmarkedCourses = $bookmarkModel->getUserBookmarks($userId);
        
        $data = [
            'title' => 'My Bookmarks',
            'courses' => $bookmarkedCourses
        ];
        
        return view('courses/bookmarks', $data);
    }
    
    /**
     * View certificate
     */
    public function certificate($certificateId = null)
    {
        // Check if user is logged in
        if (!$this->checkLogin()) {
            return redirect()->to('/auth/login');
        }
        
        if ($certificateId === null) {
            return redirect()->to('/dashboard');
        }
        
        // Get certificate details
        $certificate = $this->certificateModel->getCertificateDetails($certificateId);
        
        if ($certificate === null) {
            return redirect()->to('/dashboard')->with('error', 'Certificate not found');
        }
        
        // Verify certificate belongs to current user
        if ($certificate['user_id'] != session()->get('id') && session()->get('role') != 'admin') {
            return redirect()->to('/dashboard')->with('error', 'You do not have permission to view this certificate');
        }
        
        $data = [
            'title' => 'Course Completion Certificate',
            'certificate' => $certificate
        ];
        
        return view('certificates/view', $data);
    }
    
    /**
     * Verify certificate authenticity
     */
    public function verifyCertificate()
    {
        $certificateNumber = $this->request->getGet('number');
        
        if (empty($certificateNumber)) {
            return redirect()->to('/')->with('error', 'Please provide a certificate number');
        }
        
        // Find certificate
        $certificate = $this->certificateModel
            ->select('certificates.*, courses.title as course_title, users.name as user_name')
            ->join('courses', 'courses.id = certificates.course_id')
            ->join('users', 'users.id = certificates.user_id')
            ->where('certificate_number', $certificateNumber)
            ->first();
        
        if ($certificate === null) {
            return redirect()->to('/')->with('error', 'Invalid certificate number');
        }
        
        $data = [
            'title' => 'Certificate Verification',
            'certificate' => $certificate,
            'isValid' => true
        ];
        
        return view('certificates/verify', $data);
    }

    /**
     * Search courses
     */
    public function search()
    {
        $searchTerm = $this->request->getGet('q');
        
        if (empty($searchTerm)) {
            return redirect()->to('/courses');
        }
        
        // Search course titles and descriptions
        $courses = $this->courseModel
            ->groupStart()
                ->like('title', $searchTerm)
                ->orLike('description', $searchTerm)
            ->groupEnd()
            ->where('status', 'active')
            ->findAll();
        
        $data = [
            'title' => 'Search Results: ' . $searchTerm,
            'courses' => $courses,
            'searchTerm' => $searchTerm
        ];
        
        return view('courses/index', $data);
    }

    /**
     * Check if the user has completed the course
     */
    public function checkCourseCompletion($userId, $courseId) 
    {
        $db = \Config\Database::connect();
        $result = $db->table('course_completions')
            ->where('user_id', $userId)
            ->where('course_id', $courseId)
            ->get()
            ->getRowArray();
            
        return !empty($result);
    }
    
    /**
     * Update Course Completion Status
     */
    public function updateCourseCompletion()
    {
        // Make sure it's an AJAX request
        if (!$this->request->isAJAX()) {
            return $this->fail('Only AJAX requests are allowed', 400);
        }
        
        // Make sure the user is logged in
        if (!session()->get('isLoggedIn')) {
            return $this->fail('Please log in first', 401);
        }
        
        // Getting JSON data
        $jsonData = $this->request->getJSON(true);
        
        $courseId = $jsonData['course_id'] ?? null;
        $completed = $jsonData['completed'] ?? false;
        
        if (!$courseId) {
            return $this->fail('Missing required parameters', 400);
        }
        
        // Check if the course exists
        $course = $this->courseModel->find($courseId);
        if (!$course) {
            return $this->fail('Course not found', 404);
        }
        
        $userId = session()->get('id');
        $db = \Config\Database::connect();
        
        if ($completed) {
            // Add or update course completion record
            $existingRecord = $db->table('course_completions')
                ->where('user_id', $userId)
                ->where('course_id', $courseId)
                ->get()
                ->getRowArray();
                
            if ($existingRecord) {
                // There is a record, update completion time
                $db->table('course_completions')
                    ->where('user_id', $userId)
                    ->where('course_id', $courseId)
                    ->update([
                        'completed_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ]);
            } else {
                // Create new record
                $db->table('course_completions')->insert([
                    'user_id' => $userId,
                    'course_id' => $courseId,
                    'completed_at' => date('Y-m-d H:i:s'),
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
            }
            
            return $this->respond([
                'success' => true,
                'message' => 'Course marked as completed'
            ]);
        } else {
            // Delete course completion record
            $db->table('course_completions')
                ->where('user_id', $userId)
                ->where('course_id', $courseId)
                ->delete();
                
            return $this->respond([
                'success' => true,
                'message' => 'Course completion status cancelled'
            ]);
        }
    }
} 