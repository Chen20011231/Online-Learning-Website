<?php

namespace App\Controllers;

use App\Models\CourseModel;
use App\Models\BlogModel;

class Home extends BaseController
{
    public function index()
    {
        $courseModel = new CourseModel();
        $blogModel = new BlogModel();
        
        $data = [
            'title' => 'Smart Waste Sorting Assistant - Home',
            'featuredCourses' => $courseModel->where('status', 'active')->orderBy('created_at', 'DESC')->limit(6)->findAll(),
            'recentBlogs' => $blogModel->where('status', 'active')->orderBy('created_at', 'DESC')->limit(6)->findAll()
        ];
        
        return view('home', $data);
    }
    
    public function about()
    {
        $data = [
            'title' => 'About Us - Smart Waste Sorting Assistant'
        ];
        
        return view('about', $data);
    }
    
    public function contact()
    {
        $data = [
            'title' => 'Contact Us - Smart Waste Sorting Assistant'
        ];
        
        return view('contact', $data);
    }
}
