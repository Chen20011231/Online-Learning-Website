<?php

namespace App\Controllers;

use App\Models\ContactModel;

class Contact extends BaseController
{
    protected $contactModel;
    
    public function __construct()
    {
        $this->contactModel = new ContactModel();
    }
    
    public function index()
    {
        $data = [
            'title' => 'Contact Us'
        ];
        
        return view('contact', $data);
    }
    
    public function submit()
    {
        // Validating form data
        $rules = [
            'name' => 'required|min_length[3]',
            'email' => 'required|valid_email',
            'subject' => 'required',
            'message' => 'required|min_length[3]', // Reduced minimum length requirements
        ];
        
        $messages = [
            'name' => [
                'required' => 'Please enter your name',
                'min_length' => 'Name must be at least 3 characters long',
            ],
            'email' => [
                'required' => 'Please enter your email',
                'valid_email' => 'Please enter a valid email',
            ],
            'subject' => [
                'required' => 'Please select a consultation topic',
            ],
            'message' => [
                'required' => 'Please enter your message',
                'min_length' => 'Message must be at least 3 characters long', // Update Error Messages
            ],
        ];
        
        if (!$this->validate($rules, $messages)) {
            // Store detailed validation error messages in flash data
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors())
                ->with('error', 'Form validation failed, please check your input');
        }
        
        // Get form data
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'subject' => $this->request->getPost('subject'),
            'message' => $this->request->getPost('message'),
            'status' => 'unread',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        try {
            // Debugging Information
            log_message('debug', 'Contact form data: ' . json_encode($data));
            
            // Use direct database queries instead of models
            $db = \Config\Database::connect();
            $result = $db->table('contacts')->insert($data);
            $affectedRows = $db->affectedRows();
            
            log_message('debug', 'Direct DB insert result: ' . ($result ? 'true' : 'false') . ', Affected rows: ' . $affectedRows);
            
            if ($result && $affectedRows > 0) {
                return redirect()->to('/contact')->with('success', 'Thank you for your message! We will get back to you soon.');
            } else {
                $error = $db->error();
                log_message('error', 'Contact insertion failed: ' . json_encode($error));
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Submission failed, database operation error, please try again later');
            }
        } catch (\Exception $e) {
            log_message('error', 'Contact submission error: ' . $e->getMessage() . ' at ' . $e->getFile() . ':' . $e->getLine());
            return redirect()->back()
                ->withInput()
                ->with('error', 'Submission failed, system error: ' . $e->getMessage());
        }
    }
} 