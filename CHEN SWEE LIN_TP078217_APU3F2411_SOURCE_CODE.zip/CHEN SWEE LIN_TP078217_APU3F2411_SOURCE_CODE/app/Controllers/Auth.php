<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\CourseModel;
use App\Models\QuizResultModel;
use App\Models\CertificateModel;
use App\Models\BookmarkModel;
use App\Models\BlogBookmarkModel;

class Auth extends BaseController
{
    protected $userModel;
    
    public function __construct()
    {
        $this->userModel = new UserModel();
    }
    
    public function index()
    {
        return redirect()->to('/auth/login');
    }
    
    public function login()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/dashboard');
        }
        
        $data = [
            'title' => 'Sign In'
        ];
        
        return view('auth/login', $data);
    }
    
    public function authenticate()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        
        $user = $this->userModel->validateUser($email, $password);
        
        if (!$user) {
            session()->setFlashdata('error', 'Invalid email or password');
            return redirect()->to('/auth/login')->withInput();
        }
        
        // Setting session data
        $userData = [
            'id' => $user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role'],
            'isLoggedIn' => true
        ];
        
        session()->set($userData);
        
        // Check for temporarily saved redirect URLs
        $redirectUrl = session()->getTempdata('redirect_url');
        
        if ($redirectUrl) {
            // Clearing temporary data
            session()->removeTempdata('redirect_url');
            return redirect()->to($redirectUrl);
        } else {
            // No redirect URL, redirects to default page based on role
            if ($user['role'] == 'admin') {
                return redirect()->to('/admin/dashboard');
            } else {
                return redirect()->to('/'); // Redirect to home page
            }
        }
    }
    
    // Update Dashboard Page Processing
    public function dashboard()
    {
        // Check if the user is logged in
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/auth/login');
        }
        
        $userId = session()->get('id');
        
        // Get user information
        $userModel = new UserModel();
        $user = $userModel->find($userId);
        
        // Get user quiz results
        $quizResultModel = new QuizResultModel();
        $userResults = $quizResultModel->getUserResults($userId);
        
        // Get All Courses
        $courseModel = new CourseModel();
        $allCourses = $courseModel->findAll();
        
        // Processing of user course progress data
        $completedCourses = [];
        $courseProgress = [];
        
        foreach ($userResults as $result) {
            $courseId = $result['course_id'];
            
            // Check to see if a grade has been recorded for this course
            if (!isset($completedCourses[$courseId]) || $result['score'] > $completedCourses[$courseId]['score']) {
                // Updated for top scores
                $completedCourses[$courseId] = [
                    'score' => $result['score'],
                    'completed_date' => $result['created_at']
                ];
            }
        }
        
        // Convert processed course progress data into the format required for the view
        foreach ($completedCourses as $courseId => $progress) {
            // Find course information
            $course = null;
            foreach ($allCourses as $c) {
                if ($c['id'] == $courseId) {
                    $course = $c;
                    break;
                }
            }
            
            if ($course) {
                $courseProgress[] = [
                    'course' => $course,
                    'score' => $progress['score'],
                    'completed_date' => $progress['completed_date']
                ];
            }
        }
        
        // Calculate the percentage of the number of courses completed and the total number of courses completed
        $totalCourses = count($allCourses);
        $completedCount = count($completedCourses);
        $progressPercentage = ($totalCourses > 0) ? ($completedCount / $totalCourses) * 100 : 0;
        
        // Get all the credentials of the user
        $certificateModel = new CertificateModel();
        $certificates = $certificateModel->getUserCertificates($userId);
        
        // Get the number of blog favorites a user has
        $blogBookmarkModel = new BlogBookmarkModel();
        $blogBookmarksCount = $blogBookmarkModel->where('user_id', $userId)->countAllResults();
        
        // Get the number of course favorites a user has
        $courseBookmarkModel = new BookmarkModel();
        $courseBookmarksCount = $courseBookmarkModel->where('user_id', $userId)->countAllResults();
        
        $data = [
            'title' => 'personal center',
            'user' => $user,
            'courseProgress' => $courseProgress,
            'completedCount' => $completedCount,
            'totalCourses' => $totalCourses,
            'progressPercentage' => $progressPercentage,
            'certificates' => $certificates,
            'blogBookmarksCount' => $blogBookmarksCount,
            'courseBookmarksCount' => $courseBookmarksCount
        ];
        
        return view('auth/dashboard', $data);
    }
    
    public function register()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/dashboard');
        }
        
        $data = [
            'title' => 'Sign Up'
        ];
        
        return view('auth/register', $data);
    }
    
    public function createAccount()
    {
        // 验证输入
        $rules = [
            'name' => 'required|min_length[3]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'age' => 'required|numeric',
            'gender' => 'required',
            'password' => 'required|min_length[6]',
            'confirm_password' => 'required|matches[password]',
        ];
        
        $messages = [
            'name' => [
                'required' => 'Please enter your name',
                'min_length' => 'Name length is at least 3 characters',
            ],
            'email' => [
                'required' => 'Please enter your e-mail address',
                'valid_email' => 'Please enter a valid e-mail address',
                'is_unique' => 'This e-mail address is registered',
            ],
            'age' => [
                'required' => 'Please enter your age',
                'numeric' => 'Age must be a number',
            ],
            'gender' => [
                'required' => 'Please select your gender',
            ],
            'password' => [
                'required' => 'Please enter your password',
                'min_length' => 'Password length of at least 6 characters',
            ],
            'confirm_password' => [
                'required' => 'Please confirm your password',
                'matches' => 'Inconsistent passwords entered twice',
            ],
        ];
        
        if (!$this->validate($rules, $messages)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Create User
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'age' => $this->request->getPost('age'),
            'gender' => $this->request->getPost('gender'),
            'password' => $this->request->getPost('password'),
            'role' => 'user', // Defaults to normal user
        ];
        
        $this->userModel->insert($data);
        
        session()->setFlashdata('success', 'Registration successful, please login');
        return redirect()->to('/auth/login');
    }
    
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth/login');
    }
    
    // Editor's Profile Page
    public function editProfile()
    {
        // Check if the user is logged in
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/auth/login');
        }
        
        $userId = session()->get('id');
        
        // Obtaining User Information
        $user = $this->userModel->find($userId);
        
        if (empty($user)) {
            return redirect()->to('/dashboard')->with('error', 'User does not exist');
        }
        
        $data = [
            'title' => 'Editing Personal Information',
            'user' => $user
        ];
        
        return view('auth/edit_profile', $data);
    }
    
    // Update personal data processing
    public function updateProfile()
    {
        // Check if the user is logged in
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/auth/login');
        }
        
        $userId = session()->get('id');
        $user = $this->userModel->find($userId);
        
        if (empty($user)) {
            return redirect()->to('/dashboard')->with('error', 'User does not exist');
        }
        
        // Authentication Rules
        $rules = [
            'name' => 'required|min_length[3]',
            'email' => 'required|valid_email',
            'age' => 'permit_empty|numeric|greater_than_equal_to[0]',
            'gender' => 'permit_empty|in_list[male,female,other]',
        ];
        
        // If the email has been changed, you need to validate the password and check if the mailbox has been used
        if ($this->request->getPost('email') !== $user['email']) {
            $rules['current_password'] = 'required';
            
            // Check if the mailbox has been used
            $existingUser = $this->userModel->where('email', $this->request->getPost('email'))
                                           ->where('id !=', $userId)
                                           ->first();
            
            if ($existingUser) {
                return redirect()->back()->withInput()->with('error', 'This email has been registered');
            }
        }
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // If you need to change your e-mail address, verify your current password.
        if ($this->request->getPost('email') !== $user['email']) {
            $currentPassword = $this->request->getPost('current_password');
            
            // Verify current password
            if (!password_verify($currentPassword, $user['password'])) {
                return redirect()->back()->withInput()->with('error', 'Current password is incorrect');
            }
        }
        
        // Prepare to update data
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'age' => $this->request->getPost('age'),
            'gender' => $this->request->getPost('gender'),
        ];
        
        // Update User Information
        $this->userModel->update($userId, $data);
        
        // Update Session Data
        session()->set([
            'name' => $data['name'],
            'email' => $data['email']
        ]);
        
        return redirect()->to('/auth/edit-profile')->with('success', 'Personal Information has been successfully updated');
    }
    
    // Change Password Page
    public function changePassword()
    {
        // Check if the user is logged in
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/auth/login');
        }
        
        $data = [
            'title' => 'Change Password'
        ];
        
        return view('auth/change_password', $data);
    }
    
    // Update Password Handling
    public function updatePassword()
    {
        // Check if the user is logged in
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/auth/login');
        }
        
        $userId = session()->get('id');
        $user = $this->userModel->find($userId);
        
        if (empty($user)) {
            return redirect()->to('/dashboard')->with('error', 'User does not exist');
        }
        
        // Authentication Rules
        $rules = [
            'current_password' => 'required',
            'new_password' => 'required|min_length[6]',
            'confirm_password' => 'required|matches[new_password]',
        ];
        
        $messages = [
            'current_password' => [
                'required' => 'Please enter your current password',
            ],
            'new_password' => [
                'required' => 'Please enter a new password',
                'min_length' => 'The new code is at least 6 characters long.',
            ],
            'confirm_password' => [
                'required' => 'Please confirm your new password',
                'matches' => 'Inconsistent passwords',
            ],
        ];
        
        if (!$this->validate($rules, $messages)) {
            return redirect()->back()->with('errors', $this->validator->getErrors());
        }
        
        // Verify current password
        $currentPassword = $this->request->getPost('current_password');
        if (!password_verify($currentPassword, $user['password'])) {
            return redirect()->back()->with('error', 'Current password is incorrect');
        }
        
        // Update Password
        $this->userModel->update($userId, [
            'password' => $this->request->getPost('new_password')
        ]);
        
        return redirect()->to('/auth/change-password')->with('success', 'Password has been successfully updated');
    }
}