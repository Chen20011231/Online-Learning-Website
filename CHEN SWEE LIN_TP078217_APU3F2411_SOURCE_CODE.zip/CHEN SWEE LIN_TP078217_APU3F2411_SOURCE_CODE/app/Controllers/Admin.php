<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\CourseModel;
use App\Models\QuizModel;
use App\Models\QuestionModel;
use App\Models\BlogModel;

class Admin extends BaseController
{
    protected $userModel;
    protected $courseModel;
    protected $quizModel;
    protected $questionModel;
    protected $blogModel;
    
    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->courseModel = new CourseModel();
        $this->quizModel = new QuizModel();
        $this->questionModel = new QuestionModel();
        $this->blogModel = new BlogModel();
    }
    
    // Check if user is admin
    private function checkAdmin()
    {
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'admin') {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }
    
    // Admin Panel Home
    public function index()
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Admin Panel',
            'userCount' => count($this->userModel->findAll()),
            'courseCount' => count($this->courseModel->findAll()),
            'quizCount' => count($this->quizModel->findAll()),
            'blogCount' => count($this->blogModel->findAll()),
        ];
        
        return view('admin/dashboard', $data);
    }
    
    // Admin Panel - Dashboard
    public function dashboard()
    {
        return $this->index();
    }
    
    // User Management - List All Users
    public function users()
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'User Management',
            'users' => $this->userModel->findAll(),
        ];
        
        return view('admin/users', $data);
    }
    
    // User Management - Add Administrator
    public function addAdmin()
    {
        $this->checkAdmin();
        
        return view('admin/add_admin');
    }
    
    // User Management - Create Administrator Account
    public function createAdmin()
    {
        $this->checkAdmin();
        
        // Validate input
        $rules = [
            'name' => 'required|min_length[3]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'age' => 'required|numeric',
            'gender' => 'required',
            'password' => 'required|min_length[6]',
            'confirm_password' => 'required|matches[password]',
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Create administrator
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'age' => $this->request->getPost('age'),
            'gender' => $this->request->getPost('gender'),
            'password' => $this->request->getPost('password'),
            'role' => 'admin', // Set as admin role
        ];
        
        $this->userModel->insert($data);
        
        session()->setFlashdata('success', 'Administrator account created successfully');
        return redirect()->to('/admin/users');
    }
    
    // User Management - Edit User
    public function editUser($id)
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Edit User',
            'user' => $this->userModel->find($id),
        ];
        
        if (empty($data['user'])) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        return view('admin/edit_user', $data);
    }
    
    // User Management - Update User
    public function updateUser($id)
    {
        $this->checkAdmin();
        
        // Add debug log
        log_message('debug', 'Entering updateUser method, User ID: ' . $id);
        log_message('debug', 'Form data: ' . json_encode($this->request->getPost()));
        
        // Get current user information
        $user = $this->userModel->find($id);
        if (empty($user)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Set different validation rules based on user role
        $isAdmin = $this->request->getPost('role') === 'admin';
        
        // Basic validation rules
        $rules = [
            'name' => 'required|min_length[3]',
            'email' => 'required|valid_email',
            'age' => 'permit_empty|numeric',
            'gender' => 'required',
            'role' => 'required',
        ];
        
        // Only validate password for admin accounts
        if ($isAdmin) {
            $rules['password'] = 'required|min_length[6]';
            $rules['confirm_password'] = 'required|matches[password]';
        }
        
        if (!$this->validate($rules)) {
            log_message('error', 'Validation failed: ' . json_encode($this->validator->getErrors()));
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Check if email is already used by another user - only check when email changes
        if ($this->request->getPost('email') !== $user['email']) {
            $existingUser = $this->userModel->where('email', $this->request->getPost('email'))
                                            ->where('id !=', $id)
                                            ->first();
            
            if ($existingUser) {
                log_message('error', 'Email already in use: ' . $this->request->getPost('email'));
                return redirect()->back()->withInput()->with('error', 'This email is already registered');
            }
        }
        
        // Prepare update data
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'age' => $this->request->getPost('age'),
            'gender' => $this->request->getPost('gender'),
            'role' => $this->request->getPost('role'),
        ];
        
        // Only update password for admin accounts
        if ($isAdmin && $this->request->getPost('password')) {
            $data['password'] = $this->request->getPost('password');
        }
        
        log_message('debug', 'Prepared update data: ' . json_encode($data));
        
        try {
            $result = $this->userModel->update($id, $data);
            log_message('debug', 'Update result: ' . ($result ? 'Success' : 'Failed'));
            
            if ($result === false) {
                $errors = $this->userModel->errors();
                log_message('error', 'Update failed, errors: ' . json_encode($errors));
                return redirect()->back()->withInput()->with('error', 'Update failed: ' . implode(', ', $errors));
            }
            
            session()->setFlashdata('success', 'User information updated successfully');
            return redirect()->to('/admin/users');
        } catch (\Exception $e) {
            log_message('error', 'Update exception: ' . $e->getMessage());
            session()->setFlashdata('error', 'System error: ' . $e->getMessage());
            return redirect()->back()->withInput();
        }
    }
    
    // User Management - Delete User
    public function deleteUser($id)
    {
        $this->checkAdmin();
        
        $user = $this->userModel->find($id);
        
        if (empty($user)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Do not allow deleting the currently logged in user
        if ($id == session()->get('id')) {
            session()->setFlashdata('error', 'Cannot delete the currently logged in user');
            return redirect()->to('/admin/users');
        }
        
        $this->userModel->delete($id);
        
        session()->setFlashdata('success', 'User deleted successfully');
        return redirect()->to('/admin/users');
    }
    
    // Send reply to contact message
    public function sendReply()
    {
        $this->checkAdmin();
        
        // Check if request is AJAX
        if (!$this->request->isAJAX()) {
            return redirect()->to('/admin/contacts');
        }
        
        // Get form data
        $contactId = $this->request->getPost('contact_id');
        $recipientEmail = $this->request->getPost('recipient_email');
        $recipientName = $this->request->getPost('recipient_name');
        $subject = $this->request->getPost('subject');
        $message = $this->request->getPost('message');
        
        // Validate required fields
        if (empty($recipientEmail) || empty($subject) || empty($message)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'All fields are required'
            ]);
        }
        
        // Store reply in database
        $replyModel = new \App\Models\ContactReplyModel();
        $replyData = [
            'contact_id' => $contactId,
            'admin_id' => session()->get('id'),
            'subject' => $subject,
            'message' => $message,
            'recipient_email' => $recipientEmail,
            'recipient_name' => $recipientName
        ];
        
        $result = $replyModel->insert($replyData);
        
        if ($result) {
            // Update contact status to read if not already
            $contactModel = new \App\Models\ContactModel();
            $contact = $contactModel->find($contactId);
            
            if ($contact && $contact['status'] === 'unread') {
                $contactModel->update($contactId, ['status' => 'read']);
            }
            
            // Return success response
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Reply sent successfully',
                'recipient' => $recipientName . ' <' . $recipientEmail . '>'
            ]);
        } else {
            // Return error response
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Failed to save reply. Please try again later.'
            ]);
        }
    }
    
    // Course Management - List All Courses
    public function courses()
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Course Management',
            'courses' => $this->courseModel->findAll(),
        ];
        
        return view('admin/courses', $data);
    }
    
    // Course Management - Add Course
    public function addCourse()
    {
        $this->checkAdmin();
        
        return view('admin/add_course');
    }
    
    // Course Management - Create Course
    public function createCourse()
    {
        $this->checkAdmin();
        
        // Add debug log
        log_message('debug', 'Entering createCourse method');
        log_message('debug', 'Form data: ' . json_encode($this->request->getPost()));
        
        // Validate input
        $rules = [
            'title' => 'required|min_length[3]',
            'description' => 'required|min_length[10]',
            'content' => 'required',
        ];
        
        if (!$this->validate($rules)) {
            log_message('debug', 'Validation failed: ' . json_encode($this->validator->getErrors()));
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Prepare data
        $data = [
            'title' => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'content' => $this->request->getPost('content'),
            'created_by' => session()->get('id'),
            'status' => $this->request->getPost('status') ?? 'active',
            'created_at' => date('Y-m-d H:i:s'), // Add current time as creation time
            'updated_at' => date('Y-m-d H:i:s'), // Set update time simultaneously
        ];
        
        // Handle image upload
        $image = $this->request->getFile('image');
        
        if ($image && $image->isValid() && !$image->hasMoved()) {
            try {
                $imageName = $image->getRandomName();
                $image->move(ROOTPATH . 'public/uploads/courses', $imageName);
                $data['image'] = $imageName;
                log_message('debug', 'Image uploaded successfully: ' . $imageName);
            } catch (\Exception $e) {
                log_message('error', 'Image upload failed: ' . $e->getMessage());
                // Continue execution, do not prevent course creation due to image upload failure
            }
        }
        
        log_message('debug', 'Prepared insert data: ' . json_encode($data));
        
        try {
            // Use model to insert data, automatically handle timestamps
            $courseId = $this->courseModel->insert($data);
            
            log_message('debug', 'Insert result: ' . ($courseId ? 'Success, ID: ' . $courseId : 'Failed'));
            
            if ($courseId) {
                session()->setFlashdata('success', 'Course added successfully');
                return redirect()->to('/admin/courses');
            } else {
                log_message('error', 'Insert failed: ' . json_encode($this->courseModel->errors()));
                session()->setFlashdata('error', 'Failed to add course: ' . implode(', ', $this->courseModel->errors()));
                return redirect()->back()->withInput();
            }
        } catch (\Exception $e) {
            log_message('error', 'Insert exception: ' . $e->getMessage());
            session()->setFlashdata('error', 'System error: ' . $e->getMessage());
            return redirect()->back()->withInput();
        }
    }
    
    // Course Management - Edit Course
    public function editCourse($id)
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Edit Course',
            'course' => $this->courseModel->find($id),
        ];
        
        if (empty($data['course'])) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        return view('admin/edit_course', $data);
    }
    
    // Course Management - Update Course
    public function updateCourse($id)
    {
        $this->checkAdmin();
        
        // Validate input
        $rules = [
            'title' => 'required|min_length[3]',
            'description' => 'required|min_length[10]',
            'content' => 'required',
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $course = $this->courseModel->find($id);
        
        if (empty($course)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Handle image upload
        $image = $this->request->getFile('image');
        $imageName = $course['image'];
        
        if ($image->isValid() && !$image->hasMoved()) {
            // Delete old image
            if (!empty($imageName) && file_exists(ROOTPATH . 'public/uploads/courses/' . $imageName)) {
                unlink(ROOTPATH . 'public/uploads/courses/' . $imageName);
            }
            
            $imageName = $image->getRandomName();
            $image->move(ROOTPATH . 'public/uploads/courses', $imageName);
        }
        
        // Update course
        $data = [
            'title' => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'content' => $this->request->getPost('content'),
            'image' => $imageName,
            'status' => $this->request->getPost('status') ?? 'active',
            'updated_at' => date('Y-m-d H:i:s'), // Add current time as update time
        ];
        
        $this->courseModel->update($id, $data);
        
        session()->setFlashdata('success', 'Course updated successfully');
        return redirect()->to('/admin/courses');
    }
    
    // Course Management - Delete Course
    public function deleteCourse($id)
    {
        $this->checkAdmin();
        
        $course = $this->courseModel->find($id);
        
        if (empty($course)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Delete course image
        if (!empty($course['image']) && file_exists(ROOTPATH . 'public/uploads/courses/' . $course['image'])) {
            unlink(ROOTPATH . 'public/uploads/courses/' . $course['image']);
        }
        
        // Delete related quizzes and questions
        $quizzes = $this->quizModel->where('course_id', $id)->findAll();
        
        foreach ($quizzes as $quiz) {
            $this->questionModel->where('quiz_id', $quiz['id'])->delete();
        }
        
        $this->quizModel->where('course_id', $id)->delete();
        $this->courseModel->delete($id);
        
        session()->setFlashdata('success', 'Course deleted successfully');
        return redirect()->to('/admin/courses');
    }
    
    // Quiz Management - List All Quizzes
    public function quizzes($courseId = null)
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Quiz Management',
        ];
        
        if ($courseId) {
            $data['quizzes'] = $this->quizModel->where('course_id', $courseId)->findAll();
            $data['course'] = $this->courseModel->find($courseId);
        } else {
            $data['quizzes'] = $this->quizModel->findAll();
        }
        
        return view('admin/quizzes', $data);
    }
    
    // Quiz Management - Add Quiz
    public function addQuiz($courseId = null)
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Add Quiz',
            'courses' => $this->courseModel->findAll(),
            'course_id' => $courseId,
        ];
        
        return view('admin/add_quiz', $data);
    }
    
    // Quiz Management - Create Quiz
    public function createQuiz()
    {
        $this->checkAdmin();
        
        // Add debug log
        log_message('debug', 'Starting quiz creation request');
        log_message('debug', 'Form data: ' . json_encode($this->request->getPost()));
        
        // Validate input
        $rules = [
            'title' => 'required|min_length[3]',
            'description_hidden' => 'required|min_length[10]',
            'course_id' => 'required|numeric',
            'questions.0.question' => 'required|min_length[5]',
            'questions.0.option_a' => 'required',
            'questions.0.option_b' => 'required',
            'questions.0.correct_answer' => 'required',
        ];
        
        if (!$this->validate($rules)) {
            log_message('error', 'Validation failed: ' . json_encode($this->validator->getErrors()));
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Get description content (prioritize value from hidden field)
        $description = $this->request->getPost('description_hidden');
        if (empty($description)) {
            $description = $this->request->getPost('description');
        }
        log_message('debug', 'Description content: ' . $description);
        
        // Create quiz
        $quizData = [
            'title' => $this->request->getPost('title'),
            'description' => $description,
            'course_id' => $this->request->getPost('course_id'),
            'created_by' => session()->get('id'),
            'status' => $this->request->getPost('status') ?? 'active',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        
        try {
            // Insert quiz and get ID
            $quizId = $this->quizModel->insert($quizData);
            log_message('debug', 'Quiz creation result: ' . ($quizId ? 'Success, ID=' . $quizId : 'Failed'));
            
            if ($quizId) {
                // Get all question data
                $questions = $this->request->getPost('questions');
                $successCount = 0;
                
                if (is_array($questions)) {
                    foreach ($questions as $index => $questionData) {
                        // Validate question data
                        if (empty($questionData['question']) || empty($questionData['option_a']) || 
                            empty($questionData['option_b']) || empty($questionData['correct_answer'])) {
                            log_message('debug', 'Incomplete question data, skipping: ' . json_encode($questionData));
                            continue;
                        }
                        
                        // Prepare option data (JSON format)
                        $options = [
                            'A' => $questionData['option_a'],
                            'B' => $questionData['option_b'],
                            'C' => $questionData['option_c'] ?? '',
                            'D' => $questionData['option_d'] ?? '',
                        ];
                        
                        // Remove empty options
                        $options = array_filter($options, function($value) {
                            return !empty($value);
                        });
                        
                        // Create question
                        $insertData = [
                            'quiz_id' => $quizId,
                            'question' => $questionData['question'],
                            'options' => json_encode($options, JSON_UNESCAPED_UNICODE),
                            'correct_answer' => $questionData['correct_answer'],
                            'created_at' => date('Y-m-d H:i:s'),
                            'updated_at' => date('Y-m-d H:i:s'),
                        ];
                        
                        try {
                            $result = $this->questionModel->insert($insertData);
                            log_message('debug', 'Question creation result: ' . ($result ? 'Success' : 'Failed') . ', data: ' . json_encode($insertData));
                            if ($result) {
                                $successCount++;
                            }
                        } catch (\Exception $e) {
                            log_message('error', 'Question creation exception: ' . $e->getMessage());
                        }
                    }
                } else {
                    log_message('debug', 'No question data or incorrect format');
                }
                
                if ($successCount > 0) {
                    session()->setFlashdata('success', "Quiz created successfully, added {$successCount} questions");
                } else {
                    session()->setFlashdata('error', 'Quiz created successfully, but no questions were added');
                }
            } else {
                session()->setFlashdata('error', 'Failed to add quiz');
            }
        } catch (\Exception $e) {
            log_message('error', 'Quiz creation exception: ' . $e->getMessage());
            session()->setFlashdata('error', 'Failed to add quiz: ' . $e->getMessage());
        }
        
        return redirect()->to('/admin/quizzes/' . $this->request->getPost('course_id'));
    }
    
    // Quiz Management - Edit Quiz
    public function editQuiz($id)
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Edit Quiz',
            'quiz' => $this->quizModel->find($id),
            'courses' => $this->courseModel->findAll(),
        ];
        
        if (empty($data['quiz'])) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        return view('admin/edit_quiz', $data);
    }
    
    // Quiz Management - Update Quiz
    public function updateQuiz($id)
    {
        $this->checkAdmin();
        
        // Validate input
        $rules = [
            'title' => 'required|min_length[3]',
            'description' => 'required|min_length[10]',
            'course_id' => 'required|numeric',
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $quiz = $this->quizModel->find($id);
        
        if (empty($quiz)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Update quiz
        $data = [
            'title' => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'course_id' => $this->request->getPost('course_id'),
            'status' => $this->request->getPost('status') ?? 'active',
            'updated_at' => date('Y-m-d H:i:s'), // Add current time as update time
        ];
        
        $this->quizModel->update($id, $data);
        
        // Check if there is question data
        $question = $this->request->getPost('question');
        if (!empty($question)) {
            // Validate question data
            $questionRules = [
                'option_a' => 'required',
                'option_b' => 'required',
                'correct_answer' => 'required',
            ];
            
            $questionValid = true;
            foreach ($questionRules as $field => $rule) {
                if (empty($this->request->getPost($field))) {
                    $questionValid = false;
                    session()->setFlashdata('error', 'Question data incomplete, question not added');
                    break;
                }
            }
            
            if ($questionValid) {
                // Prepare option data (JSON format)
                $options = [
                    'A' => $this->request->getPost('option_a'),
                    'B' => $this->request->getPost('option_b'),
                    'C' => $this->request->getPost('option_c'),
                    'D' => $this->request->getPost('option_d'),
                ];
                
                // Remove empty options
                $options = array_filter($options, function($value) {
                    return !empty($value);
                });
                
                // Create question
                $questionData = [
                    'quiz_id' => $id,
                    'question' => $question,
                    'options' => json_encode($options, JSON_UNESCAPED_UNICODE),
                    'correct_answer' => $this->request->getPost('correct_answer'),
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ];
                
                $this->questionModel->insert($questionData);
                session()->setFlashdata('success', 'Quiz updated successfully and a new question added');
            } else {
                session()->setFlashdata('success', 'Quiz updated successfully, but question data incomplete, no question added');
            }
        } else {
            session()->setFlashdata('success', 'Quiz updated successfully');
        }
        
        return redirect()->to('/admin/quizzes/' . $this->request->getPost('course_id'));
    }
    
    // Quiz Management - Delete Quiz
    public function deleteQuiz($id)
    {
        $this->checkAdmin();
        
        $quiz = $this->quizModel->find($id);
        
        if (empty($quiz)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Delete related questions
        $this->questionModel->where('quiz_id', $id)->delete();
        $this->quizModel->delete($id);
        
        session()->setFlashdata('success', 'Quiz deleted successfully');
        return redirect()->to('/admin/quizzes/' . $quiz['course_id']);
    }
    
    // Question Management - View all questions for a quiz
    public function questions($quizId)
    {
        $this->checkAdmin();
        
        $quiz = $this->quizModel->find($quizId);
        
        if (empty($quiz)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        $data = [
            'title' => 'Question Management',
            'quiz' => $quiz,
            'questions' => $this->questionModel->where('quiz_id', $quizId)->findAll(),
            'course' => $this->courseModel->find($quiz['course_id']),
        ];
        
        return view('admin/questions', $data);
    }
    
    // Question Management - Add Question
    public function addQuestion($quizId)
    {
        $this->checkAdmin();
        
        $quiz = $this->quizModel->find($quizId);
        
        if (empty($quiz)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        $data = [
            'title' => 'Add Question',
            'quiz' => $quiz,
            'course' => $this->courseModel->find($quiz['course_id']),
        ];
        
        return view('admin/add_question', $data);
    }
    
    // Question Management - Create Question
    public function createQuestion()
    {
        $this->checkAdmin();
        
        // Validate input
        $rules = [
            'quiz_id' => 'required|numeric',
            'question' => 'required|min_length[5]',
            'option_a' => 'required',
            'option_b' => 'required',
            'correct_answer' => 'required',
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $quizId = $this->request->getPost('quiz_id');
        
        // Prepare option data (JSON format)
        $options = [
            'A' => $this->request->getPost('option_a'),
            'B' => $this->request->getPost('option_b'),
            'C' => $this->request->getPost('option_c'),
            'D' => $this->request->getPost('option_d'),
        ];
        
        // Remove empty options
        $options = array_filter($options, function($value) {
            return !empty($value);
        });
        
        // Create question
        $data = [
            'quiz_id' => $quizId,
            'question' => $this->request->getPost('question'),
            'options' => json_encode($options, JSON_UNESCAPED_UNICODE),
            'correct_answer' => $this->request->getPost('correct_answer'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        
        $this->questionModel->insert($data);
        
        // Check if it's "Save and Add Next Question"
        if ($this->request->getPost('save_and_add')) {
            session()->setFlashdata('success', 'Question added successfully, please add another question');
            return redirect()->to('/admin/add-question/' . $quizId);
        } else {
            session()->setFlashdata('success', 'Question added successfully');
            return redirect()->to('/admin/questions/' . $quizId);
        }
    }
    
    // Question Management - Edit Question
    public function editQuestion($id)
    {
        $this->checkAdmin();
        
        $question = $this->questionModel->find($id);
        
        if (empty($question)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        $quiz = $this->quizModel->find($question['quiz_id']);
        
        $data = [
            'title' => 'Edit Question',
            'question' => $question,
            'quiz' => $quiz,
            'course' => $this->courseModel->find($quiz['course_id']),
            'options' => json_decode($question['options'], true),
        ];
        
        return view('admin/edit_question', $data);
    }
    
    // Question Management - Update Question
    public function updateQuestion($id)
    {
        $this->checkAdmin();
        
        // Validate input
        $rules = [
            'question' => 'required|min_length[5]',
            'option_a' => 'required',
            'option_b' => 'required',
            'correct_answer' => 'required',
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $question = $this->questionModel->find($id);
        
        if (empty($question)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Prepare option data (JSON format)
        $options = [
            'A' => $this->request->getPost('option_a'),
            'B' => $this->request->getPost('option_b'),
            'C' => $this->request->getPost('option_c'),
            'D' => $this->request->getPost('option_d'),
        ];
        
        // Remove empty options
        $options = array_filter($options, function($value) {
            return !empty($value);
        });
        
        // Update question
        $data = [
            'question' => $this->request->getPost('question'),
            'options' => json_encode($options, JSON_UNESCAPED_UNICODE),
            'correct_answer' => $this->request->getPost('correct_answer'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        
        $this->questionModel->update($id, $data);
        
        session()->setFlashdata('success', 'Question updated successfully');
        return redirect()->to('/admin/questions/' . $question['quiz_id']);
    }
    
    // Question Management - Delete Question
    public function deleteQuestion($id)
    {
        $this->checkAdmin();
        
        $question = $this->questionModel->find($id);
        
        if (empty($question)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        $quizId = $question['quiz_id'];
        
        $this->questionModel->delete($id);
        
        session()->setFlashdata('success', 'Question deleted successfully');
        return redirect()->to('/admin/questions/' . $quizId);
    }
    
    // Blog Management - List All Blogs
    public function blogs()
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Blog Management',
            'blogs' => $this->blogModel->orderBy('created_at', 'DESC')->findAll(),
        ];
        
        return view('admin/blogs', $data);
    }
    
    // Blog Management - Add Blog
    public function addBlog()
    {
        $this->checkAdmin();
        
        return view('admin/add_blog');
    }
    
    // Blog Management - Create Blog
    public function createBlog()
    {
        $this->checkAdmin();
        
        // Add debug log
        log_message('debug', 'Entering createBlog method');
        log_message('debug', 'Form data: ' . json_encode($this->request->getPost()));
        
        // Validate input
        $rules = [
            'title' => 'required|min_length[3]',
            'content' => 'required|min_length[10]',
        ];
        
        if (!$this->validate($rules)) {
            log_message('error', 'Validation failed: ' . json_encode($this->validator->getErrors()));
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Handle image upload
        $image = $this->request->getFile('image');
        $imageName = null;
        
        if ($image && $image->isValid() && !$image->hasMoved()) {
            try {
                $imageName = $image->getRandomName();
                $uploadPath = ROOTPATH . 'public/uploads/blogs';
                
                // Ensure upload directory exists
                if (!is_dir($uploadPath)) {
                    mkdir($uploadPath, 0777, true);
                }
                
                $image->move($uploadPath, $imageName);
                log_message('debug', 'Image uploaded successfully: ' . $imageName);
            } catch (\Exception $e) {
                log_message('error', 'Image upload failed: ' . $e->getMessage());
                // Continue execution, do not prevent blog creation due to image upload failure
            }
        }
        
        // Create blog
        $data = [
            'title' => $this->request->getPost('title'),
            'content' => $this->request->getPost('content'),
            'image' => $imageName,
            'created_by' => session()->get('id'),
            'status' => $this->request->getPost('status') ?? 'active',
            'created_at' => date('Y-m-d H:i:s'), // Add current time as creation time
            'updated_at' => date('Y-m-d H:i:s'), // Set update time simultaneously
        ];
        
        log_message('debug', 'Prepared insert data: ' . json_encode($data));
        
        try {
            // Use model to insert data, automatically handle timestamps
            $blogId = $this->blogModel->insert($data);
            
            log_message('debug', 'Insert result: ' . ($blogId ? 'Success, ID: ' . $blogId : 'Failed'));
            
            if ($blogId) {
                session()->setFlashdata('success', 'Blog added successfully');
                return redirect()->to('/admin/blogs');
            } else {
                log_message('error', 'Insert failed: ' . json_encode($this->blogModel->errors()));
                session()->setFlashdata('error', 'Failed to add blog: ' . implode(', ', $this->blogModel->errors()));
                return redirect()->back()->withInput();
            }
        } catch (\Exception $e) {
            log_message('error', 'Insert exception: ' . $e->getMessage());
            session()->setFlashdata('error', 'System error: ' . $e->getMessage());
            return redirect()->back()->withInput();
        }
    }
    
    // Blog Management - Edit Blog
    public function editBlog($id)
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Edit Blog',
            'blog' => $this->blogModel->find($id),
        ];
        
        if (empty($data['blog'])) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        return view('admin/edit_blog', $data);
    }
    
    // Blog Management - Update Blog
    public function updateBlog($id)
    {
        $this->checkAdmin();
        
        // Validate input
        $rules = [
            'title' => 'required|min_length[3]',
            'content' => 'required|min_length[10]',
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $blog = $this->blogModel->find($id);
        
        if (empty($blog)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Handle image upload
        $image = $this->request->getFile('image');
        $imageName = $blog['image'];
        
        if ($image->isValid() && !$image->hasMoved()) {
            // Delete old image
            if (!empty($imageName) && file_exists(ROOTPATH . 'public/uploads/blogs/' . $imageName)) {
                unlink(ROOTPATH . 'public/uploads/blogs/' . $imageName);
            }
            
            $imageName = $image->getRandomName();
            $image->move(ROOTPATH . 'public/uploads/blogs', $imageName);
        }
        
        // Update blog
        $data = [
            'title' => $this->request->getPost('title'),
            'content' => $this->request->getPost('content'),
            'image' => $imageName,
            'status' => $this->request->getPost('status') ?? 'active',
            'updated_at' => date('Y-m-d H:i:s'), // Add current time as update time
        ];
        
        $this->blogModel->update($id, $data);
        
        session()->setFlashdata('success', 'Blog updated successfully');
        return redirect()->to('/admin/blogs');
    }
    
    // Blog Management - Delete Blog
    public function deleteBlog($id)
    {
        $this->checkAdmin();
        
        $blog = $this->blogModel->find($id);
        
        if (empty($blog)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Delete blog image
        if (!empty($blog['image']) && file_exists(ROOTPATH . 'public/uploads/blogs/' . $blog['image'])) {
            unlink(ROOTPATH . 'public/uploads/blogs/' . $blog['image']);
        }
        
        $this->blogModel->delete($id);
        
        session()->setFlashdata('success', 'Blog deleted successfully');
        return redirect()->to('/admin/blogs');
    }
    
    // Profile Management
    public function profile()
    {
        $this->checkAdmin();
        
        $data = [
            'title' => 'Profile',
            'admin' => $this->userModel->find(session()->get('id')),
        ];
        
        return view('admin/profile', $data);
    }
    
    // Update Profile
    public function updateProfile()
    {
        $this->checkAdmin();
        
        $id = session()->get('id');
        $admin = $this->userModel->find($id);
        
        if (empty($admin)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        // Set validation rules
        $rules = [
            'name' => 'required|min_length[3]',
            'email' => 'required|valid_email',
            'age' => 'permit_empty|numeric|greater_than_equal_to[0]',
            'gender' => 'permit_empty|in_list[male,female,other]',
            'current_password' => 'permit_empty',
            'new_password' => 'permit_empty|min_length[6]',
            'confirm_password' => 'permit_empty|matches[new_password]',
        ];
        
        $messages = [
            'name' => [
                'required' => 'Please enter your name',
                'min_length' => 'Name must be at least 3 characters',
            ],
            'email' => [
                'required' => 'Please enter your email',
                'valid_email' => 'Please enter a valid email address',
            ],
            'age' => [
                'numeric' => 'Age must be a number',
                'greater_than_equal_to' => 'Age must be greater than or equal to 0',
            ],
            'gender' => [
                'in_list' => 'Please select a valid gender option',
            ],
            'new_password' => [
                'min_length' => 'New password must be at least 6 characters',
            ],
            'confirm_password' => [
                'matches' => 'Passwords do not match',
            ],
        ];
        
        if (!$this->validate($rules, $messages)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Check if email is already used by another user
        if ($this->request->getPost('email') !== $admin['email']) {
            $existingUser = $this->userModel->where('email', $this->request->getPost('email'))
                                           ->where('id !=', $id)
                                           ->first();
            
            if ($existingUser) {
                return redirect()->back()->withInput()->with('error', 'This email is already registered');
            }
        }
        
        // Prepare update data
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'age' => $this->request->getPost('age'),
            'gender' => $this->request->getPost('gender'),
        ];
        
        // If current password is provided, validate and update new password
        $currentPassword = $this->request->getPost('current_password');
        $newPassword = $this->request->getPost('new_password');
        
        if (!empty($currentPassword) && !empty($newPassword)) {
            // Validate current password
            if (!password_verify($currentPassword, $admin['password'])) {
                return redirect()->back()->withInput()->with('error', 'Current password is incorrect');
            }
            
            // Update password
            $data['password'] = $newPassword;
        }
        
        // Update profile
        $this->userModel->update($id, $data);
        
        // Update session data
        session()->set([
            'name' => $data['name'],
            'email' => $data['email']
        ]);
        
        session()->setFlashdata('success', 'Profile updated successfully');
        return redirect()->to('/admin/profile');
    }

    public function contacts()
    {
        // Check if user is logged in and is an admin
        if (!session()->get('isLoggedIn') || session()->get('role') != 'admin') {
            return redirect()->to('/auth/login');
        }
        
        $contactModel = new \App\Models\ContactModel();
        $contacts = $contactModel->getAllContacts();
        
        $data = [
            'title' => 'Contact Messages',
            'contacts' => $contacts
        ];
        
        return view('admin/contacts', $data);
    }
    
    public function viewContact($id)
    {
        // Check if user is logged in and is an admin
        if (!session()->get('isLoggedIn') || session()->get('role') != 'admin') {
            return redirect()->to('/auth/login');
        }
        
        $contactModel = new \App\Models\ContactModel();
        $contact = $contactModel->find($id);
        
        if (!$contact) {
            return redirect()->to('/admin/contacts')->with('error', 'Contact message not found');
        }
        
        // Mark as read
        $contactModel->markAsRead($id);
        
        $data = [
            'title' => 'View Contact Message',
            'contact' => $contact
        ];
        
        return view('admin/view_contact', $data);
    }
    
    public function deleteContact($id)
    {
        // Check if user is logged in and is an admin
        if (!session()->get('isLoggedIn') || session()->get('role') != 'admin') {
            return redirect()->to('/auth/login');
        }
        
        $contactModel = new \App\Models\ContactModel();
        $contact = $contactModel->find($id);
        
        if (!$contact) {
            return redirect()->to('/admin/contacts')->with('error', 'Contact message not found');
        }
        
        if ($contactModel->delete($id)) {
            return redirect()->to('/admin/contacts')->with('success', 'Contact message deleted successfully');
        } else {
            return redirect()->to('/admin/contacts')->with('error', 'Delete failed, please try again later');
        }
    }

    public function deleteContactPost()
    {
        // Check if user is logged in and is an admin
        $this->checkAdmin();
        
        // 獲取POST提交的聯絡ID
        $contactId = $this->request->getPost('contact_id');
        
        if (!$contactId) {
            return redirect()->to('/admin/contacts')->with('error', 'Invalid request. Contact ID is required.');
        }
        
        $contactModel = new \App\Models\ContactModel();
        $contact = $contactModel->find($contactId);
        
        if (!$contact) {
            return redirect()->to('/admin/contacts')->with('error', 'Contact message not found');
        }
        
        if ($contactModel->delete($contactId)) {
            return redirect()->to('/admin/contacts')->with('success', 'Contact message deleted successfully');
        } else {
            return redirect()->to('/admin/contacts')->with('error', 'Delete failed, please try again later');
        }
    }

    public function markAllReadContacts()
    {
        // Check if user is logged in and is an admin
        $this->checkAdmin();
        
        $contactModel = new \App\Models\ContactModel();
        
        // Get all unread contacts
        $unreadContacts = $contactModel->where('status', 'unread')->findAll();
        
        // Mark all as read
        if (!empty($unreadContacts)) {
            foreach ($unreadContacts as $contact) {
                $contactModel->update($contact['id'], ['status' => 'read']);
            }
            
            session()->setFlashdata('success', count($unreadContacts) . ' message(s) marked as read');
        } else {
            session()->setFlashdata('info', 'No unread messages found');
        }
        
        return redirect()->to('/admin/contacts');
    }
    
    // Contact Reply Management - List all sent replies
    public function contactReplies()
    {
        $this->checkAdmin();
        
        $replyModel = new \App\Models\ContactReplyModel();
        $replies = $replyModel->orderBy('created_at', 'DESC')->findAll();
        
        $data = [
            'title' => 'Sent Replies',
            'replies' => $replies
        ];
        
        return view('admin/contact_replies', $data);
    }
    
    // Contact Reply Management - View a single reply
    public function viewReply($id)
    {
        $this->checkAdmin();
        
        $replyModel = new \App\Models\ContactReplyModel();
        $reply = $replyModel->find($id);
        
        if (!$reply) {
            return redirect()->to('/admin/contact-replies')->with('error', 'Reply not found');
        }
        
        // Get the original contact message
        $contactModel = new \App\Models\ContactModel();
        $contact = $contactModel->find($reply['contact_id']);
        
        $data = [
            'title' => 'View Reply',
            'reply' => $reply,
            'contact' => $contact
        ];
        
        return view('admin/view_reply', $data);
    }
    
    // Contact Reply Management - Delete a reply
    public function deleteReply()
    {
        $this->checkAdmin();
        
        $replyId = $this->request->getPost('reply_id');
        
        if (!$replyId) {
            return redirect()->to('/admin/contact-replies')->with('error', 'Invalid request');
        }
        
        $replyModel = new \App\Models\ContactReplyModel();
        $reply = $replyModel->find($replyId);
        
        if (!$reply) {
            return redirect()->to('/admin/contact-replies')->with('error', 'Reply not found');
        }
        
        if ($replyModel->delete($replyId)) {
            return redirect()->to('/admin/contact-replies')->with('success', 'Reply deleted successfully');
        } else {
            return redirect()->to('/admin/contact-replies')->with('error', 'Failed to delete reply');
        }
    }
} 