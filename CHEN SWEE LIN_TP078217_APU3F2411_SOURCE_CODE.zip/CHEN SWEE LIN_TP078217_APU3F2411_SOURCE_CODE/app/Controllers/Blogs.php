<?php

namespace App\Controllers;

use App\Models\BlogModel;
use App\Models\BlogBookmarkModel;

class Blogs extends BaseController
{
    protected $blogModel;
    protected $blogBookmarkModel;
    
    public function __construct()
    {
        $this->blogModel = new BlogModel();
        $this->blogBookmarkModel = new BlogBookmarkModel();
    }
    
    public function index()
    {
        // Set the number of blogs displayed per page
        $perPage = 6;
        
        // Get current page number
        $page = $this->request->getGet('page') ?? 1;
        
        // Get the total number of blogs
        $total = $this->blogModel->where('status', 'active')->countAllResults();
        
        // Get the current page of the blog
        $blogs = $this->blogModel->where('status', 'active')
            ->orderBy('created_at', 'DESC')
            ->limit($perPage, ($page - 1) * $perPage)
            ->findAll();
        
        // Check if the user is logged in, if so, get the favorite blogs
        $bookmarkedBlogIds = [];
        if (session()->get('isLoggedIn')) {
            $userId = session()->get('id');
            $bookmarkedBlogs = $this->blogBookmarkModel->getUserBookmarks($userId);
            foreach ($bookmarkedBlogs as $blog) {
                $bookmarkedBlogIds[] = $blog['id'];
            }
        }
        
        // Configure the pager correctly
        $pager = service('pager');
        $pager->setPath('blogs');
        
        $data = [
            'title' => 'Environmental Blog',
            'blogs' => $blogs,
            'bookmarkedBlogIds' => $bookmarkedBlogIds,
            'pager' => $pager,
            'pager_links' => $pager->makeLinks($page, $perPage, $total, 'blog_pager')
        ];
        
        return view('blogs/index', $data);
    }
    
    public function view($id = null)
    {
        if ($id === null) {
            return redirect()->to('/blogs');
        }
        
        $blog = $this->blogModel->find($id);
        
        if ($blog === null) {
            return redirect()->to('/blogs')->with('error', '未找到该博客');
        }
        
        // Get author information
        $db = \Config\Database::connect();
        $author = $db->table('users')
            ->select('name')
            ->where('id', $blog['created_by'])
            ->get()
            ->getRowArray();

        $isBookmarked = false;
        // Check if the user has bookmarked this blog
        if (session()->get('isLoggedIn')) {
            $userId = session()->get('id');
            $isBookmarked = $this->blogBookmarkModel->isBookmarked($userId, $id);
        }
            
        $data = [
            'title' => $blog['title'],
            'blog' => $blog,
            'author' => $author ? $author['name'] : 'unknown author',
            'isBookmarked' => $isBookmarked
        ];
        
        return view('blogs/view', $data);
    }

    /**
     * Add Blog Favorites
     */
    public function bookmark($id = null)
    {
        // Check if the user is logged in
        if (!session()->get('isLoggedIn')) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Please login before bookmarking'
            ]);
        }

        if ($id === null) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'The blog was not found'
            ]);
        }

        $userId = session()->get('id');

        // Check if the blog exists
        $blog = $this->blogModel->find($id);
        if ($blog === null) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'The blog was not found'
            ]);
        }

        // Add Favorites
        $result = $this->blogBookmarkModel->addBookmark($userId, $id);

        if ($result) {
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Successful bookmarking'
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'You have bookmarked this blog'
            ]);
        }
    }

    /**
     * Cancel Blog Favorites
     */
    public function unbookmark($id = null)
    {
        // Check if the user is logged in
        if (!session()->get('isLoggedIn')) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Please log in first'
            ]);
        }

        if ($id === null) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'The blog was not found'
            ]);
        }

        $userId = session()->get('id');

        // Remove Favorites
        $result = $this->blogBookmarkModel->removeBookmark($userId, $id);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Unbookmarked'
        ]);
    }

    /**
     * Show user's blog favorites
     */
    public function bookmarks()
    {
        // Check if the user is logged in
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/auth/login')->with('error', 'Please log in first');
        }

        $userId = session()->get('id');

        $data = [
            'title' => 'My Blog Favorites',
            'bookmarkedBlogs' => $this->blogBookmarkModel->getUserBookmarks($userId)
        ];

        return view('blogs/bookmarks', $data);
    }
} 