<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\Database\Exceptions\DatabaseException;

class Test extends Controller
{
    public function index()
    {
        echo "Test Controller";
    }
    
    public function testDb()
    {
        try {
            $db = \Config\Database::connect();
            
            // Test connection
            $tables = $db->listTables();
            
            echo "<h2>Database Connection Test</h2>";
            echo "<p>Connection Status: <strong style='color:green'>Success</strong></p>";
            echo "<p>Database Name: <strong>{$db->getDatabase()}</strong></p>";
            
            echo "<h3>Table List:</h3>";
            echo "<ul>";
            foreach ($tables as $table) {
                echo "<li>{$table}</li>";
            }
            echo "</ul>";
            
            // Test quizzes table
            echo "<h3>Test Quizzes Table:</h3>";
            if (in_array('quizzes', $tables)) {
                echo "<p>Quizzes table exists</p>";
                
                // Check table structure
                $fields = $db->getFieldData('quizzes');
                
                echo "<table border='1' cellpadding='5'>";
                echo "<tr><th>Field Name</th><th>Type</th><th>Max Length</th><th>Primary Key</th></tr>";
                
                foreach ($fields as $field) {
                    echo "<tr>";
                    echo "<td>{$field->name}</td>";
                    echo "<td>{$field->type}</td>";
                    echo "<td>{$field->max_length}</td>";
                    echo "<td>" . ($field->primary_key ? 'Yes' : 'No') . "</td>";
                    echo "</tr>";
                }
                
                echo "</table>";
                
                // Try to insert data
                echo "<h3>Test Data Insertion:</h3>";
                
                try {
                    $data = [
                        'title' => 'Test Quiz',
                        'description' => 'This is a test quiz description',
                        'course_id' => 1,
                        'created_by' => 1,
                        'status' => 'active',
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s'),
                    ];
                    
                    $result = $db->table('quizzes')->insert($data);
                    
                    if ($result) {
                        $insertId = $db->insertID();
                        echo "<p style='color:green'>Insertion successful, ID: {$insertId}</p>";
                        
                        // Delete test data
                        $db->table('quizzes')->delete(['id' => $insertId]);
                        echo "<p>Test data has been deleted</p>";
                    } else {
                        echo "<p style='color:red'>Insertion failed</p>";
                    }
                } catch (\Exception $e) {
                    echo "<p style='color:red'>Error while inserting test data: " . $e->getMessage() . "</p>";
                }
                
            } else {
                echo "<p style='color:red'>Quizzes table does not exist</p>";
            }
            
            // Test questions table
            echo "<h3>Test Questions Table:</h3>";
            if (in_array('questions', $tables)) {
                echo "<p>Questions table exists</p>";
                
                // Check table structure
                $fields = $db->getFieldData('questions');
                
                echo "<table border='1' cellpadding='5'>";
                echo "<tr><th>Field Name</th><th>Type</th><th>Max Length</th><th>Primary Key</th></tr>";
                
                foreach ($fields as $field) {
                    echo "<tr>";
                    echo "<td>{$field->name}</td>";
                    echo "<td>{$field->type}</td>";
                    echo "<td>{$field->max_length}</td>";
                    echo "<td>" . ($field->primary_key ? 'Yes' : 'No') . "</td>";
                    echo "</tr>";
                }
                
                echo "</table>";
                
                // Try to insert data
                echo "<h3>Test Data Insertion:</h3>";
                
                try {
                    $data = [
                        'quiz_id' => 1,
                        'question' => 'This is a test question',
                        'options' => json_encode(['A' => 'Option A', 'B' => 'Option B'], JSON_UNESCAPED_UNICODE),
                        'correct_answer' => 'A',
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s'),
                    ];
                    
                    $result = $db->table('questions')->insert($data);
                    
                    if ($result) {
                        $insertId = $db->insertID();
                        echo "<p style='color:green'>Insertion successful, ID: {$insertId}</p>";
                        
                        // Delete test data
                        $db->table('questions')->delete(['id' => $insertId]);
                        echo "<p>Test data has been deleted</p>";
                    } else {
                        echo "<p style='color:red'>Insertion failed</p>";
                    }
                } catch (\Exception $e) {
                    echo "<p style='color:red'>Error while inserting test data: " . $e->getMessage() . "</p>";
                }
                
            } else {
                echo "<p style='color:red'>Questions table does not exist</p>";
            }
            
        } catch (DatabaseException $e) {
            echo "<h2>Database Connection Test</h2>";
            echo "<p>Connection Status: <strong style='color:red'>Failed</strong></p>";
            echo "<p>Error Message: {$e->getMessage()}</p>";
        } catch (\Exception $e) {
            echo "<h2>Test Error</h2>";
            echo "<p>Error Message: {$e->getMessage()}</p>";
        }
    }
} 